import { defineConfig } from 'vite';
import { transform } from 'esbuild';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(fileURLToPath(import.meta.url));
const at = (...p: string[]) => path.resolve(root, ...p);

const commonInstr = 'vendor/fbw-common/src/systems/instruments/src';
const a32nx = 'vendor/fbw-a32nx/src/systems';

export default defineConfig({
  root,
  base: './',
  plugins: [
    {
      name: 'a32nx-coui-rewrite',
      enforce: 'pre',
      transform(code) {
        if (code.includes('coui://html_ui/')) {
          return code.split('coui://html_ui/').join('/');
        }
        return null;
      },
    },
    {
      // The A32NX codebase mixes two JSX runtimes: FSComponent (avionics) and
      // React (legacy instruments such as ISIS). Vite's global esbuild JSX
      // factory can only be one of them, so React-flavoured .tsx files are
      // pre-compiled here with React.createElement.
      name: 'a32nx-react-jsx',
      enforce: 'pre',
      async transform(code, id) {
        if (!id.endsWith('.tsx') || id.includes('/node_modules/')) return null;
        if (!/from ['"]react['"]/.test(code) || code.includes('FSComponent')) return null;
        const result = await transform(code, {
          loader: 'tsx',
          jsx: 'transform',
          jsxFactory: 'React.createElement',
          jsxFragment: 'React.Fragment',
          target: 'es2020',
          sourcemap: true,
        });
        return { code: result.code, map: result.map };
      },
    },
  ],
  esbuild: {
    jsx: 'transform',
    jsxFactory: 'FSComponent.buildComponent',
    jsxFragment: 'FSComponent.Fragment',
    target: 'es2020',
  },
  define: {
    'process.env.AIRCRAFT_PROJECT_PREFIX': JSON.stringify('A32NX'),
    'process.env.NODE_ENV': JSON.stringify('production'),
    'process.env': '{}',
  },
  resolve: {
    dedupe: ['react', 'react-dom'],
    alias: {
      '@flybywiresim/fbw-sdk': at('src/sdk/fbw-sdk.ts'),
      '@flybywiresim/fbw-sdk-react': at('src/sdk/fbw-sdk-react.ts'),
      '@flybywiresim/msfs-avionics-common': at(commonInstr, 'MsfsAvionicsCommon/index.ts'),
      '@flybywiresim/pfd': at(commonInstr, 'PFD/index.ts'),
      '@flybywiresim/navigation-display': at(commonInstr, 'ND/index.ts'),
      '@flybywiresim/clock': at(commonInstr, 'Clock/index.ts'),
      '@flybywiresim/bat': at(commonInstr, 'BAT/index.ts'),
      '@flybywiresim/oanc': at(commonInstr, 'OANC/index.ts'),
      '@shared': at(a32nx, 'shared/src'),
      '@failures': at(a32nx, 'failures/src/index.ts'),
      '@fmgc/flightphase/Phase': at('src/shims/fmgc/flightphase/Phase.ts'),
      '@fmgc/flightphase': at('src/shims/fmgc/flightphase/index.ts'),
      '@fmgc': at(a32nx, 'fmgc/src'),
      '@atsu/fmsclient': at(a32nx, 'atsu/fmsclient/src'),
      '@atsu/common': at(a32nx, 'atsu/common/src'),
      '@datalink/aoc': at('vendor/fbw-common/src/systems/datalink/aoc/src'),
      '@datalink/atc': at('vendor/fbw-common/src/systems/datalink/atc/src'),
      '@datalink/common': at('vendor/fbw-common/src/systems/datalink/common/src'),
      '@datalink/router': at('vendor/fbw-common/src/systems/datalink/router/src'),
      '@simbridge': at(a32nx, 'simbridge-client/src'),
      '@tcas': at(a32nx, 'tcas/src'),
      '@instruments/common': at(a32nx, 'instruments/src/Common'),
      '@localization': at('vendor/fbw-a32nx/src/localization'),
      '@typings': at('vendor/fbw-common/src/typings'),
    },
  },
  server: {
    port: 5177,
    strictPort: true,
    fs: { allow: [root] },
  },
  build: {
    target: 'es2020',
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: at('index.html'),
        pfd: at('pfd.html'),
        nd: at('nd.html'),
        ewd: at('ewd.html'),
        sd: at('sd.html'),
        sdFull: at('sd-full.html'),
        clock: at('clock.html'),
        isis: at('isis.html'),
        fcu: at('fcu.html'),
        rmp: at('rmp.html'),
        bat: at('bat.html'),
        atc: at('atc.html'),
        mcdu: at('mcdu.html'),
        overhead: at('overhead.html'),
        panels: at('panels.html'),
      },
    },
  },
});
