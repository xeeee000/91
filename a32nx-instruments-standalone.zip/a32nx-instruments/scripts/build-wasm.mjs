import { execFileSync } from 'node:child_process';
import { copyFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const crate = resolve(root, 'crates/sim-core');
const source = resolve(crate, 'target/wasm32-unknown-unknown/release/sim_core.wasm');
const destination = resolve(root, 'public/wasm/sim_core.wasm');

execFileSync('cargo', ['build', '--release', '--target', 'wasm32-unknown-unknown'], {
  cwd: crate,
  stdio: 'inherit',
});
mkdirSync(dirname(destination), { recursive: true });
copyFileSync(source, destination);
console.log(`[wasm] ${destination}`);
