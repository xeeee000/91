//! Lightweight A320-class flight dynamics core.
//!
//! This is the Rust side of the browser/native simulation. It intentionally has
//! no dependencies so it can be built for Windows, iOS and wasm32 with the same
//! source. The JS/TS side owns systems, ECAM and FMS; this crate owns the
//! aircraft's motion and the basic engine/gear model.

use std::f64::consts::PI;

const G: f64 = 9.80665;
const KT: f64 = 0.514444;
const FT: f64 = 0.3048;
const WING_AREA: f64 = 122.6;
const MAX_THRUST_N: f64 = 2.0 * 120_000.0;
const EMPTY_MASS: f64 = 40_000.0;
const PAYLOAD: f64 = 8_000.0;
const FIELD_ELEV_FT: f64 = 1411.0;
const VFE: [f64; 5] = [0.0, 230.0, 200.0, 185.0, 177.0];
const FLAP_CL: [f64; 5] = [0.0, 0.35, 0.9, 1.25, 1.5];
const FLAP_CD: [f64; 5] = [0.0, 0.006, 0.014, 0.028, 0.05];

pub const PHASE_PARKED: u8 = 0;
pub const PHASE_TAXI: u8 = 1;
pub const PHASE_TAKEOFF: u8 = 2;
pub const PHASE_CLIMB: u8 = 3;
pub const PHASE_CRUISE: u8 = 4;
pub const PHASE_DESCENT: u8 = 5;
pub const PHASE_APPROACH: u8 = 6;
pub const PHASE_LANDED: u8 = 7;

pub const WARN_NONE: u8 = 0;
pub const WARN_STALL: u8 = 1;
pub const WARN_OVERSPEED: u8 = 2;

#[derive(Clone, Copy)]
pub struct Controls {
    pub pitch: f64,
    pub roll: f64,
    pub yaw: f64,
    pub throttle: f64,
    pub flaps: i32,
    pub gear_down: bool,
    pub brake: bool,
    pub ap: bool,
    pub target_alt: f64,
    pub target_speed: f64,
    pub target_heading: f64,
    pub paused: bool,
}

impl Default for Controls {
    fn default() -> Self {
        Self {
            pitch: 0.0,
            roll: 0.0,
            yaw: 0.0,
            throttle: 0.0,
            flaps: 2,
            gear_down: true,
            brake: true,
            ap: false,
            target_alt: 10_000.0,
            target_speed: 250.0,
            target_heading: 45.0,
            paused: false,
        }
    }
}

#[derive(Clone, Copy)]
pub struct State {
    pub lat: f64,
    pub lon: f64,
    pub alt_ft: f64,
    pub field_elev_ft: f64,
    pub ias: f64,
    pub tas: f64,
    pub gs: f64,
    pub vs_fpm: f64,
    pub pitch: f64,
    pub roll: f64,
    pub heading: f64,
    pub track: f64,
    pub aoa: f64,
    pub g_load: f64,
    pub n1: f64,
    pub throttle: f64,
    pub flaps: i32,
    pub gear_down: bool,
    pub brakes: bool,
    pub on_ground: bool,
    pub phase: u8,
    pub fuel_kg: f64,
    pub mass_kg: f64,
    pub thrust_kn: f64,
    pub warning: u8,
    pub touchdown_vs: f64,
    pub pitch_rate: f64,
    pub roll_rate: f64,
    pub yaw_rate: f64,
}

impl Default for State {
    fn default() -> Self {
        Self {
            lat: 46.238,
            lon: 6.109,
            alt_ft: FIELD_ELEV_FT,
            field_elev_ft: FIELD_ELEV_FT,
            ias: 0.0,
            tas: 0.0,
            gs: 0.0,
            vs_fpm: 0.0,
            pitch: 0.0,
            roll: 0.0,
            heading: 45.0,
            track: 45.0,
            aoa: 0.0,
            g_load: 1.0,
            n1: 0.0,
            throttle: 0.0,
            flaps: 2,
            gear_down: true,
            brakes: true,
            on_ground: true,
            phase: PHASE_PARKED,
            fuel_kg: 12_000.0,
            mass_kg: EMPTY_MASS + PAYLOAD + 12_000.0,
            thrust_kn: 0.0,
            warning: WARN_NONE,
            touchdown_vs: 0.0,
            pitch_rate: 0.0,
            roll_rate: 0.0,
            yaw_rate: 0.0,
        }
    }
}

pub struct Model {
    pub state: State,
    pub controls: Controls,
}

impl Model {
    pub fn new() -> Self {
        Self {
            state: State::default(),
            controls: Controls::default(),
        }
    }

    pub fn reset_runway(&mut self) {
        self.controls = Controls::default();
        self.state = State::default();
    }

    pub fn reset_at(&mut self, lat: f64, lon: f64, elevation_ft: f64, heading: f64) {
        self.reset_runway();
        self.state.lat = lat;
        self.state.lon = lon;
        self.state.alt_ft = elevation_ft;
        self.state.field_elev_ft = elevation_ft;
        self.state.heading = heading;
        self.state.track = heading;
        self.controls.target_heading = heading;
    }

    pub fn reset_approach_at(&mut self, lat: f64, lon: f64, elevation_ft: f64, heading: f64) {
        self.controls = Controls::default();
        self.state = State::default();
        self.state.lat = lat;
        self.state.lon = lon;
        self.state.field_elev_ft = elevation_ft;
        self.state.alt_ft = elevation_ft + 2000.0;
        self.state.heading = heading;
        self.state.track = heading;
        self.state.on_ground = false;
        self.state.ias = 140.0;
        self.state.tas = 140.0;
        self.state.gs = 140.0;
        self.state.vs_fpm = -700.0;
        self.state.flaps = 4;
        self.state.gear_down = true;
        self.state.brakes = false;
        self.state.n1 = 20.0;
        self.state.throttle = 20.0;
        self.state.phase = PHASE_APPROACH;
        self.controls.flaps = 4;
        self.controls.gear_down = true;
        self.controls.brake = false;
        self.controls.throttle = 20.0;
        self.controls.ap = true;
        self.controls.target_alt = elevation_ft;
        self.controls.target_speed = 135.0;
        self.controls.target_heading = heading;
    }

    pub fn go_around(&mut self) {        let base = self.state.field_elev_ft;
        if self.state.on_ground {
            self.state.on_ground = false;
            self.state.alt_ft = base + 50.0;
            self.state.ias = self.state.ias.max(150.0);
            self.state.tas = self.state.ias;
        }
        self.state.vs_fpm = 1200.0;
        self.state.pitch = 8.0;
        self.state.flaps = 2;
        self.state.gear_down = false;
        self.state.brakes = false;
        self.state.throttle = 100.0;
        self.state.n1 = 100.0;
        self.controls.throttle = 100.0;
        self.controls.flaps = 2;
        self.controls.gear_down = false;
        self.controls.brake = false;
        self.controls.ap = true;
        self.controls.target_alt = base + 3000.0;
        self.controls.target_speed = 180.0;
        self.controls.target_heading = self.state.heading;
    }

    pub fn reset_approach(&mut self) {
        self.controls = Controls {
            throttle: 38.0,
            flaps: 3,
            gear_down: true,
            brake: false,
            target_alt: FIELD_ELEV_FT,
            target_speed: 145.0,
            ..Controls::default()
        };
        self.state = State {
            lat: 46.238 - 8.0 / 60.0,
            alt_ft: 3000.0,
            ias: 150.0,
            tas: 150.0,
            gs: 150.0,
            vs_fpm: -700.0,
            pitch: 2.0,
            on_ground: false,
            phase: PHASE_APPROACH,
            n1: 38.0,
            throttle: 38.0,
            flaps: 3,
            gear_down: true,
            brakes: false,
            fuel_kg: 10_000.0,
            mass_kg: EMPTY_MASS + PAYLOAD + 10_000.0,
            ..State::default()
        };
    }

    pub fn update(&mut self, dt_seconds: f64) -> State {
        if self.controls.paused {
            return self.state;
        }
        let dt = dt_seconds.clamp(0.0, 0.1);
        let s = &mut self.state;
        let c = &mut self.controls;

        s.throttle = c.throttle;
        s.flaps = c.flaps.clamp(0, 4);
        s.gear_down = c.gear_down;
        s.brakes = c.brake;
        s.n1 = move_towards(s.n1, c.throttle, 28.0 * dt);
        s.mass_kg = EMPTY_MASS + PAYLOAD + s.fuel_kg;

        if c.ap && !s.on_ground {
            autopilot(s, c, dt);
        }

        let rho = 1.225 * (-(s.alt_ft * FT) / 8500.0).exp();
        let tas_ms = (s.tas * KT).max(0.1);
        let q = 0.5 * rho * tas_ms * tas_ms;
        let flaps = s.flaps.clamp(0, 4) as usize;
        let thrust_n = (s.n1 / 100.0) * MAX_THRUST_N * (rho / 1.225).clamp(0.25, 1.05);
        s.thrust_kn = thrust_n / 1000.0;

        let gamma = (s.vs_fpm / (s.tas * 196.85).max(1.0)).clamp(-0.75, 0.75).asin();
        let mut alpha = (s.pitch - gamma * 180.0 / PI).clamp(-6.0, 18.0);
        if s.on_ground {
            alpha = if s.pitch > 2.0 { (s.pitch * 0.9).clamp(0.0, 14.0) } else { 0.0 };
        }

        let mut cl = 0.12 + 4.8 * (alpha * PI / 180.0) + FLAP_CL[flaps];
        if alpha > 14.0 {
            cl *= (1.0 - (alpha - 14.0) * 0.07).max(0.35);
        }
        let cl = cl.clamp(-0.6, 2.15);
        let cd = 0.021 + 0.043 * cl * cl + FLAP_CD[flaps] + if s.gear_down { 0.016 } else { 0.0 };
        let lift = q * WING_AREA * cl;
        let drag = q * WING_AREA * cd;
        let weight = s.mass_kg * G;

        s.aoa = alpha;
        s.g_load = if s.on_ground { 1.0 } else { lift / weight.max(1.0) };
        s.track = s.heading;
        s.warning = if !s.on_ground && (s.aoa > 15.0 || s.ias < 105.0) {
            WARN_STALL
        } else if s.ias > VFE[flaps] + 25.0 {
            WARN_OVERSPEED
        } else {
            WARN_NONE
        };

        if s.on_ground {
            Model::ground_step(s, c, dt, thrust_n, drag, weight, lift);
        } else {
            Model::air_step(s, c, dt, thrust_n, drag, weight, lift, gamma, flaps);
        }

        s.fuel_kg = (s.fuel_kg - (s.n1 * 19.0 * 2.0 / 3600.0) * dt).max(0.0);

        let distance_nm = (s.gs * KT * dt) / 1852.0;
        let heading_rad = s.heading * PI / 180.0;
        let lat_rad = s.lat * PI / 180.0;
        s.lat += (distance_nm / 60.0) * heading_rad.cos();
        s.lon += (distance_nm / (60.0 * lat_rad.cos().max(0.1))) * heading_rad.sin();

        update_phase(s);
        self.state
    }

    fn ground_step(s: &mut State, c: &Controls, dt: f64, thrust: f64, drag: f64, weight: f64, lift: f64) {
        let rolling = weight * if c.brake { 0.55 } else { 0.018 };
        let accel = (thrust - drag - rolling) / s.mass_kg;
        s.tas = (s.tas + (accel / KT) * dt).max(0.0);
        if c.brake && s.tas < 1.0 {
            s.tas = 0.0;
        }
        s.ias = s.tas;
        s.gs = s.tas;
        s.alt_ft = s.field_elev_ft;
        s.vs_fpm = 0.0;
        s.roll = move_towards(s.roll, 0.0, 20.0 * dt);
        s.heading = (s.heading + c.yaw * 1.6 * dt * (s.tas / 80.0).clamp(0.2, 1.0) + 360.0) % 360.0;

        let vr = 145.0;
        if s.tas > vr * 0.92 && c.pitch > 0.08 {
            s.pitch = move_towards(s.pitch, 3.0 + c.pitch * 10.0, 8.0 * dt);
        } else {
            s.pitch = move_towards(s.pitch, 0.0, 4.0 * dt);
        }
        s.aoa = 0.0;

        if s.tas > vr && s.pitch > 2.0 && lift > weight * 0.92 {
            s.on_ground = false;
            s.phase = PHASE_TAKEOFF;
            s.vs_fpm = 450.0;
            s.pitch = s.pitch.max(6.0);
        }
    }

    fn air_step(s: &mut State, c: &mut Controls, dt: f64, thrust: f64, drag: f64, weight: f64, lift: f64, gamma: f64, flaps: usize) {
        let tas_ms = (s.tas * KT).max(1.0);

        let bank_target = c.roll * 27.0;
        s.roll = move_towards(s.roll, bank_target, 22.0 * dt);
        let turn_rate = G * (s.roll * PI / 180.0).tan() / tas_ms.max(45.0);
        s.heading = (s.heading + turn_rate * 180.0 / PI * dt + c.yaw * 1.2 * dt + 360.0) % 360.0;
        s.roll_rate = (bank_target - s.roll) * 0.8;

        let target_pitch = if c.pitch >= 0.0 { 2.0 + c.pitch * 12.0 } else { 2.0 + c.pitch * 9.0 };
        let old_pitch = s.pitch;
        s.pitch = move_towards(s.pitch, target_pitch, 6.0 * dt);
        s.pitch_rate = (s.pitch - old_pitch) / dt.max(1e-6);
        s.yaw_rate = c.yaw * 1.2;

        let load_factor = lift / weight.max(1.0);
        let mut target_vs = ((load_factor - 1.0) * 3000.0).clamp(-5000.0, 5000.0);
        let radio_alt = s.alt_ft - s.field_elev_ft;
        if radio_alt < 80.0 && s.vs_fpm < 0.0 {
            target_vs = target_vs.max(-180.0);
        }
        if s.tas < 115.0 {
            target_vs = target_vs.min(-400.0);
        }
        if s.aoa > 15.5 {
            target_vs = target_vs.min(-800.0);
        }
        s.vs_fpm += (target_vs - s.vs_fpm) * (3.0 * dt).clamp(0.0, 1.0);
        s.alt_ft += s.vs_fpm / 60.0 * dt;

        let accel = (thrust * (s.aoa * PI / 180.0).cos() - drag - weight * gamma.sin()) / s.mass_kg;
        s.tas = (s.tas + (accel / KT) * dt).clamp(45.0, 340.0);
        let rho = 1.225 * (-(s.alt_ft * FT) / 8500.0).exp();
        s.ias = s.tas * (rho / 1.225_f64).clamp(0.3, 1.1).sqrt();
        if s.ias > VFE[flaps] + 25.0 {
            s.tas = (s.tas - 6.0 * dt).max(45.0);
        }
        s.gs = s.ias + 6.0;

        if s.alt_ft <= s.field_elev_ft + 2.0 && s.vs_fpm <= 0.0 {
            s.touchdown_vs = s.vs_fpm;
            s.alt_ft = s.field_elev_ft;
            s.on_ground = true;
            s.pitch = 0.0;
            s.roll = 0.0;
            s.vs_fpm = 0.0;
            s.phase = PHASE_LANDED;
            s.tas = s.tas.min(145.0);
            s.ias = s.tas;
            s.gs = s.tas;
            c.brake = true;
            c.throttle = 0.0;
        }
    }
}

fn autopilot(s: &mut State, c: &mut Controls, dt: f64) {
    let alt_error = c.target_alt - s.alt_ft;
    let desired_vs = (alt_error * 1.1).clamp(-1400.0, 1600.0);
    c.pitch = ((desired_vs - s.vs_fpm) / 700.0).clamp(-0.9, 0.9);
    let speed_error = c.target_speed - s.ias;
    c.throttle = (c.throttle + speed_error * 0.45 * dt).clamp(0.0, 100.0);
    let hdg_error = ((c.target_heading - s.heading + 540.0) % 360.0) - 180.0;
    c.roll = (hdg_error / 35.0).clamp(-0.65, 0.65);
}

fn update_phase(s: &mut State) {
    if s.on_ground {
        if s.phase == PHASE_LANDED {
            return;
        }
        s.phase = if s.tas < 1.0 { PHASE_PARKED } else { PHASE_TAXI };
        return;
    }
    s.phase = if s.vs_fpm > 250.0 {
        PHASE_CLIMB
    } else if s.vs_fpm < -250.0 {
        if s.alt_ft < 3500.0 { PHASE_APPROACH } else { PHASE_DESCENT }
    } else {
        PHASE_CRUISE
    };
}

fn move_towards(current: f64, target: f64, max_delta: f64) -> f64 {
    if (target - current).abs() <= max_delta {
        target
    } else {
        current + (target - current).signum() * max_delta
    }
}

// ---------------------------------------------------------------------------
// Minimal wasm32 C ABI. No wasm-bindgen is required, so the same crate also
// builds natively for Windows/iOS and can be tested with `cargo test`.
// ---------------------------------------------------------------------------

static mut MODEL: Option<Model> = None;
static mut STATE_BUF: [f64; 32] = [0.0; 32];

fn model_mut() -> &'static mut Model {
    unsafe { MODEL.get_or_insert_with(Model::new) }
}

fn write_state(s: &State) {
    unsafe {
        let b = &mut STATE_BUF;
        b[0] = s.lat;
        b[1] = s.lon;
        b[2] = s.alt_ft;
        b[3] = s.ias;
        b[4] = s.tas;
        b[5] = s.gs;
        b[6] = s.vs_fpm;
        b[7] = s.pitch;
        b[8] = s.roll;
        b[9] = s.heading;
        b[10] = s.track;
        b[11] = s.aoa;
        b[12] = s.g_load;
        b[13] = s.n1;
        b[14] = s.throttle;
        b[15] = s.flaps as f64;
        b[16] = if s.gear_down { 1.0 } else { 0.0 };
        b[17] = if s.brakes { 1.0 } else { 0.0 };
        b[18] = if s.on_ground { 1.0 } else { 0.0 };
        b[19] = s.phase as f64;
        b[20] = s.fuel_kg;
        b[21] = s.mass_kg;
        b[22] = s.thrust_kn;
        b[23] = s.warning as f64;
        b[24] = s.touchdown_vs;
        b[25] = s.pitch_rate;
        b[26] = s.roll_rate;
        b[27] = s.yaw_rate;
        b[28] = s.field_elev_ft;
    }
}

#[no_mangle]
pub extern "C" fn sim_reset(mode: u32) {
    let m = model_mut();
    if mode == 1 {
        m.reset_approach();
    } else {
        m.reset_runway();
    }
}

#[no_mangle]
pub extern "C" fn sim_reset_at(lat: f64, lon: f64, elevation_ft: f64, heading: f64) {
    model_mut().reset_at(lat, lon, elevation_ft, heading);
}

#[no_mangle]
pub extern "C" fn sim_go_around() {
    model_mut().go_around();
}

#[no_mangle]
pub extern "C" fn sim_reset_approach_at(lat: f64, lon: f64, elevation_ft: f64, heading: f64) {
    model_mut().reset_approach_at(lat, lon, elevation_ft, heading);
}

#[allow(clippy::too_many_arguments)]
#[no_mangle]
pub extern "C" fn sim_set_controls(
    pitch: f64,
    roll: f64,
    yaw: f64,
    throttle: f64,
    flaps: f64,
    gear_down: f64,
    brake: f64,
    ap: f64,
    target_alt: f64,
    target_speed: f64,
    target_heading: f64,
    paused: f64,
) {
    let c = &mut model_mut().controls;
    c.pitch = pitch.clamp(-1.0, 1.0);
    c.roll = roll.clamp(-1.0, 1.0);
    c.yaw = yaw.clamp(-1.0, 1.0);
    c.throttle = throttle.clamp(0.0, 100.0);
    c.flaps = (flaps.round() as i32).clamp(0, 4);
    c.gear_down = gear_down > 0.5;
    c.brake = brake > 0.5;
    c.ap = ap > 0.5;
    c.target_alt = target_alt;
    c.target_speed = target_speed;
    c.target_heading = target_heading;
    c.paused = paused > 0.5;
}

#[no_mangle]
pub extern "C" fn sim_step(dt: f64) {
    let m = model_mut();
    m.update(dt);
    write_state(&m.state);
}

#[no_mangle]
pub extern "C" fn sim_state_ptr() -> *const f64 {
    let m = model_mut();
    write_state(&m.state);
    unsafe { STATE_BUF.as_ptr() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn takeoff_profile() {
        let mut m = Model::new();
        m.controls.throttle = 100.0;
        m.controls.brake = false;
        for _ in 0..600 {
            m.update(0.05);
        }
        assert!(m.state.tas > 140.0, "speed {}", m.state.tas);
        m.controls.pitch = 0.75;
        for _ in 0..300 {
            m.update(0.05);
        }
        assert!(!m.state.on_ground, "did not rotate");
        assert!(m.state.alt_ft > FIELD_ELEV_FT + 50.0, "alt {}", m.state.alt_ft);
    }

    #[test]
    fn autopilot_landing() {
        let mut m = Model::new();
        m.reset_approach();
        m.controls.ap = true;
        m.controls.target_alt = 1000.0;
        m.controls.target_speed = 135.0;
        let mut landed = false;
        for _ in 0..6000 {
            m.update(0.05);
            if m.state.on_ground {
                landed = true;
                break;
            }
        }
        assert!(landed, "did not touch down, alt {}", m.state.alt_ft);
        assert!(m.state.touchdown_vs > -800.0);
    }
}
