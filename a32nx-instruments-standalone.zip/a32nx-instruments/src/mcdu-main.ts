import './harness/globals';
import './styles/mcdu.css';
import { installInstrumentPower } from './power';
installInstrumentPower('dc');
import { simVars } from './harness/simvar-store';
import { FlightPlanLeg } from '../vendor/fbw-a32nx/src/systems/fmgc/src/flightplanning/legs/FlightPlanLeg';
import { WAYPOINT_DB } from './data/waypoints';
import { installMiniNavdata } from './data/mini-navdata';
import { CDUPerformancePage } from '../vendor/fbw-a32nx/src/systems/instruments/src/MCDU/legacy_pages/A320_Neo_CDU_PerformancePage';
import { CDUProgressPage } from '../vendor/fbw-a32nx/src/systems/instruments/src/MCDU/legacy_pages/A320_Neo_CDU_ProgressPage';
import { CDUInitPage } from '../vendor/fbw-a32nx/src/systems/instruments/src/MCDU/legacy_pages/A320_Neo_CDU_InitPage';
import { loadOpenAip } from './data/navdata/bootstrap';

void loadOpenAip();

simVars.set('L:A32NX_COLD_AND_DARK_SPAWN', 0);
simVars.set('L:A32NX_ELEC_DC_ESS_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_AC_ESS_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_AC_ESS_SHED_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_AC_2_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_FMGC_FLIGHT_PHASE', 1);
simVars.set('L:A32NX_FWC_FLIGHT_PHASE', 3);
simVars.set('E:SIMULATION TIME', 0, 'seconds');

let routePoints = [
  { ident: 'ZB01', lat: 39.67, long: 116.44 },
  { ident: 'ZB02', lat: 39.82, long: 116.5 },
  { ident: 'ZB03', lat: 39.96, long: 116.56 },
];

const fmsChannel = new BroadcastChannel('a32nx-fms');
let activeFp: any = null;
let pressKey: (key: string) => void = () => undefined;

function publishFmsRoute(origin = 'ZBAD', destination = 'ZBAA'): void {
  const legs = activeFp?.allLegs ?? [];
  const extracted = legs
    .filter((leg: any) => !leg.isDiscontinuity && leg.definition?.waypoint?.location)
    .map((leg: any) => ({
      ident: leg.definition.waypoint.ident,
      lat: leg.definition.waypoint.location.lat,
      long: leg.definition.waypoint.location.long,
    }))
    .filter((point: any, index: number, all: any[]) => index === 0 || point.ident !== all[index - 1].ident);
  if (extracted.length > 1) routePoints = extracted;
  fmsChannel.postMessage({ origin, destination, route: routePoints });
}

function airport(ident: string, icao: string, lat: number, long: number): any {
  return {
    databaseId: ident,
    icaoCode: icao,
    ident,
    name: ident,
    sectionCode: 4,
    subSectionCode: 0,
    location: { lat, long, alt: 0 },
  };
}

function installFmsGuards(host: any): boolean {
  const fms = host?.fsInstrument?.legacyFms;
  if (!fms || fms.__standaloneGuards) return !!fms;
  const original = fms.onActiveFlightPlanChanged?.bind(fms);
  if (typeof original === 'function') {
    fms.onActiveFlightPlanChanged = async (...args: any[]) => {
      try {
        return await original(...args);
      } catch (error) {
        // newCityPair deletes the active plan before creating the replacement;
        // the original subscriber can observe the gap. The page itself is fine.
        if (String(error).includes('non-existent flight plan')) return undefined;
        throw error;
      }
    };
  }
  fms.__standaloneGuards = true;
  return true;
}

function setFlightNumber(): void {
  const input = document.getElementById('fms-flt') as HTMLInputElement | null;
  const fms = (window as any).__a32nxFms;
  if (!activeFp || !input || !fms) return;
  const value = input.value.trim().toUpperCase().slice(0, 7);
  if (!value) return;
  activeFp.flightNumber?.set?.(value);
  void fms.onActiveFlightNumberChanged?.(value);
  input.value = '';
  CDUInitPage.ShowPage1(fms);
}

function installDemoRoute(host: any): boolean {
  const fms = host?.fsInstrument?.legacyFms;
  const fp = fms?.currFlightPlanService?.active;
  if (!fp) return false;
  if (fp.__standaloneDemoRoute) return true;
  activeFp = fp;
  (window as any).__a32nxFms = fms;
  if (fp.flightNumber?.get?.() === 'QQQQQ') fp.flightNumber.set('');

  fp.originSegment.airport = airport('ZBAD', 'ZB', 39.5098, 116.4105);
  fp.destinationSegment.airport = airport('ZBAA', 'ZB', 40.0801, 116.5846);

  const pd = fp.performanceData;
  pd.v1?.set(145);
  pd.vr?.set(150);
  pd.v2?.set(155);
  pd.databaseTransitionAltitude?.set(5000);
  pd.pilotThrustReductionAltitude?.set(1500);
  pd.defaultThrustReductionAltitude?.set(1500);
  pd.pilotAccelerationAltitude?.set(3000);
  pd.defaultAccelerationAltitude?.set(3000);
  pd.pilotEngineOutAccelerationAltitude?.set(3000);
  pd.defaultEngineOutAccelerationAltitude?.set(3000);
  pd.takeoffFlaps?.set(2);
  pd.flexTakeoffTemperature?.set(0);
  pd.zeroFuelWeight?.set(60000);
  pd.costIndex?.set(30);
  pd.cruiseFlightLevel?.set(350);
  pd.preselectedClimbSpeed?.set(250);
  pd.preselectedCruiseSpeed?.set(250);

  let index = 0;
  for (const wp of routePoints) {
    const fix = {
      databaseId: wp.ident,
      icaoCode: 'LF',
      ident: wp.ident,
      sectionCode: 2,
      subSectionCode: 0,
      area: 0,
      location: { lat: wp.lat, long: wp.long },
    };
    fp.enrouteSegment.insertBefore(index++, FlightPlanLeg.fromEnrouteFix(fp.enrouteSegment, fix));
  }
  fp.incrementVersion();
  fp.__standaloneDemoRoute = true;

  publishFmsRoute();
  return true;
}

function applyFmsEditor(): void {
  if (!activeFp) return;
  const originInput = document.getElementById('fms-origin') as HTMLInputElement | null;
  const destInput = document.getElementById('fms-dest') as HTMLInputElement | null;
  const wptInput = document.getElementById('fms-wpt') as HTMLInputElement | null;

  const origin = (originInput?.value ?? '').trim().toUpperCase();
  const dest = (destInput?.value ?? '').trim().toUpperCase();
  const wpt = (wptInput?.value ?? '').trim().toUpperCase();

  if (origin && WAYPOINT_DB[origin]) {
    const p = WAYPOINT_DB[origin];
    activeFp.originSegment.airport = airport(origin, origin.slice(0, 2), p.lat, p.long);
  }
  if (dest && WAYPOINT_DB[dest]) {
    const p = WAYPOINT_DB[dest];
    activeFp.destinationSegment.airport = airport(dest, dest.slice(0, 2), p.lat, p.long);
  }
  if (wpt && WAYPOINT_DB[wpt] && routePoints.length < 12) {
    const p = WAYPOINT_DB[wpt];
    const fix = {
      databaseId: wpt,
      icaoCode: wpt.slice(0, 2),
      ident: wpt,
      sectionCode: 2,
      subSectionCode: 0,
      area: 0,
      location: { lat: p.lat, long: p.long },
    };
    activeFp.enrouteSegment.insertBefore(
      activeFp.enrouteSegment.legCount,
      FlightPlanLeg.fromEnrouteFix(activeFp.enrouteSegment, fix),
    );
    routePoints = [...routePoints, { ident: wpt, lat: p.lat, long: p.long }];
    if (wptInput) wptInput.value = '';
  }
  activeFp.incrementVersion();
  publishFmsRoute(origin || 'ZBAD', dest || 'ZBAA');
}

function removeLastWaypoint(): void {
  if (!activeFp || routePoints.length === 0) return;
  routePoints = routePoints.slice(0, -1);
  const legs = activeFp.enrouteSegment.allLegs;
  if (legs.length > 0) legs.splice(legs.length - 1, 1);
  activeFp.incrementVersion();
  publishFmsRoute();
}

function clearRoute(): void {
  if (!activeFp) return;
  routePoints = [];
  activeFp.enrouteSegment.allLegs.length = 0;
  activeFp.incrementVersion();
  publishFmsRoute();
}

function applyConstraint(): void {
  const input = document.getElementById('fms-cst') as HTMLInputElement | null;
  const idxInput = document.getElementById('fms-idx') as HTMLInputElement | null;
  if (!activeFp || !input) return;
  const legs = activeFp.enrouteSegment.allLegs;
  if (legs.length === 0) return;
  const requested = Number(idxInput?.value);
  const index = Math.min(Math.max(1, Number.isFinite(requested) && requested > 0 ? requested : legs.length), legs.length);
  const leg = legs[index - 1] as any;
  if (!leg) return;

  const raw = input.value.trim();
  const [first, second] = raw.split('/');
  const speed = Number(first);
  const altitude = Number(second);
  if (Number.isFinite(speed) && speed > 0 && second !== undefined) {
    leg.pilotEnteredSpeedConstraint = { speedDescriptor: '@', speed };
    if (leg.definition) leg.definition.speed = speed;
  }
  const alt = second !== undefined ? altitude : Number(first);
  if (Number.isFinite(alt) && alt > 0) {
    leg.pilotEnteredAltitudeConstraint = { altitudeDescriptor: '+', altitude1: alt };
  }
  leg.constraintType = 1;
  activeFp.incrementVersion();
  input.value = '';
  pressKey('FPLN');
}

function moveWaypoint(delta: number): void {
  if (!activeFp || routePoints.length < 2) return;
  const idxInput = document.getElementById('fms-idx') as HTMLInputElement | null;
  const requested = Number(idxInput?.value);
  const index = Number.isFinite(requested) && requested > 0 ? requested - 1 : routePoints.length - 1;
  const target = index + delta;
  if (index < 0 || index >= routePoints.length || target < 0 || target >= routePoints.length) return;
  [routePoints[index], routePoints[target]] = [routePoints[target], routePoints[index]];
  const legs = activeFp.enrouteSegment.allLegs;
  if (legs[index] && legs[target]) [legs[index], legs[target]] = [legs[target], legs[index]];
  activeFp.incrementVersion();
  publishFmsRoute();
  pressKey('FPLN');
}

function swapLastWaypoints(): void {
  if (!activeFp || routePoints.length < 2) return;
  const n = routePoints.length;
  [routePoints[n - 2], routePoints[n - 1]] = [routePoints[n - 1], routePoints[n - 2]];
  const legs = activeFp.enrouteSegment.allLegs;
  if (legs.length >= 2) {
    [legs[legs.length - 2], legs[legs.length - 1]] = [legs[legs.length - 1], legs[legs.length - 2]];
  }
  activeFp.incrementVersion();
  publishFmsRoute();
  pressKey('FPLN');
}

function calculatePerformance(): void {
  if (!activeFp) return;
  const pd = activeFp.performanceData;
  const zfw = pd.zeroFuelWeight?.get?.() ?? 60000;
  const flaps = pd.takeoffFlaps?.get?.() ?? 2;
  const v1 = Math.round(120 + (zfw - 50000) * 0.0012 + flaps * 2);
  const vr = v1 + 5;
  const v2 = vr + 5;
  pd.v1?.set(v1);
  pd.vr?.set(vr);
  pd.v2?.set(v2);
  activeFp.incrementVersion();
  pressKey('PERF');
}

import('./instruments/mcdu-entry').then(() => {
  const host = document.querySelector('a32nx-mcdu') as any;
  const keysRoot = document.getElementById('mcdu-keys')!;
  let last = performance.now();
  let phase = 0;

  const keyQueue: string[] = [];
  let keyTimer: number | undefined;

  function dispatchKey(key: string): void {
    const fms = host?.fsInstrument?.legacyFms;
    if (key === 'PERF' && fms) {
      CDUPerformancePage.ShowPage(fms);
      return;
    }
    if (key === 'INIT' && fms) {
      CDUInitPage.ShowPage1(fms);
      return;
    }
    if (key === 'PROG' && fms) {
      CDUProgressPage.ShowPage(fms);
      return;
    }
    if (key === 'L3' && fms && fms.page?.Current === fms.page?.InitPageA) {
      // The legacy INIT page updates the plan but does not always redraw the
      // FLT NBR field in this standalone host, which made valid input look
      // like it had been ignored. Write it and refresh the page explicitly.
      const value = fms.scratchpad.getText().trim().toUpperCase().slice(0, 7);
      if (value && activeFp) {
        activeFp.flightNumber?.set?.(value);
        void fms.onActiveFlightNumberChanged?.(value);
        fms.scratchpad.setText('');
        CDUInitPage.ShowPage1(fms);
        return;
      }
    }
    const event = `A320_Neo_CDU_1_BTN_${key}`;
    if (host?.fsInstrument?.onInteractionEvent) {
      host.fsInstrument.onInteractionEvent([event]);
    } else {
      host?.onInteractionEvent?.([event]);
    }
  }

  function pumpKeys(): void {
    const key = keyQueue.shift();
    if (key === undefined) {
      keyTimer = undefined;
      return;
    }
    // The legacy MCDU updates the scratchpad one animation frame behind the
    // key event. Give LSK presses a little time so R1/L1 see the final text.
    const delay = /^[LR]\d$/.test(key) ? 600 : 55;
    keyTimer = window.setTimeout(() => {
      dispatchKey(key);
      if (keyQueue.length > 0) {
        keyTimer = window.setTimeout(pumpKeys, delay);
      } else {
        keyTimer = undefined;
      }
    }, delay);
  }

  function press(key: string): void {
    keyQueue.push(key);
    if (keyTimer === undefined) keyTimer = window.setTimeout(pumpKeys, 0);
  }

  pressKey = press;

  const rows: Array<{ cls: string; keys: string[] }> = [
    { cls: 'lsk', keys: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6'] },
    { cls: 'lsk', keys: ['R1', 'R2', 'R3', 'R4', 'R5', 'R6'] },
    { cls: 'fn', keys: ['MENU', 'INIT', 'FPLN', 'PERF', 'PROG', 'DATA'] },
    { cls: 'fn', keys: ['RAD', 'DIR', 'SEC', 'ATC', 'FUEL', 'AIRPORT'] },
    { cls: 'fn', keys: ['UP', 'DOWN', 'PREVPAGE', 'NEXTPAGE', 'CLR', 'SP'] },
    { cls: 'alpha', keys: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('') },
    { cls: 'num', keys: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'DOT', 'OVFY', 'PLUSMINUS', 'DIV'] },
  ];

  const labels: Record<string, string> = {
    PREVPAGE: '←',
    NEXTPAGE: '→',
    PLUSMINUS: '+/-',
    OVFY: 'OVFY',
  };

  for (const row of rows) {
    const element = document.createElement('div');
    element.className = `key-row ${row.cls}`;
    for (const key of row.keys) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = labels[key] ?? key;
      if (row.cls === 'lsk') button.classList.add('lsk-key');
      if (row.cls === 'fn') button.classList.add('fn-key');
      button.addEventListener('click', () => press(key));
      element.appendChild(button);
    }
    keysRoot.appendChild(element);
  }

  let installed = false;
  let navReady = false;
  let guardsReady = false;
  const routeTimer = setInterval(() => {
    if (!guardsReady) guardsReady = installFmsGuards(host);
    if (!navReady) navReady = installMiniNavdata(host);
    if (!installed) installed = installDemoRoute(host);
    if (installed) {
      publishFmsRoute();
      clearInterval(routeTimer);
    }
  }, 500);

  const originInput = document.getElementById('fms-origin') as HTMLInputElement | null;
  const destInput = document.getElementById('fms-dest') as HTMLInputElement | null;
  if (originInput) originInput.value = 'ZBAD';
  if (destInput) destInput.value = 'ZBAA';
  document.getElementById('fms-apply')?.addEventListener('click', () => {
    applyFmsEditor();
    press('FPLN');
  });
  document.getElementById('fms-del')?.addEventListener('click', () => {
    removeLastWaypoint();
    press('FPLN');
  });
  document.getElementById('fms-clear')?.addEventListener('click', () => {
    clearRoute();
    press('FPLN');
  });
  document.getElementById('fms-cst-apply')?.addEventListener('click', () => applyConstraint());
  document.getElementById('fms-swap')?.addEventListener('click', () => swapLastWaypoints());
  document.getElementById('fms-calc')?.addEventListener('click', () => calculatePerformance());
  document.getElementById('fms-flt-set')?.addEventListener('click', () => setFlightNumber());
  document.getElementById('fms-up')?.addEventListener('click', () => moveWaypoint(-1));
  document.getElementById('fms-dn')?.addEventListener('click', () => moveWaypoint(1));

  function fit(): void {
    const scale = Math.min(window.innerWidth / 600, window.innerHeight / 900);
    document.documentElement.style.setProperty('--mcdu-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;
    simVars.set('E:SIMULATION TIME', phase, 'seconds');
    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});