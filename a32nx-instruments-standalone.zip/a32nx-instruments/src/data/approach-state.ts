/** Simple ILS approach geometry shared by PFD/ND. */
export const approachState = {
  course: 45,
  distanceNm: 8,
  locDeviation: 0.02,
  gsDeviation: -0.03,
};
