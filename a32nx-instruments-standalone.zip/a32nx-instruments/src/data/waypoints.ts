export interface RoutePoint {
  ident: string;
  lat: number;
  long: number;
}

/** Tiny waypoint database for the standalone FMS-lite route editor. */
export const WAYPOINT_DB: Record<string, { lat: number; long: number }> = {
  LSGG: { lat: 46.238, long: 6.109 },
  LSGS: { lat: 46.219, long: 7.327 },
  LSGL: { lat: 46.545, long: 6.617 },
  LFLL: { lat: 45.726, long: 5.081 },
  LFLJ: { lat: 45.396, long: 6.635 },
  LFMN: { lat: 43.658, long: 7.215 },
  LEPA: { lat: 39.551, long: 2.738 },
  LIMC: { lat: 45.63, long: 8.723 },
  ZBAD: { lat: 39.5098, long: 116.4105 },
  ZBAA: { lat: 40.0801, long: 116.5846 },
  ZB01: { lat: 39.67, long: 116.44 },
  ZB02: { lat: 39.82, long: 116.5 },
  ZB03: { lat: 39.96, long: 116.56 },
};

/** Runway/scene data for the cockpit flight model. */
export const AIRPORT_SCENE: Record<string, { elevationFt: number; heading: number }> = {
  LSGG: { elevationFt: 1411, heading: 45 },
  ZBAD: { elevationFt: 118, heading: 10 },
  ZBAA: { elevationFt: 116, heading: 180 },
  LSGS: { elevationFt: 1580, heading: 220 },
  LFLL: { elevationFt: 821, heading: 170 },
  LFMN: { elevationFt: 12, heading: 40 },
};
