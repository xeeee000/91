import { simVars } from '../harness/simvar-store';
import { word } from './pfd-feed';
import { rmpState } from './rmp-state';

export function publishRmpState(): void {
  simVars.set('L:A32NX_ELEC_DC_ESS_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_OVHD_INTLT_ANN', 1);

  for (const side of ['L', 'R']) {
    simVars.set(`L:A32NX_RMP_${side}_TOGGLE_SWITCH`, 1, 'bool');
    simVars.set(`L:A32NX_RMP_${side}_SELECTED_MODE`, 1); // VHF1
    simVars.set(`L:A32NX_RMP_${side}_NAV_BUTTON_SELECTED`, 0, 'bool');
    simVars.set(`L:A32NX_RMP_${side}_AVAILABLE_MODE`, 0);
    simVars.set(`L:A32NX_RMP_${side}_VHF2_STANDBY_FREQUENCY`, 121_800_000, 'hz');
    simVars.set(`L:A32NX_RMP_${side}_VHF3_STANDBY_FREQUENCY`, 131_725_000, 'hz');
  }

  // Active/standby VHF1, Hz (the original RMP uses COM ACTIVE/STANDBY FREQUENCY).
  simVars.set('COM ACTIVE FREQUENCY:1', Math.round(rmpState.active * 1_000_000), 'hz');
  simVars.set('COM STANDBY FREQUENCY:1', Math.round(rmpState.standby * 1_000_000), 'hz');

  simVars.set('L:A32NX_ATSU_RMP_FREQUENCY', word(0));
  simVars.set('L:A32NX_AUTOPILOT_ACTIVE', 0, 'bool');
  simVars.set('L:A32NX_FCU_APPR_MODE_ACTIVE', 0, 'bool');
  simVars.set('L:A32NX_RA_1_RADIO_ALTITUDE', 0);
  simVars.set('L:A32NX_RA_2_RADIO_ALTITUDE', 0);
}
