import { publishPfdState, flight, word } from './pfd-feed';
import { simVars } from '../harness/simvar-store';
import { engineParams, engineState } from './engine-state';
import { publishSystemsState } from './systems-feed';
import { systemsState } from './systems-state';

export function publishSdState(page = 10): void {
  publishPfdState();
  publishSystemsState();
  const eng = engineParams();

  simVars.set('L:A32NX_ELEC_AC_2_BUS_IS_POWERED', 1, 'bool');
  simVars.set('LIGHT POTENTIOMETER:93', 0.85);
  simVars.set('L:A32NX_ECAM_SD_PAGE_TO_DISPLAY', page);
  simVars.set('L:A32NX_FM_GROSS_WEIGHT', 62);
  simVars.set('L:A32NX_HYD_RUDDER_DEFLECTION', 0);
  simVars.set('L:A32NX_ADIRS_IR_1_BODY_NORMAL_ACC', 1);
  simVars.set('A:ENG COMBUSTION:1', 1, 'bool');
  simVars.set('A:ENG COMBUSTION:2', 1, 'bool');
  simVars.set('L:XMLVAR_ENG_MODE_SEL', 0);

  for (const engIndex of [1, 2]) {
    simVars.set(`L:A32NX_FADEC_POWERED_ENG${engIndex}`, 1, 'bool');
    simVars.set(`L:A32NX_ENGINE_STATE:${engIndex}`, 2);
    simVars.set(`L:A32NX_FUEL_USED:${engIndex}`, 600 + eng.n1 * 10);
    simVars.set(`ENG OIL PRESSURE:${engIndex}`, 50, 'psi');
    simVars.set(`ENG OIL QUANTITY:${engIndex}`, 80, 'percent');
    simVars.set(`GENERAL ENG OIL TEMPERATURE:${engIndex}`, 90, 'celsius');
    simVars.set(`TURB ENG VIBRATION:${engIndex}`, 0.3);
    simVars.set(`ENG N2 RPM:${engIndex}`, eng.n2, 'percent');
    simVars.set(`L:A32NX_PNEU_ENG_${engIndex}_STARTER_VALVE_OPEN`, 0, 'bool');
    simVars.set(`L:A32NX_PNEU_ENG_${engIndex}_OVERPRESSURE`, 0, 'bool');
    simVars.set(`L:A32NX_PNEU_ENG_${engIndex}_REGULATED_TRANSDUCER_PRESSURE`, 45, 'psi');
  }

  simVars.set('E:ZULU TIME', 0, 'seconds');

  // Flight-control computers: neutral surfaces, valid ARINC words.
  for (const fcdc of [1, 2]) {
    for (const wordName of [
      'DISCRETE_WORD_1',
      'DISCRETE_WORD_2',
      'DISCRETE_WORD_3',
      'DISCRETE_WORD_4',
      'DISCRETE_WORD_5',
      'CAPT_ROLL_COMMAND',
      'FO_ROLL_COMMAND',
      'CAPT_PITCH_COMMAND',
      'FO_PITCH_COMMAND',
      'RUDDER_PEDAL_POS',
      'AILERON_LEFT_POS',
      'ELEVATOR_LEFT_POS',
      'AILERON_RIGHT_POS',
      'ELEVATOR_RIGHT_POS',
      'ELEVATOR_TRIM_POS',
    ]) {
      simVars.set(`L:A32NX_FCDC_${fcdc}_${wordName}`, word(wordName === 'DISCRETE_WORD_1' ? 1 << 10 : 0));
    }
  }

  // Electric / hydraulic / fuel values used by the SD pages.
  simVars.set('L:A32NX_ELEC_AC_1_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_AC_2_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_1_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_HYD_GREEN_PRESSURE', 3000);
  simVars.set('L:A32NX_HYD_BLUE_PRESSURE', 3000);
  simVars.set('L:A32NX_HYD_YELLOW_PRESSURE', 3000);
  simVars.set('L:A32NX_TOTAL_FUEL_QUANTITY', engineState.fuel);

  // Pressurization: a simple cabin schedule driven by the flight-model altitude.
  const cabinAlt = systemsState.pressFault ? 14000 : Math.max(0, Math.min(8000, (flight.altitude - 1411) * 0.24));
  const deltaPsi = systemsState.pressFault ? 0 : Math.max(0, Math.min(8.6, ((flight.altitude - 1411) / 1000) * 0.55));
  simVars.set('L:A32NX_OVHD_PRESS_MODE_SEL_PB_IS_AUTO', systemsState.pressAuto ? 1 : 0, 'bool');
  simVars.set('L:A32NX_PRESS_CPC_1_DISCRETE_WORD', word(0));
  simVars.set('L:A32NX_PRESS_CPC_2_DISCRETE_WORD', word(0));
  simVars.set('L:A32NX_PRESS_CPC_1_CABIN_ALTITUDE', word(cabinAlt));
  simVars.set('L:A32NX_PRESS_CPC_1_CABIN_DELTA_PRESSURE', word(deltaPsi));
  simVars.set('L:A32NX_PRESS_CPC_1_CABIN_VS', word(0));
  simVars.set('L:A32NX_PRESS_CPC_1_LANDING_ELEVATION', word(1411));
  simVars.set('L:A32NX_PRESS_CPC_1_OUTFLOW_VALVE_OPEN_PERCENTAGE', word(50));
  simVars.set('L:A32NX_PRESS_CPC_2_CABIN_ALTITUDE', word(cabinAlt));
  simVars.set('L:A32NX_PRESS_CPC_2_CABIN_DELTA_PRESSURE', word(deltaPsi));
  simVars.set('L:A32NX_PRESS_CPC_2_CABIN_VS', word(0));
  simVars.set('L:A32NX_PRESS_CPC_2_LANDING_ELEVATION', word(1411));
  simVars.set('L:A32NX_PRESS_CPC_2_OUTFLOW_VALVE_OPEN_PERCENTAGE', word(50));
  simVars.set('L:A32NX_PRESS_MAN_CABIN_ALTITUDE', 0, 'feet');
  simVars.set('L:A32NX_PRESS_MAN_CABIN_DELTA_PRESSURE', 0, 'psi');
  simVars.set('L:A32NX_PRESS_MAN_CABIN_VS', 0, 'feet per minute');
  simVars.set('L:A32NX_PRESS_MAN_OUTFLOW_VALVE_OPEN_PERCENTAGE', 50, 'percent');
  simVars.set('L:A32NX_PRESS_SAFETY_VALVE_OPEN_PERCENTAGE', 0, 'percent');
  simVars.set('L:VENT_INLET_VALVE', 50, 'percent');
  simVars.set('L:VENT_OUTLET_VALVE', 50, 'percent');
  simVars.set('INTERACTIVE POINT OPEN:0', systemsState.cabinDoor ? 100 : 0, 'percent');
  simVars.set('INTERACTIVE POINT OPEN:3', systemsState.cabinDoor ? 100 : 0, 'percent');
  simVars.set('L:A32NX_FWD_DOOR_CARGO_LOCKED', systemsState.cargoDoor ? 0 : 1, 'bool');
  simVars.set('L:PUSH_OVHD_OXYGEN_CREW', systemsState.oxyFail ? 1 : 0, 'bool');
}
