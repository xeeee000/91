import { simVars } from '../harness/simvar-store';
import { fcuState } from './fcu-state';

export function publishFcuState(): void {
  simVars.set('L:A32NX_FCU_HEALTHY', 1);
  simVars.set('L:A32NX_OVHD_INTLT_ANN', 1);
  simVars.set('L:A32NX_ELEC_AC_1_BUS_IS_POWERED', 1, 'bool');
  simVars.set('LIGHT POTENTIOMETER:87', 0.85, 'percent over 100');

  // AFS display: SPD 250, HDG 045, ALT 20000, V/S 0000.
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_SPD_MACH_VALUE', fcuState.speed);
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_SPD_MACH_DASHES', 0, 'bool');
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_SPD_MACH_MANAGED', fcuState.speedManaged ? 1 : 0, 'bool');
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_MACH_MODE', 0, 'bool');

  simVars.set('L:A32NX_FCU_AFS_DISPLAY_HDG_TRK_VALUE', fcuState.heading);
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_HDG_TRK_DASHES', 0, 'bool');
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_HDG_TRK_MANAGED', fcuState.headingManaged ? 1 : 0, 'bool');
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_TRK_FPA_MODE', 0, 'bool');

  simVars.set('L:A32NX_FCU_AFS_DISPLAY_ALT_VALUE', fcuState.altitude);
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_LVL_CH_MANAGED', fcuState.altitudeManaged ? 1 : 0, 'bool');

  simVars.set('L:A32NX_FCU_AFS_DISPLAY_VS_FPA_VALUE', fcuState.verticalSpeed);
  simVars.set('L:A32NX_FCU_AFS_DISPLAY_VS_FPA_DASHES', 0, 'bool');

  // EFIS baro displays, both sides.
  for (const side of ['L', 'R']) {
    simVars.set(`L:A32NX_FCU_EFIS_${side}_DISPLAY_BARO_VALUE_MODE`, 0);
    simVars.set(`L:A32NX_FCU_EFIS_${side}_DISPLAY_BARO_VALUE`, 1013);
    simVars.set(`L:A32NX_FCU_EFIS_${side}_DISPLAY_BARO_MODE`, 0);
  }
}
