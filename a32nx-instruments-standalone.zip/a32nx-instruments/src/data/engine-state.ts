/**
 * Shared engine state used by E/WD, SD and the FCU-ish displays.
 * Values are deliberately simple: this is the seed of the future JS systems
 * model that will replace the WASM systems.
 */
export interface EngineState {
  n1: number;
  fuel: number;
}

export const engineState: EngineState = {
  n1: 62,
  fuel: 15000,
};

export function engineParams(): { n1: number; n2: number; egt: number; ff: number } {
  const n1 = Math.max(0, Math.min(100, engineState.n1));
  return {
    n1,
    n2: Math.min(100, 40 + n1 * 0.7),
    egt: 350 + n1 * 4.2,
    ff: n1 * 19,
  };
}
