import { publishPfdState, flight, word } from './pfd-feed';
import { fmaState } from './fma-state';
import { ndState } from './nd-state';
import { simVars } from '../harness/simvar-store';

export function publishNdState(): void {
  publishPfdState();

  // EFIS control panel (captain side). APP mode forces ROSE_ILS (0).
  simVars.set('L:A32NX_EFIS_L_ND_RANGE', ndState.range);
  simVars.set('L:A32NX_EFIS_L_ND_MODE', fmaState.lateral === 'APP' ? 0 : ndState.mode);
  simVars.set('L:A32NX_EFIS_L_OPTION', 1); // constraints
  simVars.set('L:A32NX_EFIS_L_NAVAID_1_MODE', 0);
  simVars.set('L:A32NX_EFIS_L_NAVAID_2_MODE', 0);
  simVars.set('L:A32NX_EFIS_L_OANS_RANGE', -1);
  simVars.set('L:A380X_EFIS_L_LS_BUTTON_IS_ON', fmaState.lateral === 'APP' ? 1 : 0, 'bool');
  simVars.set('L:A380X_EFIS_L_ACTIVE_OVERLAY', fmaState.lateral === 'APP' ? 1 : 0);
  simVars.set('L:A32NX_FM_LS_COURSE', flight.heading);

  simVars.set('L:A32NX_FCU_HEADING_SELECTED', flight.heading, 'degrees');
  simVars.set('L:A320_FCU_SHOW_SELECTED_HEADING', 1, 'bool');
  simVars.set('L:A32NX_FM_LS_COURSE', 0);

  // ND display brightness potentiometers.
  simVars.set('LIGHT POTENTIOMETER:89', 0.85);
  simVars.set('LIGHT POTENTIOMETER:91', 0.85);

  // FCU selected values shown on the ND.
  simVars.set('L:A32NX_FCU_SELECTED_HEADING', word(flight.heading));
  simVars.set('L:A32NX_FCU_SELECTED_ALTITUDE', word(20000));
  simVars.set('L:A32NX_FM_LS_COURSE', flight.heading);

  // Range rings / mode annunciations are fed through the event bus by the
  // original publishers; this keeps the display alive with no FMS route yet.
}
