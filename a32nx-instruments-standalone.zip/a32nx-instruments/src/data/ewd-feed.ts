import { publishPfdState, word } from './pfd-feed';
import { simVars } from '../harness/simvar-store';
import { engineParams, engineState } from './engine-state';
import { systemsState } from './systems-state';

export function publishEwdState(): void {
  publishPfdState();
  const eng = engineParams();

  simVars.set('L:A32NX_ELEC_AC_ESS_BUS_IS_POWERED', 1, 'bool');
  simVars.set('LIGHT POTENTIOMETER:92', 0.85);

  // Engines (values are percent / degrees C / kg per hour).
  for (const engIndex of [1, 2]) {
    const running = engIndex === 1 ? systemsState.eng1Running : systemsState.eng2Running;
    const master = engIndex === 1 ? systemsState.eng1Master : systemsState.eng2Master;
    const n1 = running ? eng.n1 : 0;
    const n2 = running ? eng.n2 : 0;
    const egt = running ? eng.egt : 15;
    const ff = running ? eng.ff : 0;
    simVars.set(`L:A32NX_ENGINE_N1:${engIndex}`, n1);
    simVars.set(`L:A32NX_ENGINE_N2:${engIndex}`, n2);
    simVars.set(`L:A32NX_ENGINE_EGT:${engIndex}`, egt);
    simVars.set(`L:A32NX_ENGINE_FF:${engIndex}`, ff);
    simVars.set(`L:A32NX_ENGINE_STATE:${engIndex}`, running ? 2 : 0);
    simVars.set(`L:A32NX_FADEC_POWERED_ENG${engIndex}`, master ? 1 : 0, 'bool');
    simVars.set(`L:A32NX_REVERSER_${engIndex}_DEPLOYING`, 0, 'bool');
    simVars.set(`L:A32NX_REVERSER_${engIndex}_DEPLOYED`, 0, 'bool');
    simVars.set(`L:A32NX_AUTOTHRUST_TLA_N1:${engIndex}`, 0);
    simVars.set(`L:A32NX_AUTOTHRUST_N1_COMMANDED:${engIndex}`, n1);
  }

  simVars.set('L:A32NX_ENGINE_IDLE_N1', 22);
  simVars.set('L:A32NX_AUTOTHRUST_THRUST_LIMIT', 88);
  simVars.set('L:A32NX_AUTOTHRUST_THRUST_LIMIT_TOGA', 100);
  simVars.set('L:A32NX_AUTOTHRUST_THRUST_LIMIT_TYPE', 2);
  simVars.set('L:A32NX_AUTOTHRUST_MODE', 0);
  simVars.set('L:A32NX_AUTOTHRUST_STATUS', 0);
  simVars.set('L:A32NX_AUTOTHRUST_THRUST_LEVER_WARNING_TOGA', 0, 'bool');

  simVars.set('L:A32NX_COND_PACK_FLOW_VALVE_1_IS_OPEN', systemsState.pack1 ? 1 : 0, 'bool');
  simVars.set('L:A32NX_COND_PACK_FLOW_VALVE_2_IS_OPEN', systemsState.pack2 ? 1 : 0, 'bool');
  simVars.set('L:A32NX_OVHD_COND_PACK_1_PB_IS_ON', systemsState.pack1 ? 1 : 0, 'bool');
  simVars.set('L:A32NX_OVHD_COND_PACK_2_PB_IS_ON', systemsState.pack2 ? 1 : 0, 'bool');
  simVars.set('L:XMLVAR_Momentary_PUSH_OVHD_ANTIICE_ENG1_Pressed', 0, 'bool');
  simVars.set('L:XMLVAR_Momentary_PUSH_OVHD_ANTIICE_ENG2_Pressed', 0, 'bool');
  simVars.set('L:A32NX_PNEU_WING_ANTI_ICE_SYSTEM_SELECTED', 0, 'bool');
  simVars.set('L:APU_BLEED_PRESSURE', 0);
  simVars.set('L:XMLVAR_Throttle1Position', 0);
  simVars.set('L:XMLVAR_Throttle2Position', 0);

  simVars.set('L:A32NX_TOTAL_FUEL_QUANTITY', engineState.fuel);
  simVars.set('L:A32NX_AIRLINER_TO_FLEX_TEMP', 0);
  simVars.set('L:A32NX_ADIRS_ADR_1_STATIC_AIR_TEMPERATURE', word(15));
  simVars.set('L:A32NX_LGCIU_1_LEFT_GEAR_COMPRESSED', 0, 'bool');
  simVars.set('L:A32NX_LGCIU_1_RIGHT_GEAR_COMPRESSED', 0, 'bool');

  simVars.set('A:FUELSYSTEM VALVE SWITCH:1', 1, 'bool');
  simVars.set('A:FUELSYSTEM VALVE SWITCH:2', 1, 'bool');

  // ECAM warnings: FWC message codes consumed by formatEwdMessages().
  const warnings: number[] = [];
  if (engineState.fuel < 3000) warnings.push(280014501); // L+R WING TK LO LVL
  if (!systemsState.gen1) warnings.push(240006001); // GEN 1 OFF
  if (!systemsState.gen2) warnings.push(240007001); // GEN 2 OFF
  if (!systemsState.hydGreen) warnings.push(290012803); // GREEN ENG 1 PUMP OFF
  if (!systemsState.hydBlue) warnings.push(290012602); // BLUE ELEC PUMP OFF
  if (!systemsState.hydYellow) warnings.push(290012703); // YELLOW ENG 2 PUMP OFF
  if (!systemsState.pack1) warnings.push(216120701); // PACK 1 OFF
  if (!systemsState.pack2) warnings.push(216120801); // PACK 2 OFF
  if (engineState.n1 > 5) {
    if (!systemsState.fuelL) warnings.push(280013006); // L TK PUMP 1 OFF
    if (!systemsState.fuelR) warnings.push(280014006); // R TK PUMP 1 OFF
  }
  if (systemsState.eng1Fire) warnings.unshift(260001001); // ENG 1 FIRE
  if (systemsState.eng2Fire) warnings.unshift(260002001); // ENG 2 FIRE
  if (systemsState.apuFire) warnings.unshift(260003001); // APU FIRE
  if (systemsState.eng1Fail && systemsState.eng2Fail) warnings.unshift(770002712); // ALL ENG FAIL
  if (systemsState.cargoSmoke) warnings.unshift(260015001); // FWD CARGO SMOKE
  if (systemsState.pressFault) warnings.unshift(213122101); // EXCESS CAB ALT
  if (systemsState.oxyFail) warnings.unshift(213122102); // CREW OXY MASKS USE
  if (systemsState.hotAirFault) warnings.unshift(216329001); // HOT AIR FAULT
  if ((systemsState.adirs1 || systemsState.adirs2 || systemsState.adirs3) && !systemsState.adirsAligned) {
    warnings.unshift(340004812); // IR 1+2+3 IN ALIGN
  }
  if (systemsState.gearFail && !systemsState.gearDown) warnings.unshift(320015001); // GEAR NOT DOWN
  if (systemsState.elac1Fail) warnings.unshift(270011001); // ELAC 1 FAULT
  if (systemsState.sec1Fail) warnings.unshift(270021001); // SEC 1 FAULT
  if (systemsState.fac1Fail) warnings.unshift(220020001); // FAC 1 FAULT
  if (systemsState.fuelLeakL) warnings.unshift(280013001); // L WING TK LO LVL
  if (systemsState.fuelLeakR) warnings.unshift(280014001); // R WING TK LO LVL
  for (let i = 0; i < 7; i++) {
    simVars.set(`L:A32NX_Ewd_LOWER_LEFT_LINE_${i + 1}`, warnings[i] ?? 0);
  }
}
