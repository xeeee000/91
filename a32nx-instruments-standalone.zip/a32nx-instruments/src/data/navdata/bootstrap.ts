import { OpenAipProvider } from './openaip';
import { setNavDataProvider } from './provider';

/**
 * Optional OpenAIP data drop-in. Place an OpenAIP export at
 * public/navdata/openaip.json and it replaces the local provider at runtime.
 * The file is intentionally optional so the standalone build has no external
 * data dependency.
 */
export async function loadOpenAip(url = '/navdata/openaip.json'): Promise<boolean> {
  try {
    const response = await fetch(url);
    if (!response.ok) return false;
    const dataset = await response.json();
    const provider = new OpenAipProvider(dataset);
    if (provider.airports().length === 0) return false;
    setNavDataProvider(provider);
    console.info(`[navdata] OpenAIP provider active: ${provider.airports().length} airports`);
    return true;
  } catch {
    return false;
  }
}
