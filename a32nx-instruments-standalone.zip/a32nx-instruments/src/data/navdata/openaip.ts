import { AirportInfo, NavDataProvider, RunwayInfo } from './provider';

export interface OpenAipAirport {
  _id?: string;
  name?: string;
  icaoCode?: string;
  ident?: string;
  geometry?: { type?: string; coordinates?: [number, number] };
  elevation?: { value?: number; unit?: number } | number;
  runways?: OpenAipRunway[];
}

export interface OpenAipRunway {
  designator?: string;
  name?: string;
  trueHeading?: number;
  heading?: number;
  length?: { value?: number } | number;
  width?: { value?: number } | number;
  threshold?: { coordinates?: [number, number] };
  thresholdLocation?: { lat?: number; long?: number; lon?: number };
  elevation?: { value?: number } | number;
}

const numberOf = (value: { value?: number } | number | undefined, fallback = 0): number =>
  typeof value === 'number' ? value : value?.value ?? fallback;

const coordinate = (airport: OpenAipAirport): [number, number] | undefined => {
  const c = airport.geometry?.coordinates;
  return Array.isArray(c) && c.length >= 2 ? c : undefined;
};

/**
 * OpenAIP JSON adapter. It accepts either the API response ({ items: [...] })
 * or a bare array exported from the OpenAIP data portal.
 *
 * The browser cannot call the OpenAIP API without a key and CORS permission,
 * so this provider is intended to be fed by a local export or a small proxy.
 */
export class OpenAipProvider implements NavDataProvider {
  readonly name = 'openaip';
  private readonly airportsById = new Map<string, AirportInfo>();
  private readonly runwaysById = new Map<string, RunwayInfo[]>();

  constructor(dataset: { items?: OpenAipAirport[] } | OpenAipAirport[]) {
    const airports = Array.isArray(dataset) ? dataset : dataset.items ?? [];
    for (const raw of airports) {
      const ident = (raw.icaoCode ?? raw.ident ?? '').toUpperCase();
      const coords = coordinate(raw);
      if (!ident || !coords) continue;
      const [lon, lat] = coords;
      const elevation = numberOf(raw.elevation);
      this.airportsById.set(ident, { ident, lat, long: lon, elevationFt: elevation * 3.28084 });
      this.runwaysById.set(ident, this.parseRunways(ident, raw, elevation));
    }
  }

  private parseRunways(airportIdent: string, airport: OpenAipAirport, elevationFt: number): RunwayInfo[] {
    return (airport.runways ?? [])
      .map((r) => {
        const ident = (r.designator ?? r.name ?? '').toUpperCase();
        if (!ident) return undefined;
        const threshold = r.threshold?.coordinates;
        const fallback = this.airportsById.get(airportIdent);
        const lat = r.thresholdLocation?.lat ?? (threshold ? threshold[1] : fallback?.lat ?? 0);
        const long = r.thresholdLocation?.long ?? r.thresholdLocation?.lon ?? (threshold ? threshold[0] : fallback?.long ?? 0);
        return {
          ident,
          airportIdent,
          lat,
          long,
          elevationFt: numberOf(r.elevation, elevationFt),
          heading: r.trueHeading ?? r.heading ?? 0,
          lengthM: numberOf(r.length),
          widthM: numberOf(r.width, 45),
        } satisfies RunwayInfo;
      })
      .filter((r): r is RunwayInfo => !!r);
  }

  airports(): AirportInfo[] {
    return Array.from(this.airportsById.values());
  }

  airport(ident: string): AirportInfo | undefined {
    return this.airportsById.get(ident.toUpperCase());
  }

  waypoints(): Array<{ ident: string; lat: number; long: number }> {
    return this.airports().map((a) => ({ ident: a.ident, lat: a.lat, long: a.long }));
  }

  runways(airportIdent: string): RunwayInfo[] {
    return this.runwaysById.get(airportIdent.toUpperCase()) ?? [];
  }

  static async load(url: string, apiKey?: string): Promise<OpenAipProvider> {
    const response = await fetch(url, {
      headers: apiKey ? { 'x-openaip-api-key': apiKey } : undefined,
    });
    if (!response.ok) throw new Error(`OpenAIP request failed: ${response.status}`);
    return new OpenAipProvider(await response.json());
  }
}
