import { AIRPORT_SCENE, WAYPOINT_DB } from '../waypoints';

export interface AirportInfo {
  ident: string;
  lat: number;
  long: number;
  elevationFt: number;
}

export interface RunwayInfo {
  ident: string;
  airportIdent: string;
  lat: number;
  long: number;
  elevationFt: number;
  heading: number;
  lengthM: number;
  widthM: number;
}

/**
 * The FMS talks to this interface only. The local provider is the current
 * source; an OpenAIP provider and a Navigraph provider can be added without
 * touching the MCDU or the navdata backend.
 */
export interface NavDataProvider {
  readonly name: string;
  airports(): AirportInfo[];
  airport(ident: string): AirportInfo | undefined;
  waypoints(): Array<{ ident: string; lat: number; long: number }>;
  runways(airportIdent: string): RunwayInfo[];
  departures?(airportIdent: string): any[];
  arrivals?(airportIdent: string): any[];
  approaches?(airportIdent: string): any[];
}

const RUNWAYS: RunwayInfo[] = [
  // ZBAD / Beijing Daxing
  { ident: '01L', airportIdent: 'ZBAD', lat: 39.485, long: 116.395, elevationFt: 118, heading: 10, lengthM: 3800, widthM: 60 },
  { ident: '19R', airportIdent: 'ZBAD', lat: 39.545, long: 116.405, elevationFt: 118, heading: 190, lengthM: 3800, widthM: 60 },
  { ident: '01R', airportIdent: 'ZBAD', lat: 39.495, long: 116.435, elevationFt: 118, heading: 10, lengthM: 3800, widthM: 60 },
  { ident: '19L', airportIdent: 'ZBAD', lat: 39.555, long: 116.445, elevationFt: 118, heading: 190, lengthM: 3800, widthM: 60 },
  // ZBAA / Beijing Capital
  { ident: '18L', airportIdent: 'ZBAA', lat: 40.06, long: 116.56, elevationFt: 116, heading: 180, lengthM: 3800, widthM: 60 },
  { ident: '36R', airportIdent: 'ZBAA', lat: 40.10, long: 116.57, elevationFt: 116, heading: 360, lengthM: 3800, widthM: 60 },
  { ident: '18R', airportIdent: 'ZBAA', lat: 40.07, long: 116.61, elevationFt: 116, heading: 180, lengthM: 3200, widthM: 50 },
  { ident: '36L', airportIdent: 'ZBAA', lat: 40.10, long: 116.62, elevationFt: 116, heading: 360, lengthM: 3200, widthM: 50 },
  { ident: '01', airportIdent: 'ZBAA', lat: 40.10, long: 116.58, elevationFt: 116, heading: 10, lengthM: 3200, widthM: 50 },
  { ident: '19', airportIdent: 'ZBAA', lat: 40.14, long: 116.59, elevationFt: 116, heading: 190, lengthM: 3200, widthM: 50 },
  // LSGG / Geneva
  { ident: '04', airportIdent: 'LSGG', lat: 46.238, long: 6.109, elevationFt: 1411, heading: 40, lengthM: 3900, widthM: 50 },
  { ident: '22', airportIdent: 'LSGG', lat: 46.258, long: 6.129, elevationFt: 1411, heading: 220, lengthM: 3900, widthM: 50 },
];

export class LocalNavDataProvider implements NavDataProvider {
  readonly name = 'local';

  airports(): AirportInfo[] {
    return Object.entries(AIRPORT_SCENE).map(([ident, scene]) => ({
      ident,
      lat: WAYPOINT_DB[ident]?.lat ?? 0,
      long: WAYPOINT_DB[ident]?.long ?? 0,
      elevationFt: scene.elevationFt,
    }));
  }

  airport(ident: string): AirportInfo | undefined {
    const key = ident.toUpperCase();
    const point = WAYPOINT_DB[key];
    const scene = AIRPORT_SCENE[key];
    if (!point || !scene) return undefined;
    return { ident: key, lat: point.lat, long: point.long, elevationFt: scene.elevationFt };
  }

  waypoints(): Array<{ ident: string; lat: number; long: number }> {
    return Object.entries(WAYPOINT_DB).map(([ident, p]) => ({ ident, lat: p.lat, long: p.long }));
  }

  runways(airportIdent: string): RunwayInfo[] {
    return RUNWAYS.filter((r) => r.airportIdent === airportIdent.toUpperCase());
  }

  departures(airportIdent: string): any[] {
    if (airportIdent.toUpperCase() !== 'ZBAD') return [];
    return [sidObject('ZBAD', 'ZB1D', '01L', ['ZB01', 'ZB02'])];
  }

  arrivals(airportIdent: string): any[] {
    if (airportIdent.toUpperCase() !== 'ZBAA') return [];
    return [starObject('ZBAA', 'ZB2A', '18L', ['ZB02', 'ZB03'])];
  }

  approaches(airportIdent: string): any[] {
    if (airportIdent.toUpperCase() !== 'ZBAA') return [];
    return [approachObject('ZBAA', 'RNAV18L', '18L', 18) ];
  }
}

function fixObject(ident: string): any {
  const p = WAYPOINT_DB[ident];
  if (!p) return undefined;
  return {
    databaseId: ident,
    icaoCode: ident.slice(0, 2),
    ident,
    sectionCode: 2,
    subSectionCode: 0,
    area: 0,
    location: { lat: p.lat, long: p.long },
  };
}

function leg(procedureIdent: string, ident: string): any {
  return {
    procedureIdent,
    type: 'TF',
    overfly: false,
    waypoint: fixObject(ident),
    course: 0,
    magVar: 0,
  };
}

function sidObject(airport: string, ident: string, runway: string, fixes: string[]): any {
  const legs = fixes.map((f) => leg(ident, f));
  return {
    databaseId: `${airport}/${ident}`,
    icaoCode: airport.slice(0, 2),
    ident,
    sectionCode: 4,
    subSectionCode: 3,
    authorisationRequired: false,
    runwayTransitions: [{ databaseId: `${airport}/${ident}/${runway}`, ident: runway, legs }],
    commonLegs: [],
    enrouteTransitions: [{ databaseId: `${airport}/${ident}/ENR`, ident: fixes[fixes.length - 1], legs }],
  };
}

function starObject(airport: string, ident: string, runway: string, fixes: string[]): any {
  const legs = fixes.map((f) => leg(ident, f));
  return {
    databaseId: `${airport}/${ident}`,
    icaoCode: airport.slice(0, 2),
    ident,
    sectionCode: 4,
    subSectionCode: 4,
    authorisationRequired: false,
    enrouteTransitions: [{ databaseId: `${airport}/${ident}/ENR`, ident: fixes[0], legs }],
    commonLegs: [],
    runwayTransitions: [{ databaseId: `${airport}/${ident}/${runway}`, ident: runway, legs: [leg(ident, airport)] }],
  };
}

function approachObject(airport: string, ident: string, runway: string, runwayNumber: number): any {
  return {
    databaseId: `${airport}/${ident}`,
    icaoCode: airport.slice(0, 2),
    ident,
    sectionCode: 4,
    subSectionCode: 5,
    runwayIdent: runway,
    runwayNumber,
    runwayDesignator: 2,
    multipleIndicator: '',
    type: 12,
    authorisationRequired: false,
    missedApproachAuthorisationRequired: false,
    transitions: [],
    legs: [leg(ident, airport)],
    missedLegs: [],
  };
}

export const navData: NavDataProvider = new LocalNavDataProvider();

let activeProvider: NavDataProvider = navData;

export function getNavDataProvider(): NavDataProvider {
  return activeProvider;
}

export function setNavDataProvider(provider: NavDataProvider): void {
  activeProvider = provider;
}
