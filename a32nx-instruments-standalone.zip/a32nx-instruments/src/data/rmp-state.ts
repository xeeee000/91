/** RMP active/standby VHF1 frequencies in MHz. */
export const rmpState = {
  active: 118.7,
  standby: 121.5,
};
