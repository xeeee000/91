import { getNavDataProvider, RunwayInfo } from './navdata/provider';

function airportObject(ident: string): any {
  const airport = getNavDataProvider().airport(ident);
  if (!airport) return undefined;
  return {
    databaseId: airport.ident,
    icaoCode: airport.ident.slice(0, 2),
    ident: airport.ident,
    name: airport.ident,
    sectionCode: 4,
    subSectionCode: 0,
    location: { lat: airport.lat, long: airport.long, alt: airport.elevationFt },
  };
}

function waypointObject(ident: string, lat: number, long: number): any {
  return {
    databaseId: ident,
    icaoCode: ident.slice(0, 2),
    ident,
    sectionCode: 2,
    subSectionCode: 0,
    area: 0,
    location: { lat, long },
  };
}

function runwayObject(runway: RunwayInfo): any {
  const number = Number.parseInt(runway.ident, 10) || 0;
  const designator = runway.ident.endsWith('L') ? 2 : runway.ident.endsWith('R') ? 3 : 1;
  return {
    databaseId: `${runway.airportIdent}/${runway.ident}`,
    icaoCode: runway.airportIdent.slice(0, 2),
    ident: runway.ident,
    airportIdent: runway.airportIdent,
    sectionCode: 4,
    subSectionCode: 6,
    area: 0,
    number,
    designator,
    bearing: runway.heading,
    magneticBearing: runway.heading,
    gradient: 0,
    startLocation: { lat: runway.lat, long: runway.long },
    thresholdLocation: { lat: runway.lat, long: runway.long, alt: runway.elevationFt },
    thresholdCrossingHeight: 50,
    length: runway.lengthM,
    width: runway.widthM,
    lsIdent: '',
    magVar: 0,
  };
}

/**
 * Replaces the MSFS facility backend with the local/OpenAIP/Navigraph provider.
 * The MCDU/FMS sees the same API as the real navdata backend.
 */
export function installMiniNavdata(host: any): boolean {
  const backend = host?.fsInstrument?.legacyFms?.navigationDatabase?.backendDatabase?.backend;
  if (!backend || backend.__standaloneMiniNavdata) return !!backend;

  backend.getAirports = async (requested: string[]) =>
    requested.map((ident) => airportObject(ident.toUpperCase())).filter(Boolean);

  backend.getWaypoints = async (requested: string[]) =>
    requested
      .map((ident) => {
        const key = ident.toUpperCase();
        const p = getNavDataProvider().waypoints().find((w) => w.ident === key);
        return p ? waypointObject(key, p.lat, p.long) : undefined;
      })
      .filter(Boolean);

  backend.getRunways = async (airportIdent: string) => getNavDataProvider().runways(airportIdent).map(runwayObject);
  backend.getDepartures = async (airportIdent: string) => getNavDataProvider().departures?.(airportIdent) ?? [];
  backend.getArrivals = async (airportIdent: string) => getNavDataProvider().arrivals?.(airportIdent) ?? [];
  backend.getApproaches = async (airportIdent: string) => getNavDataProvider().approaches?.(airportIdent) ?? [];
  backend.getNavaids = async () => [];
  backend.getNDBs = async () => [];
  backend.getILSs = async () => [];
  backend.getAirways = async () => [];
  backend.__standaloneMiniNavdata = true;
  backend.__standaloneMiniIdents = getNavDataProvider().airports().map((a) => a.ident);

  return true;
}
