/** FCU selected targets and managed (push) states. */
export const fcuState = {
  speed: 250,
  heading: 45,
  altitude: 20000,
  verticalSpeed: 0,
  speedManaged: false,
  headingManaged: false,
  altitudeManaged: false,
};
