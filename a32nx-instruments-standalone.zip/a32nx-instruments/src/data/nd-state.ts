/** EFIS ND mode/range indices. Mode: ROSE_NAV=2, ARC=3, PLAN=4. */
export const ndState = {
  mode: 2, // ROSE_NAV
  range: 2, // 40 NM
};
