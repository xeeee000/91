﻿import { simVars } from '../harness/simvar-store';

export function publishClockState(phase: number): void {
  simVars.set('L:A32NX_ELEC_DC_ESS_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_HOT_1_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_OVHD_INTLT_ANN', 1);

  const now = new Date();
  const secondsOfDay = now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds() + (phase % 1);

  simVars.set('E:ABSOLUTE TIME', 63_900_000_000 + phase, 'seconds');
  simVars.set('E:ZULU TIME', secondsOfDay, 'seconds');
  simVars.set('E:ZULU DAY OF MONTH', now.getUTCDate());
  simVars.set('E:ZULU MONTH OF YEAR', now.getUTCMonth() + 1);
  simVars.set('E:ZULU YEAR', now.getUTCFullYear());
  simVars.set('E:TIME OF DAY', 1); // day
  simVars.set('L:A32NX_CHRONO_ET_SWITCH_POS', 0);
}

