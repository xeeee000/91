export interface OverheadState {
  bat1: boolean;
  bat2: boolean;
  extPwr: boolean;
  gen1: boolean;
  gen2: boolean;
  apuGen: boolean;
  busTie: boolean;
  apuMaster: boolean;
  apuStart: boolean;
  apuAvailable: boolean;
  eng1Master: boolean;
  eng2Master: boolean;
  eng1Start: boolean;
  eng2Start: boolean;
  eng1Running: boolean;
  eng2Running: boolean;
  eng1Fire: boolean;
  eng2Fire: boolean;
  apuFire: boolean;
  eng1Agent: boolean;
  eng2Agent: boolean;
  apuAgent: boolean;
  eng1Fail: boolean;
  eng2Fail: boolean;
  apuFail: boolean;
  cargoSmoke: boolean;
  pressFault: boolean;
  gearFail: boolean;
  elac1Fail: boolean;
  sec1Fail: boolean;
  fac1Fail: boolean;
  fuelLeakL: boolean;
  fuelLeakR: boolean;
  cabinDoor: boolean;
  cargoDoor: boolean;
  oxyFail: boolean;
  hotAirFault: boolean;
  navLights: boolean;
  beaconLights: boolean;
  strobeLights: boolean;
  landingLights: boolean;
  taxiLights: boolean;
  hydEng1: boolean;
  hydEng2: boolean;
  hydElec1: boolean;
  hydElec2: boolean;
  ptu: boolean;
  fuelL: boolean;
  fuelR: boolean;
  fuelC: boolean;
  xfeed: boolean;
  pack1: boolean;
  pack2: boolean;
  engBleed1: boolean;
  engBleed2: boolean;
  apuBleed: boolean;
  xbleed: boolean;
  pressAuto: boolean;
  wingAntiIce: boolean;
  engAntiIce1: boolean;
  engAntiIce2: boolean;
  adirs1: boolean;
  adirs2: boolean;
  adirs3: boolean;
  adirsAligned: boolean;
}

export const overhead: OverheadState = {
  bat1: false,
  bat2: false,
  extPwr: false,
  gen1: false,
  gen2: false,
  apuGen: false,
  busTie: true,
  apuMaster: false,
  apuStart: false,
  apuAvailable: false,
  eng1Master: false,
  eng2Master: false,
  eng1Start: false,
  eng2Start: false,
  eng1Running: false,
  eng2Running: false,
  eng1Fire: false,
  eng2Fire: false,
  apuFire: false,
  eng1Agent: false,
  eng2Agent: false,
  apuAgent: false,
  eng1Fail: false,
  eng2Fail: false,
  apuFail: false,
  cargoSmoke: false,
  pressFault: false,
  gearFail: false,
  elac1Fail: false,
  sec1Fail: false,
  fac1Fail: false,
  fuelLeakL: false,
  fuelLeakR: false,
  cabinDoor: false,
  cargoDoor: false,
  oxyFail: false,
  hotAirFault: false,
  navLights: false,
  beaconLights: false,
  strobeLights: false,
  landingLights: false,
  taxiLights: false,
  hydEng1: false,
  hydEng2: false,
  hydElec1: false,
  hydElec2: false,
  ptu: true,
  fuelL: false,
  fuelR: false,
  fuelC: false,
  xfeed: false,
  pack1: false,
  pack2: false,
  engBleed1: false,
  engBleed2: false,
  apuBleed: false,
  xbleed: false,
  pressAuto: true,
  wingAntiIce: false,
  engAntiIce1: false,
  engAntiIce2: false,
  adirs1: false,
  adirs2: false,
  adirs3: false,
  adirsAligned: false,
};

export type OverheadSwitch = keyof OverheadState;

export const channel = new BroadcastChannel('a32nx-overhead');

channel.onmessage = (event: MessageEvent) => {
  if (event.data?.type === 'power-request') publishOverhead();
};

export function derived() {
  const ac = overhead.extPwr || overhead.gen1 || overhead.gen2 || (overhead.apuGen && overhead.apuAvailable);
  const dc = overhead.bat1 || overhead.bat2 || ac;
  const hydGreen = ac && (overhead.hydEng1 || overhead.hydElec1);
  const hydBlue = ac && overhead.hydElec2;
  const hydYellow = ac && (overhead.hydEng2 || overhead.hydElec2);
  const fuelLeft = dc && overhead.fuelL;
  const fuelRight = dc && overhead.fuelR;
  const fuelCenter = dc && overhead.fuelC;
  const packs = ac && (overhead.pack1 || overhead.pack2);
  return { ac, dc, hydGreen, hydBlue, hydYellow, fuelLeft, fuelRight, fuelCenter, packs };
}

export function publishOverhead(): void {
  channel.postMessage({ state: { ...overhead }, derived: derived() });
}

export function resetColdDark(): void {
  Object.assign(overhead, {
    bat1: false, bat2: false, extPwr: false, gen1: false, gen2: false,
    apuGen: false, busTie: true, apuMaster: false, apuStart: false, apuAvailable: false,
    eng1Master: false, eng2Master: false, eng1Start: false, eng2Start: false, eng1Running: false, eng2Running: false,
    eng1Fire: false, eng2Fire: false, apuFire: false, eng1Agent: false, eng2Agent: false, apuAgent: false,
    eng1Fail: false, eng2Fail: false, apuFail: false, cargoSmoke: false, pressFault: false, gearFail: false, elac1Fail: false, sec1Fail: false, fac1Fail: false, fuelLeakL: false, fuelLeakR: false, cabinDoor: false, cargoDoor: false, oxyFail: false, hotAirFault: false,
    navLights: false, beaconLights: false, strobeLights: false, landingLights: false, taxiLights: false,
    adirs1: false, adirs2: false, adirs3: false, adirsAligned: false,
    hydEng1: false, hydEng2: false, hydElec1: false, hydElec2: false, ptu: true,
    fuelL: false, fuelR: false, fuelC: false, xfeed: false,
    pack1: false, pack2: false, engBleed1: false, engBleed2: false,
    apuBleed: false, xbleed: false, pressAuto: true,
    wingAntiIce: false, engAntiIce1: false, engAntiIce2: false,
    adirs1: false, adirs2: false, adirs3: false,
  });
  publishOverhead();
}
