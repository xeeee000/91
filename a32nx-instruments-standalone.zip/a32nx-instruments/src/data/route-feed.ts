import { flight } from './pfd-feed';
import { RoutePoint } from './waypoints';

/**
 * Demo FMS route injected into the original ND through the same
 * RegisterGenericDataListener/EB_EVENTS channel the real FMS uses.
 * DIR TO advances routeState.activeIndex, dropping the passed waypoints.
 */
const ROUTE = [
  { ident: 'WP01', lat: 46.32, long: 6.22 },
  { ident: 'WP02', lat: 46.42, long: 6.42 },
  { ident: 'WP03', lat: 46.54, long: 6.66 },
  { ident: 'WP04', lat: 46.66, long: 6.9 },
];

export const routeState: { activeIndex: number; custom: RoutePoint[] } = {
  activeIndex: 0,
  custom: [],
};
export const ROUTE_LENGTH = ROUTE.length;

const WAYPOINT_FLAG = 1 << 3; // NdSymbolTypeFlags.Waypoint
const FLIGHT_PLAN_FLAG = 1 << 12; // NdSymbolTypeFlags.FlightPlan

let packagedId = 0;

export function publishRoute(): void {
  const listeners = ((globalThis as any).__A32NX_GENERIC_DATA_LISTENERS__ ?? []) as Array<{
    send: (key: string, data: unknown) => void;
  }>;
  if (listeners.length === 0) return;

  const route = routeState.custom.length > 0 ? routeState.custom : ROUTE;
  const active = route.slice(routeState.activeIndex);
  if (active.length === 0) return;

  const symbols = active.map((wp) => ({
    databaseId: wp.ident,
    ident: wp.ident,
    location: { lat: wp.lat, long: wp.long },
    type: WAYPOINT_FLAG | FLIGHT_PLAN_FLAG,
  }));

  const vectors: Array<{ type: number; startPoint: { lat: number; long: number }; endPoint: { lat: number; long: number } }> = [
    {
      type: 0,
      startPoint: { lat: flight.latitude, long: flight.longitude },
      endPoint: { lat: active[0].lat, long: active[0].long },
    },
  ];
  for (let i = 1; i < active.length; i++) {
    vectors.push({
      type: 0,
      startPoint: { lat: active[i - 1].lat, long: active[i - 1].long },
      endPoint: { lat: active[i].lat, long: active[i].long },
    });
  }

  const payload = {
    packagedId: ++packagedId,
    data: [
      { topic: 'A32NX_EFIS_L_SYMBOLS', data: symbols },
      { topic: 'A32NX_EFIS_VECTORS_L_ACTIVE', data: vectors },
      { topic: 'A32NX_EFIS_VECTORS_L_DASHED', data: [] },
    ],
  };

  for (const listener of listeners) listener.send('EB_EVENTS', payload);
}
