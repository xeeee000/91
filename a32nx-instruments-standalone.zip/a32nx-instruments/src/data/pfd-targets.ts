/** FCU selected targets shown as PFD bugs / readouts. */
export const pfdTargets = {
  speed: 250,
  altitude: 20000,
};
