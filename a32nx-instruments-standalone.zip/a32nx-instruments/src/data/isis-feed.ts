import { simVars } from '../harness/simvar-store';

export const isisFlight = {
  ias: 250,
  altitude: 12000,
  pitch: 2.5,
  roll: 0,
  mach: 0.48,
};

export function publishIsisState(): void {
  simVars.set('L:A32NX_COLD_AND_DARK_SPAWN', 0);
  simVars.set('L:A32NX_ELEC_DC_ESS_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_ELEC_DC_HOT_1_BUS_IS_POWERED', 1, 'bool');
  simVars.set('L:A32NX_AIRCRAFT_PRESET_QUICK_MODE', 1, 'bool');

  simVars.set('AIRSPEED INDICATED', isisFlight.ias, 'knots');
  simVars.set('INDICATED ALTITUDE:3', isisFlight.altitude, 'feet');
  simVars.set('PLANE PITCH DEGREES', isisFlight.pitch, 'degrees');
  simVars.set('PLANE BANK DEGREES', isisFlight.roll, 'degrees');
  simVars.set('AIRSPEED MACH', isisFlight.mach, 'mach');
  simVars.set('ACCELERATION BODY X', 0, 'G Force');
  simVars.set('GLASSCOCKPIT AUTOMATIC BRIGHTNESS', 1);

  simVars.set('A:KOHLSMAN SETTING MB:3', 1013, 'millibars');
  simVars.set('L:A32NX_ISIS_BARO_MODE', 0);
  simVars.set('L:A32NX_ISIS_BUGS_ACTIVE', 0, 'bool');
  simVars.set('L:A32NX_ISIS_LS_ACTIVE', 0, 'bool');
  simVars.set('L:A32NX_ISIS_MANUAL_BRIGHTNESS_OFFSET', 0);
  simVars.set('L:AIRLINER_MINIMUM_DESCENT_ALTITUDE', 0, 'feet');

  simVars.set('L:A32NX_RADIO_RECEIVER_GS_IS_VALID', 0);
  simVars.set('L:A32NX_RADIO_RECEIVER_GS_DEVIATION', 0);
  simVars.set('L:A32NX_RADIO_RECEIVER_LOC_IS_VALID', 0);
  simVars.set('L:A32NX_RADIO_RECEIVER_LOC_DEVIATION', 0);
}
