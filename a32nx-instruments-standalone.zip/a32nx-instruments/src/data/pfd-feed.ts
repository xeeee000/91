import { Arinc429SignStatusMatrix, Arinc429Word } from '../sdk/fbw-sdk';
import { simVars } from '../harness/simvar-store';
import { PFDVars } from '../../vendor/fbw-a32nx/src/systems/instruments/src/PFD/shared/PFDSimvarPublisher';
import { fmaDiscreteWords, fmaState } from './fma-state';
import { approachState } from './approach-state';
import { pfdTargets } from './pfd-targets';

const NORMAL = Arinc429SignStatusMatrix.NormalOperation;

export function word(value: number): number {
  return Arinc429Word.getRawWord(value, NORMAL);
}

export interface FlightState {
  pitch: number;
  roll: number;
  heading: number;
  track: number;
  altitude: number;
  radioAltitude: number;
  ias: number;
  mach: number;
  tas: number;
  groundSpeed: number;
  verticalSpeed: number;
  latitude: number;
  longitude: number;
  baroSetting: number;
}

export const flight: FlightState = {
  pitch: 2.5,
  roll: 0,
  heading: 45,
  track: 45,
  altitude: 12000,
  radioAltitude: 0,
  ias: 250,
  mach: 0.48,
  tas: 280,
  groundSpeed: 260,
  verticalSpeed: 0,
  latitude: 46.238,
  longitude: 6.109,
  baroSetting: 1013,
};

(globalThis as any).__A32NX_FLIGHT__ = flight;

/** Write a value that the original PFD consumes as a raw ARINC 429 word. */
function setWord(name: string, value: number): void {
  simVars.set(name, word(value));
}

function setBool(name: string, value: boolean): void {
  simVars.set(name, value ? 1 : 0, 'bool');
}

export function publishPfdState(): void {
  // Generic MSFS variables used by the original ND map/aircraft symbol.
  simVars.set('PLANE LATITUDE', flight.latitude, 'degrees');
  simVars.set('PLANE LONGITUDE', flight.longitude, 'degrees');
  simVars.set('PLANE ALTITUDE', flight.altitude, 'feet');
  simVars.set('PLANE HEADING DEGREES MAGNETIC', flight.heading, 'degrees');
  simVars.set('PLANE HEADING DEGREES TRUE', flight.heading, 'degrees');
  simVars.set('AIRSPEED INDICATED', flight.ias, 'knots');
  simVars.set('AIRSPEED TRUE', flight.tas, 'knots');
  simVars.set('GROUND VELOCITY', flight.groundSpeed, 'knots');
  simVars.set('VERTICAL SPEED', flight.verticalSpeed, 'feet per minute');
  simVars.set('PLANE PITCH DEGREES', flight.pitch, 'degrees');
  simVars.set('PLANE BANK DEGREES', flight.roll, 'degrees');

  // ---- display power / brightness ----
  simVars.set(PFDVars.coldDark, 0);
  setBool(PFDVars.elec, true);
  setBool(PFDVars.elecFo, true);
  simVars.set(PFDVars.potentiometerCaptain, 0.85);
  simVars.set(PFDVars.potentiometerFo, 0.85);

  // ---- ADIRS IR ----
  for (const src of [1, 2, 3]) {
    setWord(`L:A32NX_ADIRS_IR_${src}_PITCH`, flight.pitch);
    setWord(`L:A32NX_ADIRS_IR_${src}_ROLL`, flight.roll);
    setWord(`L:A32NX_ADIRS_IR_${src}_HEADING`, flight.heading);
    setWord(`L:A32NX_ADIRS_IR_${src}_TRACK`, flight.track);
    setWord(`L:A32NX_ADIRS_IR_${src}_TRUE_HEADING`, flight.heading);
    setWord(`L:A32NX_ADIRS_IR_${src}_TRUE_TRACK`, flight.track);
    setWord(`L:A32NX_ADIRS_IR_${src}_VERTICAL_SPEED`, flight.verticalSpeed);
    setWord(`L:A32NX_ADIRS_IR_${src}_GROUND_SPEED`, flight.groundSpeed);
    setWord(`L:A32NX_ADIRS_IR_${src}_FLIGHT_PATH_ANGLE`, 0);
    setWord(`L:A32NX_ADIRS_IR_${src}_DRIFT_ANGLE`, 0);
    setWord(`L:A32NX_ADIRS_IR_${src}_BODY_LATERAL_ACC`, 0);
    setWord(`L:A32NX_ADIRS_IR_${src}_MAINT_WORD`, 0);
    setWord(`L:A32NX_ADIRS_IR_${src}_LATITUDE`, flight.latitude);
    setWord(`L:A32NX_ADIRS_IR_${src}_LONGITUDE`, flight.longitude);
    setWord(`L:A32NX_ADIRS_IR_${src}_WIND_SPEED_BNR`, 0);
    setWord(`L:A32NX_ADIRS_IR_${src}_WIND_DIRECTION_BNR`, 0);
  }

  // ---- ADIRS ADR ----
  for (const src of [1, 2, 3]) {
    setWord(`L:A32NX_ADIRS_ADR_${src}_ALTITUDE`, flight.altitude);
    setWord(`L:A32NX_ADIRS_ADR_${src}_COMPUTED_AIRSPEED`, flight.ias);
    setWord(`L:A32NX_ADIRS_ADR_${src}_MACH`, flight.mach);
    setWord(`L:A32NX_ADIRS_ADR_${src}_BAROMETRIC_VERTICAL_SPEED`, flight.verticalSpeed);
    setWord(`L:A32NX_ADIRS_ADR_${src}_TRUE_AIRSPEED`, flight.tas);
    setWord(`L:A32NX_ADIRS_ADR_${src}_STATIC_AIR_TEMPERATURE`, 15);
    setWord(`L:A32NX_ADIRS_ADR_${src}_TOTAL_AIR_TEMPERATURE`, 17);
    setWord(`L:A32NX_ADIRS_ADR_${src}_BARO_CORRECTED_ALTITUDE_1`, flight.altitude);
    setWord(`L:A32NX_ADIRS_ADR_${src}_BARO_CORRECTED_ALTITUDE_2`, flight.altitude);
  }

  // ---- radio altimeters ----
  setWord(PFDVars.radioAltitude1, flight.radioAltitude);
  setWord(PFDVars.radioAltitude2, flight.radioAltitude);

  // ---- landing gear / flight phase ----
  setBool(PFDVars.noseGearCompressed, flight.radioAltitude < 10);
  setBool(PFDVars.leftMainGearCompressed, flight.radioAltitude < 10);
  setBool(PFDVars.rightMainGearCompressed, flight.radioAltitude < 10);
  simVars.set(PFDVars.fwcFlightPhase, 3);
  simVars.set(PFDVars.fmgcFlightPhase, 3);
  simVars.set(PFDVars.attHdgKnob, 0);
  simVars.set(PFDVars.airKnob, 0);
  simVars.set(PFDVars.flapHandleIndex, 0);
  simVars.set(PFDVars.slatPosLeft, 0);
  simVars.set(PFDVars.aoa, 2);
  simVars.set(PFDVars.v1, 140, 'knots');
  simVars.set(PFDVars.vr, 145, 'knots');

  // ---- engine / thrust ----
  simVars.set(PFDVars.tla1, 0);
  simVars.set(PFDVars.tla2, 0);
  setBool(PFDVars.engOneRunning, true);
  setBool(PFDVars.engTwoRunning, true);
  simVars.set(PFDVars.flexTemp, 0);

  // ---- FCU selected values ----
  setWord(PFDVars.fcuSelectedHeadingRaw, flight.heading);
  setWord(PFDVars.fcuSelectedAltitudeRaw, pfdTargets.altitude);
  setWord(PFDVars.fcuSelectedAirspeedRaw, pfdTargets.speed);
  setWord(PFDVars.fcuSelectedVerticalSpeedRaw, 0);
  setWord(PFDVars.fcuSelectedTrackRaw, flight.track);
  setWord(PFDVars.fcuSelectedFpaRaw, 0);
  setWord(PFDVars.fcuAtsDiscreteWordRaw, 0);
  setWord(PFDVars.fcuAtsFmaDiscreteWordRaw, 0);
  setWord(PFDVars.fcuEisLeftDiscreteWord1Raw, 0);
  setWord(PFDVars.fcuEisLeftDiscreteWord2Raw, 0);
  setWord(PFDVars.fcuEisLeftBaroRaw, flight.baroSetting);
  setWord(PFDVars.fcuEisLeftBaroHpaRaw, flight.baroSetting);
  setWord(PFDVars.fcuEisRightDiscreteWord1Raw, 0);
  setWord(PFDVars.fcuEisRightDiscreteWord2Raw, 0);
  setWord(PFDVars.fcuEisRightBaroRaw, flight.baroSetting);
  setWord(PFDVars.fcuEisRightBaroHpaRaw, flight.baroSetting);
  setWord(PFDVars.fcuDiscreteWord1Raw, 0);
  setWord(PFDVars.fcuDiscreteWord2Raw, 0);

  // ---- FAC (speed tape protections / targets) ----
  setBool(PFDVars.fac1Healthy, true);
  setBool(PFDVars.fac2Healthy, true);
  const facWords: Array<[string, number]> = [
    [PFDVars.fac1VAlphaProtRaw, 120],
    [PFDVars.fac1VAlphaMaxRaw, 115],
    [PFDVars.fac1VStallWarnRaw, 110],
    [PFDVars.fac1VMaxRaw, 340],
    [PFDVars.fac1VFeNextRaw, 230],
    [PFDVars.fac1VManRaw, 250],
    [PFDVars.fac1V4Raw, 145],
    [PFDVars.fac1V3Raw, 140],
    [PFDVars.fac1VLsRaw, 130],
    [PFDVars.fac1VCTrendRaw, 0],
    [PFDVars.fac1EstimatedBetaRaw, 0],
    [PFDVars.fac1BetaTargetRaw, 0],
    [PFDVars.fac2VAlphaProtRaw, 120],
    [PFDVars.fac2VAlphaMaxRaw, 115],
    [PFDVars.fac2VStallWarnRaw, 110],
    [PFDVars.fac2VMaxRaw, 340],
    [PFDVars.fac2VFeNextRaw, 230],
    [PFDVars.fac2VManRaw, 250],
    [PFDVars.fac2V4Raw, 145],
    [PFDVars.fac2V3Raw, 140],
    [PFDVars.fac2VLsRaw, 130],
    [PFDVars.fac2VCTrendRaw, 0],
    [PFDVars.fac2EstimatedBetaRaw, 0],
    [PFDVars.fac2BetaTargetRaw, 0],
  ];
  for (const [name, value] of facWords) setWord(name, value);

  // ---- FCDC / FMGC / FM ----
  // Managed-speed AP/FD modes, driven by fmaState (HDG/NAV/APP, ALT/VS/CLB).
  const fma = fmaDiscreteWords(flight.radioAltitude);
  setWord('L:A32NX_FMGC_1_DISCRETE_WORD_1', fma.w1);
  setWord('L:A32NX_FMGC_1_DISCRETE_WORD_2', fma.w2);
  setWord('L:A32NX_FMGC_1_DISCRETE_WORD_3', fma.w3);
  setWord('L:A32NX_FMGC_1_DISCRETE_WORD_4', fma.w4);
  setWord('L:A32NX_FMGC_2_DISCRETE_WORD_4', 0);
  setWord('L:A32NX_FCU_ATS_DISCRETE_WORD', (1 << 12) | (1 << 13));
  setWord('L:A32NX_FCU_ATS_FMA_DISCRETE_WORD', 1 << 18);

  // Bit 11 announces a healthy normal-law FCDC (without it the FMA shows the
  // direct-law "MAN PITCH TRIM ONLY" reconfiguration message).
  setWord(PFDVars.fcdc1DiscreteWord1Raw, 1 << 10);
  setWord(PFDVars.fcdc2DiscreteWord1Raw, 1 << 10);
  setWord(PFDVars.fcdc1DiscreteWord2Raw, 0);
  setWord(PFDVars.fcdc2DiscreteWord2Raw, 0);
  setWord(PFDVars.fcdc1CaptPitchCommandRaw, 0);
  setWord(PFDVars.fcdc2CaptPitchCommandRaw, 0);
  setWord(PFDVars.fcdc1FoPitchCommandRaw, 0);
  setWord(PFDVars.fcdc2FoPitchCommandRaw, 0);
  setWord(PFDVars.fcdc1CaptRollCommandRaw, 0);
  setWord(PFDVars.fcdc2CaptRollCommandRaw, 0);
  setWord(PFDVars.fcdc1FoRollCommandRaw, 0);
  setWord(PFDVars.fcdc2FoRollCommandRaw, 0);

  setWord(PFDVars.irMaintWordRaw, 0);
  setWord(PFDVars.fm1TransAltRaw, 5000);
  setWord(PFDVars.fm2TransAltRaw, 5000);
  setWord(PFDVars.fm1TransLvlRaw, 18000);
  setWord(PFDVars.fm2TransLvlRaw, 18000);
  setWord(PFDVars.fm1MdaRaw, 0);
  setWord(PFDVars.fm2MdaRaw, 0);
  setWord(PFDVars.fm1DhRaw, 0);
  setWord(PFDVars.fm2DhRaw, 0);
  simVars.set(PFDVars.fm1HealthyDiscrete, 0);
  simVars.set(PFDVars.fm2HealthyDiscrete, 0);
  setWord(PFDVars.landingElevation1Raw, 0);
  setWord(PFDVars.landingElevation2Raw, 0);

  // ---- radio nav (ILS valid only in APP mode, small deviations for the diamonds) ----
  const onApproach = fmaState.lateral === 'APP';
  // EFIS LS button (FCU EIS discrete word 2, bit 22) makes the PFD show the
  // localizer / glide-slope scales.
  setWord(PFDVars.fcuEisLeftDiscreteWord2Raw, onApproach ? 1 << 21 : 0);
  setBool(PFDVars.hasLoc, onApproach);
  setBool(PFDVars.hasGlideslope, onApproach);
  simVars.set(PFDVars.navRadialError, onApproach ? approachState.locDeviation : 0, 'degrees');
  simVars.set(PFDVars.glideSlopeError, onApproach ? approachState.gsDeviation : 0, 'degrees');
  setBool(PFDVars.hasDme, false);
  simVars.set(PFDVars.navIdent, 'ILS', 'string');
  simVars.set(PFDVars.navFreq, 110.3, 'mhz');
  simVars.set(PFDVars.dme, 0, 'nm');
  simVars.set(PFDVars.markerBeacon, 0);
  simVars.set(PFDVars.ilsCourse, flight.heading);

  // ---- misc PFD messages ----
  setBool(PFDVars.setHoldSpeed, false);
  setBool(PFDVars.tdReached, false);
  setBool(PFDVars.checkSpeedMode, false);
  simVars.set(PFDVars.autoBrakeMode, 0);
  setBool(PFDVars.autoBrakeActive, false);
  setBool(PFDVars.autoBrakeDecel, false);
}
