export type LateralMode = 'HDG' | 'NAV' | 'APP';
export type VerticalMode = 'ALT' | 'VS' | 'CLB' | 'SRS';

/** Mutable FMA mode state, updated from the cockpit control panel. */
export const fmaState = {
  lateral: 'HDG' as LateralMode,
  vertical: 'ALT' as VerticalMode,
  ap: true,
  athr: true,
};

/**
 * Pack the FMGC discrete words consumed by the PFD FMA:
 *  word1: vertical modes (ALT / V/S / CLB / G/S)
 *  word2: lateral modes (HDG / NAV / LOC)
 *  word3: armed modes (NAV)
 *  word4: AP / FD engagement
 */
export function fmaDiscreteWords(radioAltitude = 0): { w1: number; w2: number; w3: number; w4: number } {
  let w1 = 0;
  let w2 = 0;
  let w3 = 0;
  let w4 = 0;

  if (fmaState.lateral === 'APP') {
    if (radioAltitude <= 5) {
      // ROLL OUT
      w2 |= 1 << 25; // roll-out active (bit 26)
      w4 |= 1 << 13; // LAND active (bit 14)
    } else if (radioAltitude <= 100) {
      // FLARE
      w1 |= 1 << 24; // flare active (bit 25)
      w4 |= 1 << 13; // LAND active (bit 14)
    } else {
      // G/S track + capture / LOC capture.
      w1 |= 1 << 19; // G/S track (bit 20)
      w1 |= 1 << 21; // G/S active (bit 22)
      w2 |= 1 << 12; // LOC capture (bit 13)
      w3 |= 1 << 13; // NAV armed (bit 14)
      if (radioAltitude <= 100) w4 |= 1 << 13; // LAND armed/active
    }
  } else {
    if (fmaState.lateral === 'HDG') w2 |= 1 << 15; // heading (bit 16)
    if (fmaState.lateral === 'NAV') {
      w2 |= 1 << 11; // NAV active (bit 12)
      w3 |= 1 << 13; // NAV armed (bit 14)
    }

    if (fmaState.vertical === 'ALT') {
      w1 |= 1 << 18; // ALT mode (bit 19)
      w1 |= 1 << 19; // track mode (bit 20)
    } else if (fmaState.vertical === 'VS') {
      w1 |= 1 << 16; // V/S mode (bit 17)
    } else if (fmaState.vertical === 'CLB') {
      w1 |= 1 << 10; // CLB mode (bit 11)
    } else if (fmaState.vertical === 'SRS') {
      w1 |= 1 << 14; // SRS (pitch takeoff mode, bit 15)
    }
  }

  if (fmaState.ap) w4 |= 1 << 11; // AP1 engaged (bit 12)
  w4 |= 1 << 12; // FD1 engaged (bit 13)

  return { w1, w2, w3, w4 };
}
