import { simVars } from '../harness/simvar-store';
import { word } from './pfd-feed';
import { engineParams, engineState } from './engine-state';
import { systemsState, hydPressures } from './systems-state';

const bool = (name: string, value: boolean): void => simVars.set(name, value ? 1 : 0, 'bool');
const num = (name: string, value: number, unit = 'number'): void => simVars.set(name, value, unit);

/**
 * Minimal, healthy aircraft systems model for the ECAM SD pages.
 * It is not a full electrical/hydraulic/fuel simulation; it provides the
 * steady-state values the original SD pages need in order to display a
 * realistic "all systems normal" picture.
 */
export function publishSystemsState(): void {
  publishElectrical();
  publishHydraulic();
  publishFuel();
  publishApu();
  publishBleed();
  publishLights();
}

function publishLights(): void {
  bool('LIGHT NAV', systemsState.navLights);
  bool('LIGHT BEACON', systemsState.beaconLights);
  bool('LIGHT STROBE', systemsState.strobeLights);
  bool('LIGHT LANDING', systemsState.landingLights);
  bool('LIGHT TAXI', systemsState.taxiLights);
}

function publishBleed(): void {
  const xbleed = systemsState.xbleed;
  bool('L:A32NX_PNEU_XBLEED_VALVE_FULLY_OPEN', xbleed);
  bool('L:A32NX_PNEU_XBLEED_VALVE_FULLY_CLOSED', !xbleed);
  bool('L:A32NX_OVHD_PNEU_ENG_1_BLEED_PB_IS_AUTO', systemsState.engBleed1);
  bool('L:A32NX_OVHD_PNEU_ENG_2_BLEED_PB_IS_AUTO', systemsState.engBleed2);
  bool('L:A32NX_PNEU_ENG_1_PR_VALVE_OPEN', systemsState.engBleed1 && systemsState.eng1Running);
  bool('L:A32NX_PNEU_ENG_2_PR_VALVE_OPEN', systemsState.engBleed2 && systemsState.eng2Running);
  bool('L:A32NX_PNEU_WING_ANTI_ICE_SYSTEM_ON', systemsState.wingAntiIce);
  bool('L:A32NX_AIRCOND_RAMAIR_TOGGLE', false);
  num('L:A32NX_PNEU_WING_ANTI_ICE_GROUND_TIMER', 0);
}

function publishApu(): void {
  const on = systemsState.apuMaster;
  const avail = systemsState.apuAvailable;
  bool('L:A32NX_OVHD_APU_MASTER_SW_PB_IS_ON', on);
  bool('L:A32NX_OVHD_APU_START_PB_IS_AVAILABLE', avail);
  bool('L:A32NX_ELEC_CONTACTOR_3XS_IS_CLOSED', avail && systemsState.apuGen);
  bool('A:APU GENERATOR SWITCH', systemsState.apuGen);
  bool('L:A32NX_APU_AVAILABLE', avail);
  bool('L:A32NX_APU_STARTING', on && !avail);
  simVars.set('L:A32NX_APU_N', word(avail ? 100 : on ? 45 : 0));
  simVars.set('L:A32NX_APU_EGT', word(avail ? 420 : on ? 320 : 0));
  simVars.set('L:A32NX_APU_EGT_CAUTION', word(650));
  simVars.set('L:A32NX_APU_EGT_WARNING', word(900));
  num('L:A32NX_APU_FUEL_FLOW', avail ? 120 : on ? 80 : 0, 'kilograms per hour');
  simVars.set('L:A32NX_ADIRS_ADR_3_CORRECTED_AVERAGE_STATIC_PRESSURE', word(14.7));
  bool('L:A32NX_OVHD_PNEU_APU_BLEED_PB_IS_ON', systemsState.apuBleed);
  const bleedOn = systemsState.apuBleed && avail;
  bool('L:A32NX_APU_BLEED_AIR_VALVE_OPEN', bleedOn);
  num('L:A32NX_PNEU_APU_BLEED_CONTAINER_PRESSURE', bleedOn ? 59.7 : 14.7, 'psi');
}

function publishElectrical(): void {
  const buses = [
    'AC_1',
    'AC_2',
    'AC_ESS',
    'AC_ESS_SHED',
    'DC_1',
    'DC_2',
    'DC_ESS',
    'DC_ESS_SHED',
    'DC_BAT',
  ];
  for (const bus of buses) bool(`L:A32NX_ELEC_${bus}_BUS_IS_POWERED`, true);

  const closedContactors = [
    '3XC1',
    '3XC2',
    '15XE1',
    '15XE2',
    '11XU1',
    '11XU2',
    '1PC1',
    '1PC2',
    '4PC',
    '5PU1',
    '5PU2',
    '3PE',
    '9XU1',
    '9XU2',
    '6PB1',
    '6PB2',
  ];
  for (const contactor of closedContactors) bool(`L:A32NX_ELEC_CONTACTOR_${contactor}_IS_CLOSED`, true);
  for (const contactor of ['3XS', '2XE', '3XG']) bool(`L:A32NX_ELEC_CONTACTOR_${contactor}_IS_CLOSED`, false);

  for (const gen of [1, 2]) {
    const on = gen === 1 ? systemsState.gen1 : systemsState.gen2;
    num(`L:A32NX_ELEC_ENG_GEN_${gen}_POTENTIAL`, on ? 115 : 0, 'volts');
    num(`L:A32NX_ELEC_ENG_GEN_${gen}_FREQUENCY`, on ? 400 : 0, 'hertz');
    num(`L:A32NX_ELEC_ENG_GEN_${gen}_LOAD`, on ? 45 : 0, 'percent');
    bool(`L:A32NX_ELEC_ENG_GEN_${gen}_LOAD_NORMAL`, on);
    bool(`L:A32NX_ELEC_ENG_GEN_${gen}_IDG_IS_CONNECTED`, on);
    num(`L:A32NX_ELEC_ENG_GEN_${gen}_IDG_OIL_OUTLET_TEMPERATURE`, on ? 70 : 0, 'celsius');
    bool(`GENERAL ENG MASTER ALTERNATOR:${gen}`, on);
    bool(`L:A32NX_ELEC_CONTACTOR_6PB${gen}_IS_CLOSED`, on);
    bool(`L:A32NX_ELEC_CONTACTOR_9XU${gen}_IS_CLOSED`, on);
  }

  for (const bat of [1, 2]) {
    num(`L:A32NX_ELEC_BAT_${bat}_CURRENT`, 12, 'amperes');
    bool(`L:A32NX_ELEC_BAT_${bat}_CURRENT_NORMAL`, true);
    num(`L:A32NX_ELEC_BAT_${bat}_POTENTIAL`, 28, 'volts');
    bool(`L:A32NX_ELEC_BAT_${bat}_POTENTIAL_NORMAL`, true);
    bool(`L:A32NX_OVHD_ELEC_BAT_${bat}_PB_IS_AUTO`, true);
  }

  for (const tr of [1, 2, 3]) {
    num(`L:A32NX_ELEC_TR_${tr}_CURRENT`, 80, 'amperes');
    bool(`L:A32NX_ELEC_TR_${tr}_CURRENT_NORMAL`, true);
    num(`L:A32NX_ELEC_TR_${tr}_POTENTIAL`, 28, 'volts');
    bool(`L:A32NX_ELEC_TR_${tr}_POTENTIAL_NORMAL`, true);
  }

  const apuGenOn = systemsState.apuGen && systemsState.apuAvailable;
  num('L:A32NX_ELEC_APU_GEN_1_POTENTIAL', apuGenOn ? 115 : 0, 'volts');
  num('L:A32NX_ELEC_APU_GEN_1_FREQUENCY', apuGenOn ? 400 : 0, 'hertz');
  num('L:A32NX_ELEC_APU_GEN_1_LOAD', apuGenOn ? 20 : 0, 'percent');
  bool('L:A32NX_ELEC_APU_GEN_1_LOAD_NORMAL', apuGenOn);
  bool('L:A32NX_ELEC_APU_GEN_1_FREQUENCY_NORMAL', apuGenOn);
  bool('L:A32NX_ELEC_APU_GEN_1_POTENTIAL_NORMAL', apuGenOn);
  bool('L:A32NX_OVHD_APU_MASTER_SW_PB_IS_ON', systemsState.apuMaster);
  bool('APU GENERATOR SWITCH:1', systemsState.apuGen);

  num('L:A32NX_ELEC_EMER_GEN_POTENTIAL', 115, 'volts');
  num('L:A32NX_ELEC_EMER_GEN_FREQUENCY', 400, 'hertz');
  bool('L:A32NX_ELEC_EMER_GEN_POTENTIAL_NORMAL', true);
  bool('L:A32NX_ELEC_EMER_GEN_FREQUENCY_NORMAL', true);

  num('L:A32NX_ELEC_STAT_INV_POTENTIAL', 115, 'volts');
  num('L:A32NX_ELEC_STAT_INV_FREQUENCY', 400, 'hertz');
  bool('L:A32NX_ELEC_STAT_INV_POTENTIAL_NORMAL', true);
  bool('L:A32NX_ELEC_STAT_INV_FREQUENCY_NORMAL', true);

  bool('L:A32NX_EXT_PWR_AVAIL:1', false);
  bool('L:A32NX_ELEC_GALLEY_IS_SHED', false);
  bool('L:A32NX_ELEC_DC_BAT_BUS_POTENTIAL_NORMAL', true);
}

function publishHydraulic(): void {
  const n2 = engineParams().n2;

  for (const system of ['GREEN', 'BLUE', 'YELLOW']) {
    const pressure =
      system === 'GREEN' ? hydPressures.green : system === 'BLUE' ? hydPressures.blue : hydPressures.yellow;
    const pressurised = pressure > 100;
    num(`L:A32NX_HYD_${system}_SYSTEM_1_SECTION_PRESSURE`, pressure, 'psi');
    num(`L:A32NX_HYD_${system}_RESERVOIR_LEVEL`, 5, 'gallon');
    bool(`L:A32NX_HYD_${system}_RESERVOIR_LEVEL_IS_LOW`, false);
    bool(`L:A32NX_HYD_${system}_RESERVOIR_OVHT`, false);
    bool(`L:A32NX_HYD_${system}_RESERVOIR_AIR_PRESSURE_IS_LOW`, false);
    bool(`L:A32NX_HYD_${system}_SYSTEM_1_SECTION_PRESSURE_SWITCH`, pressurised);
    bool(`L:A32NX_HYD_${system}_PUMP_1_SECTION_PRESSURE_SWITCH`, pressurised);
  }

  num('TURB ENG N2:1', n2, 'percent');
  num('TURB ENG N2:2', n2, 'percent');

  bool('L:A32NX_OVHD_HYD_ENG_1_PUMP_PB_IS_AUTO', true);
  bool('L:A32NX_OVHD_HYD_ENG_2_PUMP_PB_IS_AUTO', true);
  bool('L:A32NX_OVHD_HYD_EPUMPB_PB_IS_AUTO', true);
  bool('L:A32NX_HYD_GREEN_PUMP_1_FIRE_VALVE_OPENED', false);
  bool('L:A32NX_HYD_YELLOW_PUMP_1_FIRE_VALVE_OPENED', false);
  bool('L:A32NX_HYD_GREEN_PUMP_1_SECTION_PRESSURE_SWITCH', hydPressures.green > 100);
  bool('L:A32NX_HYD_YELLOW_PUMP_1_SECTION_PRESSURE_SWITCH', hydPressures.yellow > 100);
  bool('L:A32NX_HYD_BLUE_EPUMP_ACTIVE', hydPressures.blue > 100);
  bool('L:A32NX_HYD_BLUE_EPUMP_OVHT', false);
  bool('L:A32NX_HYD_YELLOW_EPUMP_ACTIVE', hydPressures.yellow > 100);
  bool('L:A32NX_HYD_YELLOW_EPUMP_OVHT', false);
  bool('L:A32NX_HYD_PTU_VALVE_OPENED', false);
  num('L:A32NX_RAT_STOW_POSITION', 1, 'percent over 100');
}

function publishFuel(): void {
  const n1 = engineParams().n1;
  num('L:A32NX_TOTAL_FUEL_QUANTITY', engineState.fuel);
  num('FUEL WEIGHT PER GALLON', 3.0, 'kilogram');

  const fuelFraction = Math.max(0, Math.min(1, engineState.fuel / 15000));
  const tanks: Array<[string, number]> = [
    ['FUEL TANK CENTER QUANTITY', 1800],
    ['FUEL TANK LEFT MAIN QUANTITY', 1200],
    ['FUEL TANK RIGHT MAIN QUANTITY', 1200],
    ['FUEL TANK LEFT AUX QUANTITY', 400],
    ['FUEL TANK RIGHT AUX QUANTITY', 400],
  ];
  for (const [tank, gallons] of tanks) {
    const leak = tank.includes('LEFT') && systemsState.fuelLeakL ? 0.03 : tank.includes('RIGHT') && systemsState.fuelLeakR ? 0.03 : 1;
    num(tank, gallons * fuelFraction * leak, 'gallons');
  }

  const pumps = [
    systemsState.fuelL,
    systemsState.fuelL,
    systemsState.fuelC,
    systemsState.fuelC,
    systemsState.fuelR,
    systemsState.fuelR,
  ];
  for (let i = 0; i < pumps.length; i++) {
    bool(`FUELSYSTEM PUMP ACTIVE:${i + 1}`, pumps[i]);
    bool(`FUELSYSTEM PUMP SWITCH:${i + 1}`, pumps[i]);
  }
  for (const valve of [1, 2, 3, 4, 5]) num(`FUELSYSTEM VALVE OPEN:${valve}`, 1, 'percent');
  num('FUELSYSTEM VALVE OPEN:3', systemsState.xfeed ? 1 : 0, 'percent');

  bool('SIM ON GROUND', false);
  bool('L:A32NX_OVHD_FUEL_MODESEL_MANUAL', false);
  bool('L:A32NX_FIRE_BUTTON_APU', false);
  bool('FUELSYSTEM TRIGGER STATUS:9', false);

  num('L:A32NX_ENGINE_FF:1', n1 * 19, 'number');
  num('L:A32NX_ENGINE_FF:2', n1 * 19, 'number');
}
