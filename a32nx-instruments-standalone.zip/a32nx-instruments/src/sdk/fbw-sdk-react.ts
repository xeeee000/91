/**
 * Minimal `@flybywiresim/fbw-sdk-react` façade for the legacy React instruments
 * (ISIS and the original SD). Only the hooks actually used are re-exported.
 */
import { Arinc429Word } from '../../vendor/fbw-common/src/systems/shared/src/arinc429';
import { useSimVar } from '../../vendor/fbw-common/src/systems/instruments/src/react/simVars';

export * from '../../vendor/fbw-common/src/systems/instruments/src/react/simVars';
export { Arinc429Register, Arinc429SignStatusMatrix, Arinc429Word } from '../../vendor/fbw-common/src/systems/shared/src/arinc429';
export type { Arinc429WordData } from '../../vendor/fbw-common/src/systems/shared/src/arinc429';
export { RadioUtils } from '../../vendor/fbw-common/src/systems/shared/src/RadioUtils';
export { RateMultiplierKnob } from '../../vendor/fbw-common/src/systems/instruments/src/RateMultiplierKnob';
export { useUpdate, useInteractionEvent, useInteractionEvents } from '../../vendor/fbw-common/src/systems/instruments/src/react/hooks';
export { useInterval } from '../../vendor/fbw-common/src/systems/instruments/src/react/useInterval';
export * from '../../vendor/fbw-common/src/systems/instruments/src/react/persistence';
export { getSupplier, getSmallestAngle, isCaptainSide } from '../../vendor/fbw-common/src/systems/instruments/src/react/utils';
export { MathUtils } from '../../vendor/fbw-common/src/systems/shared/src/MathUtils';
export { NXDataStore } from './fbw-sdk';

/**
 * Local implementation of the upstream hook. The upstream module imports the
 * whole `shared/src/index`, which pulls in FMS/navdata/Sentry and is not needed.
 */
export function useArinc429Var(name: string, maxStaleness = 0): Arinc429Word {
  const [value] = useSimVar(name, 'number', maxStaleness);
  return new Arinc429Word(Number(value) || 0);
}
