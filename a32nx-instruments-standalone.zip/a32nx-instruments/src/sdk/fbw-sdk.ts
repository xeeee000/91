/**
 * Curated façade for `@flybywiresim/fbw-sdk`.
 *
 * The upstream package index pulls in the whole aircraft (FMS, navigraph,
 * navdata, EFB, sentry...). The instruments only need the small runtime subset
 * below, so the original import specifiers are redirected here by Vite.
 */
import { Subject } from '@microsoft/msfs-sdk';

export * from '../../vendor/fbw-common/src/systems/shared/src/arinc429';
export * from '../../vendor/fbw-common/src/systems/shared/src/ArincEventBus';
export * from '../../vendor/fbw-common/src/systems/shared/src/ArincEventBusSubscriber';
export * from '../../vendor/fbw-common/src/systems/shared/src/Arinc429ConsumerSubject';
export * from '../../vendor/fbw-common/src/systems/shared/src/Arinc429RegisterSubject';
export * from '../../vendor/fbw-common/src/systems/shared/src/ArincConsumer';
export * from '../../vendor/fbw-common/src/systems/shared/src/bitFlags';
export * from '../../vendor/fbw-common/src/systems/shared/src/MagVar';
export * from '../../vendor/fbw-common/src/systems/shared/src/MathUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/PathVector';
export * from '../../vendor/fbw-common/src/systems/shared/src/UpdateThrottler';
export * from '../../vendor/fbw-common/src/systems/shared/src/RadioUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/RunwayUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/FmMessages';
export * from '../../vendor/fbw-common/src/systems/shared/src/ApproachUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/Constants';
export * from '../../vendor/fbw-common/src/systems/shared/src/MapParameters';
export * from '../../vendor/fbw-common/src/systems/shared/src/units';
export * from '../../vendor/fbw-common/src/systems/shared/src/SimVarUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/simvar';

/** MSFS/Coherent global used by the TCAS computer; no traffic source in the standalone harness. */
export const registerTrafficListener = (): void => undefined;

export * from '../../vendor/fbw-common/src/systems/shared/src/GenericDataListenerSync';
export * from '../../vendor/fbw-common/src/systems/shared/src/types';
export { FailuresConsumer } from '../../vendor/fbw-common/src/systems/shared/src/failures/failures-consumer';
export * from '../../vendor/fbw-common/src/systems/shared/src/publishers';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/ProcedureLeg';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/SectionCode';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Airport';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Airspace';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Airway';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Approach';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Arrival';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/BaseFix';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Common';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Communication';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/DatabaseIdent';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Departure';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Gate';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/IlsNavaid';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Marker';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/NdbNavaid';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Runway';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/VhfNavaid';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/types/Waypoint';
export * from '../../vendor/fbw-common/src/systems/navdata/shared/utils';
export * from '../../vendor/fbw-common/src/systems/fmgc/constraint';
export * from '../../vendor/fbw-common/src/systems/instruments/src/NavigationDisplay';
export * from '../../vendor/fbw-common/src/systems/instruments/src/NXUnits';
export * from '../../vendor/fbw-common/src/systems/instruments/src/NXLogic';
export * from '../../vendor/fbw-common/src/systems/instruments/src/defaults';

/**
 * Minimal persistent settings store (MSFS DataStore replacement).
 * Instruments only read a couple of legacy keys.
 */
export class NXDataStore {  private static readonly memory = new Map<string, string>();

  public static getLegacy(key: string, defaultVal: string): string {
    try {
      return localStorage.getItem(`A32NX_${key}`) ?? defaultVal;
    } catch {
      return NXDataStore.memory.get(key) ?? defaultVal;
    }
  }

  public static setLegacy(key: string, value: string): void {
    try {
      localStorage.setItem(`A32NX_${key}`, value);
    } catch {
      NXDataStore.memory.set(key, value);
    }
  }

  public static get(key: string, defaultVal = ''): string {
    return NXDataStore.getLegacy(key, defaultVal);
  }

  public static set(key: string, value: string): void {
    NXDataStore.setLegacy(key, value);
  }

  public static getSetting<T = string>(key: string): Subject<T> {
    return Subject.create<T>(NXDataStore.getLegacy(key, '') as unknown as T);
  }

  public static subscribe(_key: string, _cb: () => void): () => void {
    return () => undefined;
  }

  public static subscribeLegacy(_key: string, _cb: (key: string, value: string | undefined) => void): () => void {
    return () => undefined;
  }

  public static getAndSubscribeLegacy(
    key: string,
    cb: (key: string, value: string | undefined) => void,
    defaultVal = '',
  ): () => void {
    cb(key, NXDataStore.getLegacy(key, defaultVal));
    return () => undefined;
  }
}

/** Sentry is not used in the standalone harness. */
export class FbwAircraftSentryClient {
  public onInstrumentLoaded(_options?: unknown): void {
    /* no-op */
  }
}

export * from '../../vendor/fbw-common/src/systems/shared/src/AircraftGithubVersionChecker';
export * from '../../vendor/fbw-common/src/systems/shared/src/UniversalConfigProvider';
export * from '../../vendor/fbw-common/src/systems/shared/src/Simbrief/simbriefParser';
export * from '../../vendor/fbw-common/src/systems/shared/src/popup';


export * from '../../vendor/fbw-common/src/systems/navdata/client/NearbyFacilityMonitor';


export * from '../../vendor/fbw-common/src/systems/instruments/src/Convert';


export * from '../../vendor/fbw-common/src/systems/shared/src/array';


export * from '../../vendor/fbw-common/src/systems/shared/src/notification';


export * from '../../vendor/fbw-common/src/systems/navdata/client/Database';


export * from '../../vendor/fbw-common/src/systems/navdata/client/backends/Msfs/Msfs';


export * from '../../vendor/fbw-common/src/systems/navdata/client/backends/Test/Test';


export * from '../../vendor/fbw-common/src/systems/shared/src/Troubleshooting';
export * from '../../vendor/fbw-common/src/systems/shared/src/TelexCheck';
export * from '../../vendor/fbw-common/src/systems/shared/src/ViewListenerUtils';
export * from '../../vendor/fbw-common/src/systems/shared/src/DateTimeFormatters';
export * from '../../vendor/fbw-common/src/systems/shared/src/LegacyPopupTypes';
export * from '../../vendor/fbw-common/src/systems/shared/src/config';
export * from '../../vendor/fbw-common/src/systems/shared/src/ata';
export * from '../../vendor/fbw-common/src/systems/shared/src/hash';
export * from '../../vendor/fbw-common/src/systems/shared/src/logic';
export * from '../../vendor/fbw-common/src/systems/shared/src/performance';
export * from '../../vendor/fbw-common/src/systems/shared/src/persistence';
export * from '../../vendor/fbw-common/src/systems/shared/src/parseMetar';

