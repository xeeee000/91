import '../../vendor/fbw-a32nx/src/systems/instruments/src/ND/instrument';
