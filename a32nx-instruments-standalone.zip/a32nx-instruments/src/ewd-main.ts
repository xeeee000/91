import './harness/globals';
import './styles/pfd.css';
import { publishEwdState } from './data/ewd-feed';
import { engineState } from './data/engine-state';
import { systemsState } from './data/systems-state';
import { simVars } from './harness/simvar-store';

publishEwdState();

const channel = new BroadcastChannel('a32nx-sim');
channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.n1 === 'number') engineState.n1 = s.n1;
  if (typeof s.fuel === 'number') engineState.fuel = s.fuel;
  if (typeof s.gen1 === 'boolean') systemsState.gen1 = s.gen1;
  if (typeof s.gen2 === 'boolean') systemsState.gen2 = s.gen2;
  if (typeof s.hydGreen === 'boolean') systemsState.hydGreen = s.hydGreen;
  if (typeof s.hydBlue === 'boolean') systemsState.hydBlue = s.hydBlue;
  if (typeof s.hydYellow === 'boolean') systemsState.hydYellow = s.hydYellow;
  if (typeof s.pack1 === 'boolean') systemsState.pack1 = s.pack1;
  if (typeof s.pack2 === 'boolean') systemsState.pack2 = s.pack2;
  if (typeof s.engBleed1 === 'boolean') systemsState.engBleed1 = s.engBleed1;
  if (typeof s.engBleed2 === 'boolean') systemsState.engBleed2 = s.engBleed2;
  if (typeof s.apuBleed === 'boolean') systemsState.apuBleed = s.apuBleed;
  if (typeof s.fuelL === 'boolean') systemsState.fuelL = s.fuelL;
  if (typeof s.fuelR === 'boolean') systemsState.fuelR = s.fuelR;
  if (typeof s.fuelC === 'boolean') systemsState.fuelC = s.fuelC;
  if (typeof s.xfeed === 'boolean') systemsState.xfeed = s.xfeed;
  if (typeof s.apuMaster === 'boolean') systemsState.apuMaster = s.apuMaster;
  if (typeof s.apuAvailable === 'boolean') systemsState.apuAvailable = s.apuAvailable;
  if (typeof s.apuGen === 'boolean') systemsState.apuGen = s.apuGen;
  if (typeof s.eng1Running === 'boolean') systemsState.eng1Running = s.eng1Running;
  if (typeof s.eng2Running === 'boolean') systemsState.eng2Running = s.eng2Running;
  if (typeof s.eng1Master === 'boolean') systemsState.eng1Master = s.eng1Master;
  if (typeof s.eng2Master === 'boolean') systemsState.eng2Master = s.eng2Master;
  if (typeof s.eng1Fire === 'boolean') systemsState.eng1Fire = s.eng1Fire;
  if (typeof s.eng2Fire === 'boolean') systemsState.eng2Fire = s.eng2Fire;
  if (typeof s.apuFire === 'boolean') systemsState.apuFire = s.apuFire;
  if (typeof s.eng1Fail === 'boolean') systemsState.eng1Fail = s.eng1Fail;
  if (typeof s.eng2Fail === 'boolean') systemsState.eng2Fail = s.eng2Fail;
  if (typeof s.apuFail === 'boolean') systemsState.apuFail = s.apuFail;
  if (typeof s.cargoSmoke === 'boolean') systemsState.cargoSmoke = s.cargoSmoke;
  if (typeof s.pressFault === 'boolean') systemsState.pressFault = s.pressFault;
  if (typeof s.oxyFail === 'boolean') systemsState.oxyFail = s.oxyFail;
  if (typeof s.hotAirFault === 'boolean') systemsState.hotAirFault = s.hotAirFault;
  if (typeof s.adirs1 === 'boolean') systemsState.adirs1 = s.adirs1;
  if (typeof s.adirs2 === 'boolean') systemsState.adirs2 = s.adirs2;
  if (typeof s.adirs3 === 'boolean') systemsState.adirs3 = s.adirs3;
  if (typeof s.adirsAligned === 'boolean') systemsState.adirsAligned = s.adirsAligned;
  if (typeof s.gearFail === 'boolean') systemsState.gearFail = s.gearFail;
  if (typeof s.elac1Fail === 'boolean') systemsState.elac1Fail = s.elac1Fail;
  if (typeof s.sec1Fail === 'boolean') systemsState.sec1Fail = s.sec1Fail;
  if (typeof s.fac1Fail === 'boolean') systemsState.fac1Fail = s.fac1Fail;
  if (typeof s.fuelLeakL === 'boolean') systemsState.fuelLeakL = s.fuelLeakL;
  if (typeof s.fuelLeakR === 'boolean') systemsState.fuelLeakR = s.fuelLeakR;
  if (typeof s.gearDown === 'boolean') systemsState.gearDown = s.gearDown;
  publishEwdState();
};

import('./instruments/ewd-entry').then(() => {
  const host = document.querySelector('a32nx-ewd') as any;
  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 768, window.innerHeight / 768);
    document.documentElement.style.setProperty('--pfd-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 80) {
      lastPublish = now;
      simVars.set('E:SIMULATION TIME', phase, 'seconds');
      simVars.set('E:ABSOLUTE TIME', 63_900_000_000 + phase, 'seconds');
      publishEwdState();
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
