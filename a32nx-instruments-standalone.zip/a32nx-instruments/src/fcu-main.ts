import './harness/globals';
import './styles/fcu.css';
import { installInstrumentPower } from './power';
installInstrumentPower('ac');
import { publishFcuState } from './data/fcu-feed';
import { fcuState } from './data/fcu-state';
import { simVars } from './harness/simvar-store';

// The original FCU markup points at MSFS' coui:// scheme. Rewrite it at runtime
// (no source changes) to the local asset copied from the upstream package.
function rewriteCoui(root: ParentNode = document): void {
  root.querySelectorAll<HTMLImageElement>('img[src^="coui://"]').forEach((img) => {
    const src = img.getAttribute('src') ?? '';
    const local = src.replace(/^coui:\/\/html_ui\//, '/');
    if (local !== src) img.src = local;
  });
}

publishFcuState();

const channel = new BroadcastChannel('a32nx-sim');
channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.fcuSpeed === 'number') fcuState.speed = s.fcuSpeed;
  if (typeof s.fcuHeading === 'number') fcuState.heading = s.fcuHeading;
  if (typeof s.fcuAltitude === 'number') fcuState.altitude = s.fcuAltitude;
  if (typeof s.fcuVs === 'number') fcuState.verticalSpeed = s.fcuVs;
  if (typeof s.fcuSpeedManaged === 'boolean') fcuState.speedManaged = s.fcuSpeedManaged;
  if (typeof s.fcuHeadingManaged === 'boolean') fcuState.headingManaged = s.fcuHeadingManaged;
  if (typeof s.fcuAltitudeManaged === 'boolean') fcuState.altitudeManaged = s.fcuAltitudeManaged;
  publishFcuState();
};

import('./instruments/fcu-entry').then(() => {
  const host = document.querySelector('a32nx-fcu') as any;

  rewriteCoui();
  new MutationObserver(() => rewriteCoui()).observe(document.body, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['src'],
  });

  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;
  // Daylight timestamp so the FCU's original sun/ambient model lights the panel.
  const baseAbsoluteTime = Date.UTC(2025, 5, 21, 10, 0, 0) / 1000 + 62_135_596_800;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 1280, window.innerHeight / 640);
    document.documentElement.style.setProperty('--fcu-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 120) {
      lastPublish = now;
      simVars.set('E:SIMULATION TIME', phase, 'seconds');
      simVars.set('E:ABSOLUTE TIME', baseAbsoluteTime + phase, 'seconds');
      simVars.set('PLANE LATITUDE', 46.238, 'degrees');
      simVars.set('PLANE LONGITUDE', 6.109, 'degrees');
      publishFcuState();
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
      // The HTML layer in MSFS only renders the backlight glow; in standalone
      // mode we want the original panel artwork visible.
      document.documentElement.style.setProperty('--main-background-opacity', '1');
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
