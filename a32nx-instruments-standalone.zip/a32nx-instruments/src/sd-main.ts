﻿import './harness/globals';
import './styles/pfd.css';
import { publishSdState } from './data/sd-feed';
import { simVars } from './harness/simvar-store';

publishSdState();

import('./instruments/sd-entry').then(() => {
  const host = document.querySelector('a32nx-sdv2') as any;
  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 768, window.innerHeight / 768);
    document.documentElement.style.setProperty('--pfd-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 80) {
      lastPublish = now;
      simVars.set('E:SIMULATION TIME', phase, 'seconds');
      simVars.set('E:ABSOLUTE TIME', 63_900_000_000 + phase, 'seconds');
      publishSdState();
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});

