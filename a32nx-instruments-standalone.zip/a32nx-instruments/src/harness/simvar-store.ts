/**
 * Browser-side replacement for the MSFS SimVar / Coherent data layer.
 *
 * Original A32NX instrument code is left untouched; it keeps polling SimVars and
 * using the MSFS avionics SDK. This store answers those polls from a plain JS
 * simulation instead of the flight simulator + WASM systems.
 */

export type SimVarValue = number | string | boolean | null | undefined;

const ALIASES: Record<string, string> = {
  bool: 'boolean',
  boolean: 'boolean',
  number: 'number',
  enum: 'number',
  mach: 'number',
  percent: 'number',
  'percent over 100': 'number',
  string: 'string',
  feet: 'feet',
  foot: 'feet',
  ft: 'feet',
  meters: 'meters',
  meter: 'meters',
  metre: 'meters',
  metres: 'meters',
  m: 'meters',
  knots: 'knots',
  knot: 'knots',
  kt: 'knots',
  'meters per second': 'mps',
  'm/s': 'mps',
  mps: 'mps',
  'feet per minute': 'fpm',
  fpm: 'fpm',
  degrees: 'degrees',
  degree: 'degrees',
  deg: 'degrees',
  radians: 'radians',
  rad: 'radians',
  celsius: 'celsius',
  farenheit: 'fahrenheit',
  fahrenheit: 'fahrenheit',
  hectopascals: 'hpa',
  hpa: 'hpa',
  millibars: 'hpa',
  mb: 'hpa',
  'inches of mercury': 'inhg',
  inhg: 'inhg',
  'nautical mile': 'nm',
  'nautical miles': 'nm',
  nm: 'nm',
  hours: 'hours',
  hour: 'hours',
  seconds: 'seconds',
  second: 'seconds',
  minutes: 'minutes',
  minute: 'minutes',
  amperes: 'amps',
  amps: 'amps',
  volts: 'volts',
  kilograms: 'kg',
  kg: 'kg',
  pounds: 'lbs',
  lbs: 'lbs',
  gallons: 'gal',
  gal: 'gal',
  liters: 'l',
  litres: 'l',
  l: 'l',
  hz: 'hz',
  hertz: 'hz',
  khz: 'khz',
  mhz: 'mhz',
  psi: 'psi',
  'pounds per square inch': 'psi',
};

/** factor: value_in_from * factor = value_in_to */
const CONVERSIONS: Array<[string, string, number]> = [
  ['feet', 'meters', 0.3048],
  ['meters', 'feet', 1 / 0.3048],
  ['knots', 'mps', 0.514444444],
  ['mps', 'knots', 1 / 0.514444444],
  ['fpm', 'mps', 0.00508],
  ['mps', 'fpm', 1 / 0.00508],
  ['degrees', 'radians', Math.PI / 180],
  ['radians', 'degrees', 180 / Math.PI],
  ['celsius', 'fahrenheit', 9 / 5],
  ['fahrenheit', 'celsius', 5 / 9],
  ['hpa', 'inhg', 0.0295299830714],
  ['inhg', 'hpa', 1 / 0.0295299830714],
  ['nm', 'meters', 1852],
  ['meters', 'nm', 1 / 1852],
  ['hours', 'seconds', 3600],
  ['seconds', 'hours', 1 / 3600],
  ['kg', 'lbs', 2.2046226218],
  ['lbs', 'kg', 1 / 2.2046226218],
  ['gal', 'l', 3.785411784],
  ['l', 'gal', 1 / 3.785411784],
  ['khz', 'hz', 1000],
  ['hz', 'khz', 0.001],
  ['mhz', 'hz', 1_000_000],
  ['hz', 'mhz', 1 / 1_000_000],
];

// Temperature needs an offset as well as a factor.
const TEMP_OFFSETS: Record<string, number> = { celsius: 0, fahrenheit: 32 };

function normalizeUnit(unit?: string): string {
  if (!unit) return 'number';
  return ALIASES[String(unit).trim().toLowerCase()] ?? String(unit).trim().toLowerCase();
}

export function convertValue(value: SimVarValue, fromUnit: string, toUnit: string): SimVarValue {
  if (value === null || value === undefined) return 0;
  if (fromUnit === toUnit) return value;
  if (toUnit === 'string') return String(value);
  if (fromUnit === 'string') return Number(value) || 0;
  if (toUnit === 'boolean') return !!value;
  if (typeof value !== 'number') return value;

  if (
    (fromUnit === 'celsius' || fromUnit === 'fahrenheit') &&
    (toUnit === 'celsius' || toUnit === 'fahrenheit')
  ) {
    const f = fromUnit === 'celsius' ? (value * 9) / 5 + 32 : value;
    return toUnit === 'fahrenheit' ? f : ((f - 32) * 5) / 9;
  }

  for (const [from, to, factor] of CONVERSIONS) {
    if (from === fromUnit && to === toUnit) {
      return value * factor;
    }
  }
  return value;
}

interface Entry {
  value: SimVarValue;
  unit: string;
}

class SimVarStore {
  private readonly values = new Map<string, Entry>();

  private readonly registeredIds = new Map<string, number>();

  private readonly idEntries: Array<{ name: string; unit: string }> = [];

  private key(name: string): string {
    return String(name).trim().toUpperCase();
  }

  public set(name: string, value: SimVarValue, unit = 'number'): void {
    this.values.set(this.key(name), { value, unit: normalizeUnit(unit) });
  }

  public has(name: string): boolean {
    return this.values.has(this.key(name));
  }

  public get(name: string, unit = 'number'): SimVarValue {
    const target = normalizeUnit(unit);
    const entry = this.values.get(this.key(name));
    if (!entry) {
      if (target === 'string') return '';
      if (target === 'boolean') return false;
      return 0;
    }
    return convertValue(entry.value, entry.unit, target);
  }

  public register(name: string, unit: string, dataSource = ''): number {
    const u = normalizeUnit(unit);
    const k = `${this.key(name)}|${u}|${dataSource}`;
    let id = this.registeredIds.get(k);
    if (id === undefined) {
      id = this.idEntries.length;
      this.registeredIds.set(k, id);
      this.idEntries.push({ name, unit: u });
    }
    return id;
  }

  public getById(id: number): SimVarValue {
    const entry = this.idEntries[id];
    if (!entry) return 0;
    return this.get(entry.name, entry.unit);
  }

  public setById(id: number, value: SimVarValue): void {
    const entry = this.idEntries[id];
    if (!entry) return;
    this.set(entry.name, value, entry.unit);
  }
}

export const simVars = new SimVarStore();
