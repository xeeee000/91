/**
 * MSFS runtime shims.
 *
 * The original A32NX instruments are loaded byte-for-byte unchanged. They only
 * expect the MSFS/Coherent globals below; everything else (rendering, aircraft
 * systems logic inside the instrument) stays original.
 */
import { simVars } from './simvar-store';

type Listener = (...args: any[]) => void;

const listeners = new Map<string, Listener[]>();

const viewListenerStub = () => ({
  on: (_name: string, _cb: Listener) => undefined,
  off: () => undefined,
  call: (_name: string, ..._args: any[]) => Promise.resolve(undefined),
  trigger: (_name: string, ..._args: any[]) => undefined,
  triggerToAllSubscribers: (_name: string, ..._args: any[]) => undefined,
  subscribe: () => undefined,
  unsubscribe: () => undefined,
});

/**
 * Base class for MSFS HTML instruments. Real MSFS instruments are custom
 * elements, which is why the original code can read `url` off `this`.
 */
export class BaseInstrument extends HTMLElement {
  public instrumentIndex = 1;

  public deltaTime = 16;

  public connectedCallback(): void {
    const url = this.getAttribute('url') ?? '';
    const match = url.match(/(\d)\s*$/);
    this.instrumentIndex = match ? Number(match[1]) : 1;
  }

  public Init(): void {
    /* MSFS lifecycle hook */
  }

  public Update(): void {
    /* overridden by instruments */
  }

  public onInteractionEvent(_args: string[]): void {
    /* overridden by instruments */
  }

  public onGameStateChanged(_oldState: number, _newState: number): void {
    /* overridden by instruments */
  }

  public onFlightStart(): void {
    /* overridden by instruments */
  }

  public onSoundEnd(_soundEventId: unknown): void {
    /* overridden by instruments */
  }

  public getGameState(): number {
    return 3; // ingame
  }

  public getDeltaTime(): number {
    return this.deltaTime;
  }
}

export interface InstrumentConstructor {
  new (): BaseInstrument;
}

const instrumentRegistry = new Map<string, InstrumentConstructor>();

export function registerInstrument(tagName: string, ctor: InstrumentConstructor): void {
  instrumentRegistry.set(tagName.toLowerCase(), ctor);
  if (!customElements.get(tagName.toLowerCase())) {
    customElements.define(tagName.toLowerCase(), ctor as unknown as CustomElementConstructor);
  }
}

export function getRegisteredInstrument(tagName: string): InstrumentConstructor | undefined {
  return instrumentRegistry.get(tagName.toLowerCase());
}

const simVarGlobal = {
  GetSimVarValue(name: string, unit = 'number'): unknown {
    return simVars.get(name, unit);
  },
  GetGlobalVarValue(_name: string, _unit: string): number {
    return 0;
  },
  GetGameVarValue(_name: string, _unit: string): string {
    return 'APR21MAY18/22';
  },
  SetSimVarValue(name: string, unit: string, value: unknown): Promise<void> {
    simVars.set(name, value as never, unit);
    return Promise.resolve();
  },
  GetRegisteredId(name: string, unit: string, dataSource = ''): number {
    return simVars.register(name, unit, dataSource);
  },
  GetSimVarValueFastReg(id: number): unknown {
    return simVars.getById(id);
  },
  SetSimVarValueFastReg(id: number, value: unknown): void {
    simVars.setById(id, value as never);
  },
};

const simvarGlobal = {
  getValueReg: (id: number) => simVars.getById(id),
  getValueReg_String: (id: number) => String(simVars.getById(id) ?? ''),
  getValueReg_Bool: (id: number) => !!simVars.getById(id),
  getValue_LatLongAlt: (name: string) => {
    const v = simVars.get(name, 'latlonalt');
    return v && typeof v === 'object' ? v : { lat: 0, lon: 0, alt: 0 };
  },
  getValue_LatLongAltPBH: (name: string) => {
    const v = simVars.get(name, 'latlonaltpbh');
    return v && typeof v === 'object' ? v : { lat: 0, lon: 0, alt: 0, pitch: 0, bank: 0, heading: 0 };
  },
  getValue_PBH: (name: string) => {
    const v = simVars.get(name, 'pbh');
    return v && typeof v === 'object' ? v : { pitch: 0, bank: 0, heading: 0 };
  },
  getValue_PID_STRUCT: (name: string) => simVars.get(name, 'pid_struct'),
  getValue_XYZ: (name: string) => simVars.get(name, 'xyz'),
  registerSimVar: (name: string, unit: string, dataSource = '') => simVars.register(name, unit, dataSource),
};

const coherent = {
  call(command: string, ...args: any[]): Promise<unknown> {
    switch (command) {
      case 'setValueReg_Number':
      case 'setValueReg_Bool':
        simVars.setById(args[0], args[1]);
        return Promise.resolve();
      case 'setValueReg_String':
        simVars.setById(args[0], args[1]);
        return Promise.resolve();
      case 'setValue_LatLongAlt':
      case 'setValue_LatLongAltPBH':
      case 'setValue_PBH':
      case 'setValue_PID_STRUCT':
      case 'setValue_XYZ':
        simVars.set(args[0], args[1], command.replace('setValue_', '').toLowerCase());
        return Promise.resolve();
      case 'triggerEvent':
        return Promise.resolve();
      default:
        return Promise.resolve();
    }
  },
  on(name: string, cb: Listener): void {
    const list = listeners.get(name) ?? [];
    list.push(cb);
    listeners.set(name, list);
  },
  off(name: string, cb: Listener): void {
    const list = listeners.get(name);
    if (!list) return;
    const i = list.indexOf(cb);
    if (i >= 0) list.splice(i, 1);
  },
  trigger(name: string, ...args: any[]): void {
    listeners.get(name)?.forEach((cb) => cb(...args));
  },
  triggerToAllSubscribers(name: string, ...args: any[]): void {
    listeners.get(name)?.forEach((cb) => cb(...args));
  },
};

function install(): void {
  const g = globalThis as any;

  g.BaseInstrument = BaseInstrument;
  g.registerInstrument = registerInstrument;
  g.getGameState = () => 3;
  g.getSupplier = (displaySide: 'L' | 'R' | number, knobPosition = 0) => {
    const captain = displaySide === 'L' || displaySide === 1;
    if (captain) return knobPosition === 0 ? 3 : 1;
    return knobPosition === 2 ? 3 : 2;
  };

  g.SimVar = simVarGlobal;
  g.simvar = simvarGlobal;
  g.Coherent = coherent;
  g.RegisterViewListener = (_name: string, cb?: () => void) => {
    const listener = viewListenerStub();
    // The msfs-sdk assigns the returned listener to a const and uses it inside
    // this callback, so the callback must not run synchronously.
    queueMicrotask(() => cb?.());
    return listener;
  };
  g.EmptyCallback = Object.assign(() => undefined, {
    Void: () => undefined,
    Boolean: (_value?: boolean) => undefined,
    String: (_value?: string) => undefined,
    Number: (_value?: number) => undefined,
  });
  g.Utils = {
    generateGUID: () => (globalThis.crypto?.randomUUID?.() ?? `guid-${Math.random().toString(16).slice(2)}`),
  };
  g.RegisterGenericDataListener = (onRegistered?: () => void) => {
    const handlers = new Map<string, Listener[]>();
    const listener = {
      send(key: string, data: unknown) {
        handlers.get(key)?.forEach((cb) => cb(data));
      },
      onDataReceived(key: string, cb: Listener) {
        const list = handlers.get(key) ?? [];
        list.push(cb);
        handlers.set(key, list);
      },
      trigger() {
        /* not used */
      },
    };
    (g as any).__A32NX_GENERIC_DATA_LISTENERS__ ??= [];
    (g as any).__A32NX_GENERIC_DATA_LISTENERS__.push(listener);
    queueMicrotask(() => onRegistered?.());
    return listener;
  };
  g.GetStoredData = (key: string) => {
    try {
      return localStorage.getItem(key) ?? '';
    } catch {
      return '';
    }
  };
  g.SetStoredData = (key: string, value: string) => {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* ignore */
    }
  };
  g.Simplane = {
    getGameState: () => 3,
    isReady: () => true,
    getAltitude: () => 12000,
    getAltitudeAboveGround: () => 0,
    getAmbientTemperature: () => 15,
    getAutoPilotAirspeedHoldValue: () => 250,
    getAutoPilotAirspeedManaged: () => 1,
    getAutoPilotAirspeedSelected: () => 250,
    getAutoPilotDisplayedAltitudeLockValue: () => 20000,
    getAutoPilotMachHoldValue: () => 0.48,
    getAutoPilotMachModeActive: () => 0,
    getAutoPilotSelectedAltitudeLockValue: () => 20000,
    getGreenDotSpeed: () => 220,
    getGroundSpeed: () => 260,
    getIsGrounded: () => false,
    getPressureSelectedMode: () => 0,
    getPressureValue: () => 1013,
  };

  class LatLongAlt {
    public lat = 0;

    public lon = 0;

    public alt = 0;

    constructor(v?: any) {
      if (v && typeof v === 'object') {
        this.lat = v.lat ?? 0;
        this.lon = v.lon ?? 0;
        this.alt = v.alt ?? 0;
      }
    }

    public toString(): string {
      return `${this.lat.toFixed(6)},${this.lon.toFixed(6)},${this.alt.toFixed(1)}`;
    }
  }

  class PitchBankHeading {
    public pitch = 0;

    public bank = 0;

    public heading = 0;

    constructor(v?: any) {
      if (v && typeof v === 'object') {
        this.pitch = v.pitch ?? 0;
        this.bank = v.bank ?? 0;
        this.heading = v.heading ?? 0;
      }
    }
  }

  class LatLongAltPBH extends LatLongAlt {
    public pitch = 0;

    public bank = 0;

    public heading = 0;
  }

  class XYZ {
    public x = 0;

    public y = 0;

    public z = 0;
  }

  class PID_STRUCT {
    public pid = 0;

    public value = 0;
  }

  g.LatLongAlt = LatLongAlt;
  g.LatLongAltPBH = LatLongAltPBH;
  g.PitchBankHeading = PitchBankHeading;
  g.XYZ = XYZ;
  g.PID_STRUCT = PID_STRUCT;
  g.Include = {
    addJs: () => undefined,
    addCss: () => undefined,
  };
  g.Avionics = {
    usingFacilities: false,
    Utils: {
      DEG: Math.PI / 180,
      RAD: 180 / Math.PI,
      DEG2RAD: Math.PI / 180,
      RAD2DEG: 180 / Math.PI,
      FEET: 0.3048,
      make_xpndr_bcd: (code: number) => code,
      computeGreatCircleHeading: (from: any, to: any) => {
        const toRad = (d: number) => (d * Math.PI) / 180;
        const dLon = toRad(to.long - from.long);
        const y = Math.sin(dLon) * Math.cos(toRad(to.lat));
        const x =
          Math.cos(toRad(from.lat)) * Math.sin(toRad(to.lat)) -
          Math.sin(toRad(from.lat)) * Math.cos(toRad(to.lat)) * Math.cos(dLon);
        return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
      },
      computeGreatCircleDistance: (from: any, to: any) => {
        const R = 3440.065; // nautical miles
        const toRad = (d: number) => (d * Math.PI) / 180;
        const dLat = toRad(to.lat - from.lat);
        const dLon = toRad(to.long - from.long);
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos(toRad(from.lat)) * Math.cos(toRad(to.lat)) * Math.sin(dLon / 2) ** 2;
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
      },
      lerpAngle: (a: number, b: number, t: number) => {
        const delta = ((b - a + 540) % 360) - 180;
        return (a + delta * t + 360) % 360;
      },
    },
    CurveTool: {
      StringColorRGBInterpolation: () => 'rgb(255,255,255)',
      NumberInterpolation: (a: number, b: number, t: number) => a + (b - a) * t,
    },
    Curve: class Curve {
      public interpolationFunction: (a: number, b: number, t: number) => number = (a, b, t) => a + (b - a) * t;

      private points: Array<[number, number]> = [];

      add(x: number, y: number): this {
        this.points.push([x, y]);
        this.points.sort((a, b) => a[0] - b[0]);
        return this;
      }

      get(x: number): number {
        if (this.points.length === 0) return 0;
        if (x <= this.points[0][0]) return this.points[0][1];
        if (x >= this.points[this.points.length - 1][0]) return this.points[this.points.length - 1][1];
        for (let i = 1; i < this.points.length; i++) {
          if (x <= this.points[i][0]) {
            const [x0, y0] = this.points[i - 1];
            const [x1, y1] = this.points[i];
            return this.interpolationFunction(y0, y1, (x - x0) / (x1 - x0));
          }
        }
        return 0;
      }

      evaluate(x: number): number {
        return this.get(x);
      }
    },
  };

  // MSFS global enums referenced at module-evaluation time by @microsoft/msfs-sdk.
  g.RunwayDesignator = {
    RUNWAY_DESIGNATOR_NONE: 0,
    RUNWAY_DESIGNATOR_LEFT: 1,
    RUNWAY_DESIGNATOR_RIGHT: 2,
    RUNWAY_DESIGNATOR_CENTER: 3,
    RUNWAY_DESIGNATOR_WATER: 4,
    RUNWAY_DESIGNATOR_A: 5,
    RUNWAY_DESIGNATOR_B: 6,
  };
  g.RunwaySurfaceType = {
    Asphalt: 0,
    Bituminous: 1,
    Brick: 2,
    Concrete: 3,
    Ice: 4,
    Macadam: 5,
    Paint: 6,
    Planks: 7,
    SteelMats: 8,
    Tarmac: 9,
    Urban: 10,
    Coral: 11,
    Dirt: 12,
    Forest: 13,
    Grass: 14,
    GrassBumpy: 15,
    Gravel: 16,
    HardTurf: 17,
    LongGrass: 18,
    OilTreated: 19,
    Sand: 20,
    Shale: 21,
    ShortGrass: 22,
    Snow: 23,
    WrightFlyerTrack: 24,
    WaterFSX: 25,
    Lake: 26,
    Ocean: 27,
    Pond: 28,
    River: 29,
    WasteWater: 30,
    Water: 31,
  };
}

install();

export { instrumentRegistry, viewListenerStub };

(globalThis as any).GameState = {
  loading: 'loading',
  briefing: 'briefing',
  ingame: 'ingame',
  menu: 'menu',
  freeflight: 'freeflight',
  runway: 'runway',
  approach: 'approach',
};


(globalThis as any).Facilities = {
  getMagVar: (_lat: number, _lon: number) => 0,
};

