import './harness/globals';
import './styles/atc.css';
import { installInstrumentPower } from './power';
installInstrumentPower('ac');
import { simVars } from './harness/simvar-store';

simVars.set('L:A32NX_OVHD_INTLT_ANN', 1, 'bool');
simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_AC_ESS_SHED_BUS_IS_POWERED', 1, 'bool');
simVars.set('TRANSPONDER CODE:1', 8192); // squawk 2000 in BCO16

import('./instruments/atc-entry').then(() => {
  const root = document.getElementById('MSFS_REACT_MOUNT')?.parentElement ?? document.body;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 600, window.innerHeight / 300);
    document.documentElement.style.setProperty('--atc-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  document.querySelectorAll<HTMLButtonElement>('[data-atc-btn]').forEach((button) => {
    button.addEventListener('click', () => {
      const key = button.dataset.atcBtn ?? 'CLR';
      root.dispatchEvent(new Event(`A320_Neo_ATC_BTN_${key}`));
    });
  });

  function frame(): void {
    root.dispatchEvent(new Event('update'));
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});