import './harness/globals';
import './styles/rmp.css';
import { installInstrumentPower } from './power';
installInstrumentPower('ac');
import { publishRmpState } from './data/rmp-feed';
import { rmpState } from './data/rmp-state';

publishRmpState();

const channel = new BroadcastChannel('a32nx-sim');
channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.rmpActiveMHz === 'number') rmpState.active = s.rmpActiveMHz;
  if (typeof s.rmpStandbyMHz === 'number') rmpState.standby = s.rmpStandbyMHz;
  publishRmpState();
};

import('./instruments/rmp-entry').then(() => {
  const mount = document.getElementById('MSFS_REACT_MOUNT');
  const root = mount?.parentElement ?? document.body;

  let last = performance.now();
  let lastPublish = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 1024, window.innerHeight / 512);
    document.documentElement.style.setProperty('--rmp-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;

    if (now - lastPublish > 250) {
      lastPublish = now;
      publishRmpState();
    }

    void dt;
    root.dispatchEvent(new Event('update'));
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
