/**
 * Lightweight A320-class flight model for the standalone cockpit.
 *
 * It is deliberately not a full 6-DOF model: it keeps the flight-path angle,
 * pitch and bank as states, computes lift/drag/thrust from a small polar, and
 * integrates speed, vertical speed and position. The numbers are tuned so the
 * aircraft can actually rotate, climb, cruise, descend and land in a browser.
 */

export type FlightPhase = 'PARKED' | 'TAXI' | 'TAKEOFF' | 'CLIMB' | 'CRUISE' | 'DESCENT' | 'APPROACH' | 'LANDED';

export interface FlightModelState {
  lat: number;
  lon: number;
  altFt: number;
  ias: number;
  tas: number;
  gs: number;
  vsFpm: number;
  pitch: number;
  roll: number;
  heading: number;
  track: number;
  aoa: number;
  gLoad: number;
  n1: number;
  throttle: number;
  flaps: number;
  gearDown: boolean;
  brakes: boolean;
  onGround: boolean;
  phase: FlightPhase;
  fuelKg: number;
  massKg: number;
  thrustKn: number;
  paused: boolean;
  warning: string;
  touchdownVs: number;
}

export interface FlightControls {
  pitch: number;
  roll: number;
  yaw: number;
  throttle: number;
  flaps: number;
  gearDown: boolean;
  brake: boolean;
  ap: boolean;
  targetAlt: number;
  targetSpeed: number;
  targetHeading: number;
  paused: boolean;
}

const G = 9.80665;
const KT = 0.514444;
const FT = 0.3048;
const WING_AREA = 122.6;
const MAX_THRUST_N = 2 * 120_000;
const EMPTY_MASS = 40_000;
const PAYLOAD = 8_000;
const FIELD_ELEV_FT = 1411;
const VFE = [0, 230, 200, 185, 177]; // max speed per flap detent, kt
const FLAP_CL = [0, 0.35, 0.9, 1.25, 1.5];
const FLAP_CD = [0, 0.006, 0.014, 0.028, 0.05];

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function moveTowards(current: number, target: number, maxDelta: number): number {
  if (Math.abs(target - current) <= maxDelta) return target;
  return current + Math.sign(target - current) * maxDelta;
}

export class FlightModel {
  state: FlightModelState;
  controls: FlightControls;

  constructor() {
    this.controls = {
      pitch: 0,
      roll: 0,
      yaw: 0,
      throttle: 0,
      flaps: 2,
      gearDown: true,
      brake: true,
      ap: false,
      targetAlt: 10_000,
      targetSpeed: 250,
      targetHeading: 45,
      paused: false,
    };
    this.state = this.freshState();
  }

  resetAt(lat: number, lon: number, elevationFt: number, heading: number): void {
    this.resetRunway();
    this.state.lat = lat;
    this.state.lon = lon;
    this.state.altFt = elevationFt;
    this.state.heading = heading;
    this.state.track = heading;
    this.controls.targetHeading = heading;
    this.controls.targetAlt = elevationFt + 10_000;
  }

  resetApproachAt(lat: number, lon: number, elevationFt: number, heading: number): void {
    this.resetRunway();
    this.state.lat = lat;
    this.state.lon = lon;
    this.state.altFt = elevationFt + 2000;
    this.state.heading = heading;
    this.state.track = heading;
    this.state.onGround = false;
    this.state.ias = 140;
    this.state.tas = 140;
    this.state.gs = 140;
    this.state.vsFpm = -700;
    this.state.flaps = 4;
    this.state.gearDown = true;
    this.state.brakes = false;
    this.state.n1 = 20;
    this.state.throttle = 20;
    this.controls.flaps = 4;
    this.controls.gearDown = true;
    this.controls.brake = false;
    this.controls.throttle = 20;
    this.controls.ap = true;
    this.controls.targetAlt = elevationFt;
    this.controls.targetSpeed = 135;
    this.controls.targetHeading = heading;
  }

  goAround(): void {
    if (this.state.onGround) {
      this.state.onGround = false;
      this.state.altFt += 50;
      this.state.ias = Math.max(150, this.state.ias);
      this.state.tas = this.state.ias;
    }
    this.state.vsFpm = 1200;
    this.state.pitch = 8;
    this.state.flaps = 2;
    this.state.gearDown = false;
    this.state.brakes = false;
    this.state.throttle = 100;
    this.state.n1 = 100;
    this.controls.throttle = 100;
    this.controls.flaps = 2;
    this.controls.gearDown = false;
    this.controls.brake = false;
    this.controls.ap = true;
    this.controls.targetAlt = this.state.altFt + 3000;
    this.controls.targetSpeed = 180;
    this.controls.targetHeading = this.state.heading;
  }

  private freshState(): FlightModelState {
    return {
      lat: 46.238,
      lon: 6.109,
      altFt: FIELD_ELEV_FT,
      ias: 0,
      tas: 0,
      gs: 0,
      vsFpm: 0,
      pitch: 0,
      roll: 0,
      heading: 45,
      track: 45,
      aoa: 0,
      gLoad: 1,
      n1: 0,
      throttle: 0,
      flaps: 2,
      gearDown: true,
      brakes: true,
      onGround: true,
      phase: 'PARKED',
      fuelKg: 12_000,
      massKg: EMPTY_MASS + PAYLOAD + 12_000,
      thrustKn: 0,
      paused: false,
      warning: '',
      touchdownVs: 0,
    };
  }

  resetRunway(): void {
    this.controls = {
      ...this.controls,
      pitch: 0,
      roll: 0,
      yaw: 0,
      throttle: 0,
      flaps: 2,
      gearDown: true,
      brake: true,
      ap: false,
      paused: false,
      targetAlt: 10_000,
      targetSpeed: 250,
      targetHeading: 45,
    };
    this.state = this.freshState();
  }

  resetApproach(): void {
    this.controls = {
      ...this.controls,
      pitch: 0,
      roll: 0,
      yaw: 0,
      throttle: 38,
      flaps: 3,
      gearDown: true,
      brake: false,
      ap: false,
      paused: false,
      targetAlt: FIELD_ELEV_FT,
      targetSpeed: 145,
      targetHeading: 45,
    };
    this.state = {
      ...this.freshState(),
      lat: 46.238 - 8 / 60,
      lon: 6.109,
      altFt: 3000,
      ias: 150,
      tas: 150,
      gs: 150,
      vsFpm: -700,
      pitch: 2,
      roll: 0,
      heading: 45,
      track: 45,
      onGround: false,
      phase: 'APPROACH',
      n1: 38,
      throttle: 38,
      flaps: 3,
      gearDown: true,
      brakes: false,
      fuelKg: 10_000,
      massKg: EMPTY_MASS + PAYLOAD + 10_000,
    };
  }

  setFlaps(detent: number): void {
    this.controls.flaps = clamp(Math.round(detent), 0, 4);
  }

  toggleGear(): void {
    this.controls.gearDown = !this.controls.gearDown;
  }

  toggleBrake(): void {
    this.controls.brake = !this.controls.brake;
  }

  toggleAp(): void {
    this.controls.ap = !this.controls.ap;
  }

  togglePause(): void {
    this.controls.paused = !this.controls.paused;
  }

  update(dtSeconds: number): FlightModelState {
    if (this.controls.paused) {
      this.state.paused = true;
      return this.state;
    }
    this.state.paused = false;
    const dt = clamp(dtSeconds, 0, 0.1);
    const s = this.state;
    const c = this.controls;

    s.throttle = c.throttle;
    s.flaps = c.flaps;
    s.gearDown = c.gearDown;
    s.brakes = c.brake;

    // Engine spool.
    s.n1 = moveTowards(s.n1, c.throttle, 28 * dt);
    s.massKg = EMPTY_MASS + PAYLOAD + s.fuelKg;

    if (c.ap && !s.onGround) {
      this.autopilot(dt);
    }

    const rho = 1.225 * Math.exp(-(s.altFt * FT) / 8500);
    const tasMs = Math.max(0.1, s.tas * KT);
    const q = 0.5 * rho * tasMs * tasMs;
    const flaps = clamp(Math.round(c.flaps), 0, 4);
    const thrustN = (s.n1 / 100) * MAX_THRUST_N * clamp(rho / 1.225, 0.25, 1.05);
    s.thrustKn = thrustN / 1000;

    const gamma = Math.asin(clamp(s.vsFpm / Math.max(1, s.tas * 196.85), -0.75, 0.75));
    let alpha = clamp(s.pitch - (gamma * 180) / Math.PI, -6, 18);
    if (s.onGround) alpha = s.pitch > 2 ? clamp(s.pitch * 0.9, 0, 14) : 0;

    let cl = 0.12 + 4.8 * ((alpha * Math.PI) / 180) + FLAP_CL[flaps];
    if (alpha > 14) cl *= Math.max(0.35, 1 - (alpha - 14) * 0.07);
    cl = clamp(cl, -0.6, 2.15);
    const cd = 0.021 + 0.043 * cl * cl + FLAP_CD[flaps] + (s.gearDown ? 0.016 : 0);
    const lift = q * WING_AREA * cl;
    const drag = q * WING_AREA * cd;
    const weight = s.massKg * G;

    s.aoa = alpha;
    s.gLoad = s.onGround ? 1 : lift / Math.max(1, weight);
    s.track = s.heading;
    s.warning = !s.onGround && (s.aoa > 15 || s.ias < 105) ? 'STALL' : s.ias > VFE[flaps] + 25 ? 'OVERSPEED' : '';

    if (s.onGround) {
      this.groundStep(dt, thrustN, drag, weight, lift);
    } else {
      this.airStep(dt, thrustN, drag, weight, lift, gamma, cl, flaps);
    }

    // Fuel burn, roughly 2 x N1 x 19 kg/h.
    s.fuelKg = Math.max(0, s.fuelKg - ((s.n1 * 19 * 2) / 3600) * dt);

    // Position integration.
    const gsMs = Math.max(0, s.gs * KT);
    const distanceNm = (gsMs * dt) / 1852;
    const headingRad = (s.heading * Math.PI) / 180;
    const latRad = (s.lat * Math.PI) / 180;
    s.lat += (distanceNm / 60) * Math.cos(headingRad);
    s.lon += (distanceNm / (60 * Math.max(0.1, Math.cos(latRad)))) * Math.sin(headingRad);

    this.updatePhase();
    return s;
  }

  private groundStep(dt: number, thrust: number, drag: number, weight: number, lift: number): void {
    const s = this.state;
    const c = this.controls;
    const rolling = weight * (c.brake ? 0.55 : 0.018);
    const accel = (thrust - drag - rolling) / s.massKg;
    s.tas = Math.max(0, s.tas + (accel / KT) * dt);
    if (c.brake && s.tas < 1) s.tas = 0;
    s.ias = s.tas;
    s.gs = s.tas;
    s.altFt = FIELD_ELEV_FT;
    s.vsFpm = 0;
    s.roll = moveTowards(s.roll, 0, 20 * dt);

    // Nosewheel steering / rudder.
    s.heading = (s.heading + c.yaw * 1.6 * dt * clamp(s.tas / 80, 0.2, 1) + 360) % 360;

    const vr = 145;
    if (s.tas > vr * 0.92 && c.pitch > 0.08) {
      s.pitch = moveTowards(s.pitch, 3 + c.pitch * 10, 8 * dt);
    } else {
      s.pitch = moveTowards(s.pitch, 0, 4 * dt);
    }
    s.aoa = 0;

    if (s.tas > vr && s.pitch > 2 && lift > weight * 0.92) {
      s.onGround = false;
      s.phase = 'TAKEOFF';
      s.vsFpm = 450;
      s.pitch = Math.max(6, s.pitch);
    }
  }

  private airStep(
    dt: number,
    thrust: number,
    drag: number,
    weight: number,
    lift: number,
    gamma: number,
    cl: number,
    flaps: number,
  ): void {
    const s = this.state;
    const c = this.controls;
    const tasMs = Math.max(1, s.tas * KT);

    // Bank / turn.
    const bankTarget = c.roll * 27;
    s.roll = moveTowards(s.roll, bankTarget, 22 * dt);
    const turnRate = (G * Math.tan((s.roll * Math.PI) / 180)) / Math.max(45, tasMs);
    s.heading = (s.heading + (turnRate * 180) / Math.PI * dt + c.yaw * 1.2 * dt + 360) % 360;

    // Pitch command: the sidestick directly commands a pitch attitude, while
    // alpha (pitch - flight path) still drives lift.
    const targetPitch = c.pitch >= 0 ? 2 + c.pitch * 12 : 2 + c.pitch * 9;
    s.pitch = moveTowards(s.pitch, targetPitch, 6 * dt);

    // Vertical response: lift surplus/deficit drives vertical speed.
    const loadFactor = lift / Math.max(1, weight);
    let targetVs = clamp((loadFactor - 1) * 3000, -5000, 5000);
    const radioAlt = s.altFt - FIELD_ELEV_FT;
    if (radioAlt < 80 && s.vsFpm < 0) targetVs = Math.max(targetVs, -180);
    if (s.tas < 115) targetVs = Math.min(targetVs, -400);
    if (s.aoa > 15.5) targetVs = Math.min(targetVs, -800);
    s.vsFpm += (targetVs - s.vsFpm) * clamp(3 * dt, 0, 1);
    s.altFt += (s.vsFpm / 60) * dt;

    // Speed integration along the flight path.
    const accel = (thrust * Math.cos((s.aoa * Math.PI) / 180) - drag - weight * Math.sin(gamma)) / s.massKg;
    s.tas = clamp(s.tas + (accel / KT) * dt, 45, 340);
    const rho = 1.225 * Math.exp(-(s.altFt * FT) / 8500);
    s.ias = s.tas * Math.sqrt(clamp(rho / 1.225, 0.3, 1.1));
    if (s.ias > VFE[flaps] + 25) {
      // Overspeed with flaps: add drag rather than silently exceeding VFE.
      s.tas = Math.max(45, s.tas - 6 * dt);
    }
    s.gs = s.ias + 6;

    // Touchdown.
    if (s.altFt <= FIELD_ELEV_FT + 2 && s.vsFpm <= 0) {
      s.touchdownVs = s.vsFpm;
      s.altFt = FIELD_ELEV_FT;
      s.onGround = true;
      s.pitch = 0;
      s.roll = 0;
      s.vsFpm = 0;
      s.phase = 'LANDED';
      s.tas = Math.min(s.tas, 145);
      s.ias = s.tas;
      s.gs = s.tas;
      this.controls.brake = true;
      this.controls.throttle = 0;
    }
  }

  private autopilot(dt: number): void {
    const s = this.state;
    const c = this.controls;
    const altError = c.targetAlt - s.altFt;
    const desiredVs = clamp(altError * 1.1, -1400, 1600);
    c.pitch = clamp((desiredVs - s.vsFpm) / 700, -0.9, 0.9);
    const speedError = c.targetSpeed - s.ias;
    c.throttle = clamp(c.throttle + speedError * 0.45 * dt, 0, 100);
    const hdgError = ((c.targetHeading - s.heading + 540) % 360) - 180;
    c.roll = clamp(hdgError / 35, -0.65, 0.65);
  }

  private updatePhase(): void {
    const s = this.state;
    if (s.onGround) {
      if (s.phase === 'LANDED') return;
      s.phase = s.tas < 1 ? 'PARKED' : 'TAXI';
      return;
    }
    if (s.vsFpm > 250) s.phase = 'CLIMB';
    else if (s.vsFpm < -250) s.phase = s.altFt < 3500 ? 'APPROACH' : 'DESCENT';
    else s.phase = 'CRUISE';
  }
}
