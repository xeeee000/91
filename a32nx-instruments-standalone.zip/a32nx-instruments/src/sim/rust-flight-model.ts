/**
 * Browser wrapper around the Rust `sim-core` wasm module.
 *
 * The Rust core owns the flight dynamics; this class only marshals the control
 * state and exposes the same shape as the TypeScript fallback model.
 */

const PHASES = ['PARKED', 'TAXI', 'TAKEOFF', 'CLIMB', 'CRUISE', 'DESCENT', 'APPROACH', 'LANDED'] as const;
const WARNINGS = ['', 'STALL', 'OVERSPEED'] as const;

type WasmExports = {
  memory: WebAssembly.Memory;
  sim_reset: (mode: number) => void;
  sim_reset_at: (lat: number, lon: number, elevationFt: number, heading: number) => void;
  sim_go_around: () => void;
  sim_reset_approach_at: (lat: number, lon: number, elevationFt: number, heading: number) => void;
  sim_set_controls: (
    pitch: number,
    roll: number,
    yaw: number,
    throttle: number,
    flaps: number,
    gear: number,
    brake: number,
    ap: number,
    targetAlt: number,
    targetSpeed: number,
    targetHeading: number,
    paused: number,
  ) => void;
  sim_step: (dt: number) => void;
  sim_state_ptr: () => number;
};

export class RustFlightModel {
  readonly source = 'rust-wasm';
  controls = {
    pitch: 0,
    roll: 0,
    yaw: 0,
    throttle: 0,
    flaps: 2,
    gearDown: true,
    brake: true,
    ap: false,
    targetAlt: 10_000,
    targetSpeed: 250,
    targetHeading: 45,
    paused: false,
  };

  state: any = {};

  private constructor(private readonly wasm: WasmExports) {
    this.read();
  }

  static async load(url = new URL('wasm/sim_core.wasm', document.baseURI).toString()): Promise<RustFlightModel> {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`sim_core.wasm: HTTP ${response.status}`);
    let instance: WebAssembly.Instance;
    if (WebAssembly.instantiateStreaming) {
      try {
        ({ instance } = await WebAssembly.instantiateStreaming(response.clone(), {}));
      } catch {
        const bytes = await response.arrayBuffer();
        ({ instance } = await WebAssembly.instantiate(bytes, {}));
      }
    } else {
      const bytes = await response.arrayBuffer();
      ({ instance } = await WebAssembly.instantiate(bytes, {}));
    }
    return new RustFlightModel(instance.exports as unknown as WasmExports);
  }

  private read(): void {
    const ptr = this.wasm.sim_state_ptr();
    const b = new Float64Array(this.wasm.memory.buffer, ptr, 32);
    this.state = {
      lat: b[0],
      lon: b[1],
      altFt: b[2],
      ias: b[3],
      tas: b[4],
      gs: b[5],
      vsFpm: b[6],
      pitch: b[7],
      roll: b[8],
      heading: b[9],
      track: b[10],
      aoa: b[11],
      gLoad: b[12],
      n1: b[13],
      throttle: b[14],
      flaps: b[15],
      gearDown: b[16] > 0.5,
      brakes: b[17] > 0.5,
      onGround: b[18] > 0.5,
      phase: PHASES[b[19]] ?? 'PARKED',
      fuelKg: b[20],
      massKg: b[21],
      thrustKn: b[22],
      warning: WARNINGS[b[23]] ?? '',
      touchdownVs: b[24],
      pitchRate: b[25],
      rollRate: b[26],
      yawRate: b[27],
      fieldElev: b[28],
    };
  }

  private pushControls(): void {
    const c = this.controls;
    this.wasm.sim_set_controls(
      c.pitch,
      c.roll,
      c.yaw,
      c.throttle,
      c.flaps,
      c.gearDown ? 1 : 0,
      c.brake ? 1 : 0,
      c.ap ? 1 : 0,
      c.targetAlt,
      c.targetSpeed,
      c.targetHeading,
      c.paused ? 1 : 0,
    );
  }

  update(dt: number): any {
    this.pushControls();
    this.wasm.sim_step(dt);
    this.read();
    return this.state;
  }

  private reset(mode: number): void {
    this.wasm.sim_reset(mode);
    this.controls = {
      pitch: 0,
      roll: 0,
      yaw: 0,
      throttle: mode === 1 ? 38 : 0,
      flaps: mode === 1 ? 3 : 2,
      gearDown: true,
      brake: mode !== 1,
      ap: false,
      targetAlt: mode === 1 ? 1411 : 10_000,
      targetSpeed: mode === 1 ? 145 : 250,
      targetHeading: 45,
      paused: false,
    };
    this.read();
  }

  resetRunway(): void {
    this.reset(0);
  }

  resetAt(lat: number, lon: number, elevationFt: number, heading: number): void {
    this.wasm.sim_reset_at(lat, lon, elevationFt, heading);
    this.controls = {
      pitch: 0,
      roll: 0,
      yaw: 0,
      throttle: 0,
      flaps: 2,
      gearDown: true,
      brake: true,
      ap: false,
      targetAlt: elevationFt + 10_000,
      targetSpeed: 250,
      targetHeading: heading,
      paused: false,
    };
    this.read();
  }

  resetApproachAt(lat: number, lon: number, elevationFt: number, heading: number): void {
    this.wasm.sim_reset_approach_at(lat, lon, elevationFt, heading);
    this.read();
    this.controls = {
      ...this.controls,
      throttle: 20,
      flaps: 4,
      gearDown: true,
      brake: false,
      ap: true,
      targetAlt: elevationFt,
      targetSpeed: 135,
      targetHeading: heading,
    };
  }

  goAround(): void {    this.wasm.sim_go_around();
    this.read();
    this.controls = {
      ...this.controls,
      throttle: 100,
      flaps: 2,
      gearDown: false,
      brake: false,
      ap: true,
      targetAlt: this.state.fieldElev + 3000,
      targetSpeed: 180,
      targetHeading: this.state.heading,
    };
  }

  resetApproach(): void {
    this.reset(1);
  }

  setFlaps(detent: number): void {
    this.controls.flaps = Math.max(0, Math.min(4, Math.round(detent)));
  }

  toggleGear(): void {
    this.controls.gearDown = !this.controls.gearDown;
  }

  toggleBrake(): void {
    this.controls.brake = !this.controls.brake;
  }

  toggleAp(): void {
    this.controls.ap = !this.controls.ap;
  }

  togglePause(): void {
    this.controls.paused = !this.controls.paused;
  }
}
