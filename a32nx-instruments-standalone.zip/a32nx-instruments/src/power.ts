import './styles/power.css';

/**
 * Applies the overhead AC/DC bus state to standalone instrument pages.
 * Pages that never receive an overhead message stay powered, so opening
 * fcu.html or mcdu.html directly still works.
 */
export function installInstrumentPower(bus: 'ac' | 'dc'): void {
  try {
    const channel = new BroadcastChannel('a32nx-overhead');
    channel.onmessage = (event: MessageEvent) => {
      const derived = event.data?.derived;
      if (!derived) return;
      document.body.classList.toggle('unpowered', !derived[bus]);
    };
    channel.postMessage({ type: 'power-request' });
  } catch {
    // BroadcastChannel is unavailable in some embedded webviews; keep powered.
  }
}
