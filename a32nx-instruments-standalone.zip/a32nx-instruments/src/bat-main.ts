import './harness/globals';
import './styles/bat.css';
import { installInstrumentPower } from './power';
installInstrumentPower('dc');
import { simVars } from './harness/simvar-store';

simVars.set('L:A32NX_OVHD_INTLT_ANN', 1, 'bool');
simVars.set('L:A32NX_ELEC_DC_2_BUS_IS_POWERED', 1, 'bool');
simVars.set('L:A32NX_ELEC_BAT_1_POTENTIAL', 28, 'volts');
simVars.set('L:A32NX_ELEC_BAT_2_POTENTIAL', 28, 'volts');

import('./instruments/bat-entry').then(() => {
  const root = document.getElementById('MSFS_REACT_MOUNT')?.parentElement ?? document.body;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 600, window.innerHeight / 300);
    document.documentElement.style.setProperty('--bat-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(): void {
    root.dispatchEvent(new Event('update'));
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});