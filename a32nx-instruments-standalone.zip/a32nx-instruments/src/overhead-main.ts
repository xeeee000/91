import './styles/overhead.css';
import { derived, overhead, OverheadSwitch, publishOverhead, resetColdDark } from './data/overhead-state';

const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('.oh-sw'));
let apuTimer = 0;
const engineTimers = { 1: 0, 2: 0 };
const agentTimers = { 1: 0, 2: 0, apu: 0 };
let adirsTimer = 0;
let holdUntil = 0;
let holdText = '';

function flash(text: string): void {
  holdText = text;
  holdUntil = performance.now() + 3000;
  const msg = document.getElementById('oh-msg');
  if (msg) msg.textContent = text;
}
let last = performance.now();

function setLight(name: string, on: boolean, color: 'green' | 'amber' = 'green'): void {
  const element = document.querySelector<HTMLElement>(`[data-light="${name}"]`);
  if (!element) return;
  element.classList.toggle('on', on);
  element.classList.toggle('green', color === 'green');
  element.classList.toggle('amber', color === 'amber');
}

function render(): void {
  for (const button of buttons) {
    const key = button.dataset.sw as OverheadSwitch | undefined;
    if (!key) continue;
    button.classList.toggle('on', Boolean(overhead[key]));
  }

  const d = derived();
  setLight('ac', d.ac, 'green');
  setLight('dc', d.dc, 'green');
  setLight('apuAvail', overhead.apuAvailable, 'green');
  setLight('apuGenOn', overhead.apuGen && overhead.apuAvailable, 'green');
  setLight('eng1Run', overhead.eng1Running, 'green');
  setLight('eng2Run', overhead.eng2Running, 'green');
  setLight('eng1Fire', overhead.eng1Fire, 'amber');
  setLight('eng2Fire', overhead.eng2Fire, 'amber');
  setLight('apuFire', overhead.apuFire, 'amber');
  setLight('apuFail', overhead.apuFail, 'amber');
  setLight('cargoSmoke', overhead.cargoSmoke, 'amber');
  setLight('pressFault', overhead.pressFault, 'amber');
  setLight('gearFail', overhead.gearFail, 'amber');
  setLight('elac1Fail', overhead.elac1Fail, 'amber');
  setLight('sec1Fail', overhead.sec1Fail, 'amber');
  setLight('fac1Fail', overhead.fac1Fail, 'amber');
  setLight('fuel', d.fuelLeft || d.fuelRight || d.fuelCenter, 'green');
  setLight('fuelLeak', overhead.fuelLeakL || overhead.fuelLeakR, 'amber');
  setLight('cabinDoor', overhead.cabinDoor, 'amber');
  setLight('cargoDoor', overhead.cargoDoor, 'amber');
  setLight('oxyFail', overhead.oxyFail, 'amber');
  setLight('hotAirFault', overhead.hotAirFault, 'amber');
  setLight('lights', overhead.navLights || overhead.beaconLights || overhead.strobeLights || overhead.landingLights || overhead.taxiLights, 'green');
  setLight('packs', d.packs, 'green');
  setLight('adirs', overhead.adirsAligned, 'green');

  const ac = document.getElementById('st-ac');
  const dc = document.getElementById('st-dc');
  const apu = document.getElementById('st-apu');
  const hyd = document.getElementById('st-hyd');
  if (ac) ac.textContent = d.ac ? 'ON' : 'OFF';
  if (dc) dc.textContent = d.dc ? 'ON' : 'OFF';
  if (apu) apu.textContent = overhead.apuAvailable ? 'AVAIL' : overhead.apuStart ? 'START' : 'OFF';
  if (hyd) {
    hyd.textContent = `${d.hydGreen ? 'G' : '-'}/${d.hydBlue ? 'B' : '-'}/${d.hydYellow ? 'Y' : '-'}`;
  }

  const msg = document.getElementById('oh-msg');
  if (msg) {
    if (performance.now() < holdUntil) msg.textContent = holdText;
    else if (overhead.eng1Start) msg.textContent = 'ENGINE 1 STARTING · WAIT FOR IDLE';
    else if (overhead.eng2Start) msg.textContent = 'ENGINE 2 STARTING · WAIT FOR IDLE';
    else if (overhead.apuStart) msg.textContent = 'APU STARTING · WAIT FOR AVAIL';
    else if (!d.ac) msg.textContent = 'NO AC POWER · SELECT EXT PWR OR START APU';
    else if (!d.dc) msg.textContent = 'NO DC POWER · BAT 1/2 OFF';
    else msg.textContent = 'AC/DC WIRED · SYSTEM LOGIC PARTIAL';
  }
}

function bleedReady(): boolean {
  return (overhead.apuBleed && overhead.apuAvailable) || (overhead.xbleed && (overhead.eng1Running || overhead.eng2Running));
}

for (const button of buttons) {
  button.addEventListener('click', () => {
    const key = button.dataset.sw as OverheadSwitch | undefined;
    if (!key) return;
    if (key === 'apuStart') {
      if (!overhead.apuMaster) {
        const msg = document.getElementById('oh-msg');
        if (msg) msg.textContent = 'APU MASTER SW OFF';
        return;
      }
      if (!derived().dc) {
        flash('NO DC POWER · BAT 1 OR EXT PWR REQUIRED');
        return;
      }
      overhead.apuStart = true;
      apuTimer = 0;
      return;
    }
    if (key === 'apuGen' && !overhead.apuAvailable) {
      const msg = document.getElementById('oh-msg');
      if (msg) msg.textContent = 'APU NOT AVAILABLE';
      return;
    }
    if (key === 'eng1Start' || key === 'eng2Start') {
      const engine = key === 'eng1Start' ? 1 : 2;
      const master = engine === 1 ? overhead.eng1Master : overhead.eng2Master;
      if (!master) {
        const msg = document.getElementById('oh-msg');
        if (msg) msg.textContent = `ENG ${engine} MASTER OFF`;
        return;
      }
      if (!derived().dc) {
        flash('NO DC POWER · BAT OR EXT PWR REQUIRED');
        return;
      }
      if (!(engine === 1 ? overhead.fuelL : overhead.fuelR)) {
        flash(`ENG ${engine} · FUEL PUMPS OFF`);
        return;
      }
      if (!bleedReady()) {
        const msg = document.getElementById('oh-msg');
        if (msg) msg.textContent = 'NO BLEED · APU BLEED OR XBLEED REQUIRED';
        return;
      }
      if (engine === 1) {
        overhead.eng1Start = true;
        engineTimers[1] = 0;
      } else {
        overhead.eng2Start = true;
        engineTimers[2] = 0;
      }
      return;
    }
    if (key === 'eng1Fail' || key === 'eng2Fail' || key === 'apuFail') {
      const on = !overhead[key];
      (overhead as unknown as Record<string, boolean>)[key] = on;
      if (on && key === 'eng1Fail') {
        overhead.eng1Master = false;
        overhead.eng1Running = false;
        overhead.eng1Start = false;
      }
      if (on && key === 'eng2Fail') {
        overhead.eng2Master = false;
        overhead.eng2Running = false;
        overhead.eng2Start = false;
      }
      if (on && key === 'apuFail') {
        overhead.apuMaster = false;
        overhead.apuAvailable = false;
        overhead.apuStart = false;
        overhead.apuGen = false;
        overhead.apuBleed = false;
      }
      return;
    }
    if (key === 'eng1Fire' || key === 'eng2Fire' || key === 'apuFire') {
      const on = !overhead[key];
      (overhead as unknown as Record<string, boolean>)[key] = on;
      if (on && key === 'eng1Fire') {
        overhead.eng1Master = false;
        overhead.eng1Running = false;
        overhead.eng1Start = false;
      }
      if (on && key === 'eng2Fire') {
        overhead.eng2Master = false;
        overhead.eng2Running = false;
        overhead.eng2Start = false;
      }
      if (on && key === 'apuFire') {
        overhead.apuMaster = false;
        overhead.apuAvailable = false;
        overhead.apuStart = false;
        overhead.apuGen = false;
        overhead.apuBleed = false;
      }
      return;
    }
    if (key === 'eng1Agent' || key === 'eng2Agent' || key === 'apuAgent') {
      const fireKey = key === 'eng1Agent' ? 'eng1Fire' : key === 'eng2Agent' ? 'eng2Fire' : 'apuFire';
      if (!overhead[fireKey]) {
        const msg = document.getElementById('oh-msg');
        if (msg) msg.textContent = 'NO FIRE · AGENT NOT DISCHARGED';
        return;
      }
      const timerKey = key === 'eng1Agent' ? 1 : key === 'eng2Agent' ? 2 : 'apu';
      agentTimers[timerKey] = 0;
      (overhead as unknown as Record<string, boolean>)[key] = true;
      const msg = document.getElementById('oh-msg');
      if (msg) msg.textContent = 'FIRE AGENT DISCHARGED · WAIT 5 S';
      return;
    }
    (overhead as unknown as Record<string, boolean>)[key] = !overhead[key];
  });
}

document.getElementById('oh-reset')?.addEventListener('click', () => {
  resetColdDark();
  apuTimer = 0;
  engineTimers[1] = 0;
  engineTimers[2] = 0;
  agentTimers[1] = 0;
  agentTimers[2] = 0;
  agentTimers.apu = 0;
  render();
});

document.getElementById('oh-qrh')?.addEventListener('click', () => {
  document.getElementById('qrh-modal')?.classList.toggle('hidden');
});
document.getElementById('qrh-close')?.addEventListener('click', () => {
  document.getElementById('qrh-modal')?.classList.add('hidden');
});

function tick(now: number): void {
  const dt = Math.min(0.5, (now - last) / 1000);
  last = now;

  if (!overhead.apuMaster) {
    overhead.apuAvailable = false;
    overhead.apuStart = false;
    overhead.apuGen = false;
    apuTimer = 0;
  } else if (overhead.apuStart && !overhead.apuAvailable) {
    apuTimer += dt;
    if (apuTimer >= 5) {
      overhead.apuAvailable = true;
      overhead.apuStart = false;
    }
  }

  if (!overhead.apuAvailable) overhead.apuGen = false;

  if (overhead.adirs1 && overhead.adirs2 && overhead.adirs3) {
    if (!overhead.adirsAligned) {
      adirsTimer += dt;
      if (adirsTimer >= 10) {
        overhead.adirsAligned = true;
        adirsTimer = 0;
      }
    }
  } else {
    overhead.adirsAligned = false;
    adirsTimer = 0;
  }

  if (overhead.eng1Fire && overhead.eng1Agent) {
    agentTimers[1] += dt;
    if (agentTimers[1] >= 5) {
      overhead.eng1Fire = false;
      overhead.eng1Agent = false;
      agentTimers[1] = 0;
    }
  }
  if (overhead.eng2Fire && overhead.eng2Agent) {
    agentTimers[2] += dt;
    if (agentTimers[2] >= 5) {
      overhead.eng2Fire = false;
      overhead.eng2Agent = false;
      agentTimers[2] = 0;
    }
  }
  if (overhead.apuFire && overhead.apuAgent) {
    agentTimers.apu += dt;
    if (agentTimers.apu >= 5) {
      overhead.apuFire = false;
      overhead.apuAgent = false;
      agentTimers.apu = 0;
    }
  }

  for (const engine of [1, 2] as const) {
    if (engine === 1 && overhead.eng1Fail) {
      overhead.eng1Master = false;
      overhead.eng1Running = false;
      overhead.eng1Start = false;
    }
    if (engine === 2 && overhead.eng2Fail) {
      overhead.eng2Master = false;
      overhead.eng2Running = false;
      overhead.eng2Start = false;
    }
    const master = engine === 1 ? overhead.eng1Master : overhead.eng2Master;
    const running = engine === 1 ? overhead.eng1Running : overhead.eng2Running;
    const start = engine === 1 ? overhead.eng1Start : overhead.eng2Start;
    if (!master) {
      if (engine === 1) {
        overhead.eng1Running = false;
        overhead.eng1Start = false;
      } else {
        overhead.eng2Running = false;
        overhead.eng2Start = false;
      }
      engineTimers[engine] = 0;
      continue;
    }
    if (start && !running && bleedReady()) {
      engineTimers[engine] += dt;
      if (engineTimers[engine] >= 18) {
        engineTimers[engine] = 0;
        if (engine === 1) {
          overhead.eng1Running = true;
          overhead.eng1Start = false;
        } else {
          overhead.eng2Running = true;
          overhead.eng2Start = false;
        }
      }
    }
  }

  render();
  publishOverhead();
  requestAnimationFrame(tick);
}

render();
publishOverhead();
requestAnimationFrame(tick);
