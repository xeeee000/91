import './harness/globals';
import './styles/isis.css';
import { isisFlight, publishIsisState } from './data/isis-feed';

publishIsisState();

const channel = new BroadcastChannel('a32nx-sim');
channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.altitude === 'number') isisFlight.altitude = s.altitude;
  if (typeof s.ias === 'number') {
    isisFlight.ias = s.ias;
    isisFlight.mach = Math.min(0.82, s.ias / 620);
  }
  if (typeof s.pitch === 'number') isisFlight.pitch = s.pitch;
  if (typeof s.roll === 'number') isisFlight.roll = s.roll;
  publishIsisState();
};

import('./instruments/isis-entry').then(() => {
  const mount = document.getElementById('MSFS_REACT_MOUNT');
  const root = mount?.parentElement ?? document.body;

  let last = performance.now();
  let lastPublish = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 512, window.innerHeight / 512);
    document.documentElement.style.setProperty('--isis-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;

    if (now - lastPublish > 150) {
      lastPublish = now;
      publishIsisState();
    }

    // Drives the original React `useUpdate` hooks.
    root.dispatchEvent(new Event('update'));
    // Keep the frame loop alive for the sim clock.
    void dt;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
