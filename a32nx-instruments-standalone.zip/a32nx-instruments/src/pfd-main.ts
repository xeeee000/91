import './harness/globals';
import './styles/pfd.css';
import { flight, publishPfdState } from './data/pfd-feed';
import { fmaState, LateralMode, VerticalMode } from './data/fma-state';
import { approachState } from './data/approach-state';
import { pfdTargets } from './data/pfd-targets';
import { simVars } from './harness/simvar-store';

publishPfdState();

const channel = new BroadcastChannel('a32nx-sim');
let externallyControlled = false;

channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.altitude === 'number') {
    flight.altitude = s.altitude;
    // Radio altitude is only meaningful close to the ground; use it for the
    // automatic LAND / FLARE / ROLL OUT FMA transitions.
    flight.radioAltitude = typeof s.radioAltitude === 'number' ? Math.max(0, s.radioAltitude) : s.altitude <= 2500 ? Math.max(0, s.altitude) : 0;
  }
  if (typeof s.ias === 'number') {
    flight.ias = s.ias;
    flight.tas = typeof s.tas === 'number' ? s.tas : s.ias + 30;
    flight.groundSpeed = typeof s.groundSpeed === 'number' ? s.groundSpeed : Math.max(0, s.ias - 5);
    flight.mach = typeof s.mach === 'number' ? s.mach : Math.min(0.82, s.ias / 620);
  }
  if (typeof s.latitude === 'number') flight.latitude = s.latitude;
  if (typeof s.longitude === 'number') flight.longitude = s.longitude;
  if (typeof s.radioAltitude === 'number') flight.radioAltitude = Math.max(0, s.radioAltitude);
  if (typeof s.heading === 'number') {
    flight.heading = s.heading;
    flight.track = s.heading;
  }
  if (typeof s.verticalSpeed === 'number') flight.verticalSpeed = s.verticalSpeed;
  if (typeof s.pitch === 'number') flight.pitch = s.pitch;
  if (typeof s.roll === 'number') flight.roll = s.roll;
  if (typeof s.lateral === 'string') fmaState.lateral = s.lateral as LateralMode;
  if (typeof s.vertical === 'string') fmaState.vertical = s.vertical as VerticalMode;
  if (typeof s.ap === 'boolean') fmaState.ap = s.ap;
  if (typeof s.locDeviation === 'number') approachState.locDeviation = s.locDeviation;
  if (typeof s.gsDeviation === 'number') approachState.gsDeviation = s.gsDeviation;
  if (typeof s.ilsCourse === 'number') approachState.course = s.ilsCourse;
  if (typeof s.fcuSpeed === 'number') pfdTargets.speed = s.fcuSpeed;
  if (typeof s.fcuAltitude === 'number') pfdTargets.altitude = s.fcuAltitude;
  externallyControlled = true;

  const filter = (document.querySelector('a32nx-pfd') as any)?.arincProvider?.altitudeFilter;
  if (filter && typeof s.altitude === 'number') {
    filter.PreviousInput = s.altitude;
    filter.PreviousOutput = s.altitude;
  }
  publishPfdState();
};

// Loaded dynamically so all SimVars exist before the original instrument boots.
import('./instruments/pfd-entry').then(() => {
  const host = document.querySelector('a32nx-pfd') as any;

  // Seed the original altitude lag filter with the current altitude so the
  // display powers up already settled (the filter otherwise ramps from 0).
  const provider = host?.arincProvider;
  if (provider?.altitudeFilter) {
    const alt = (globalThis as any).__A32NX_FLIGHT__?.altitude ?? 0;
    provider.altitudeFilter.PreviousInput = alt;
    provider.altitudeFilter.PreviousOutput = alt;
  }

  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 768, window.innerHeight / 768);
    document.documentElement.style.setProperty('--pfd-scale', String(scale));
  }

  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 80) {
      lastPublish = now;
      // Advance sim time; the original clock/filter logic depends on it.
      simVars.set('E:SIMULATION TIME', phase, 'seconds');
      simVars.set('E:ABSOLUTE TIME', 63_900_000_000 + phase, 'seconds');
      // Gentle motion proves the whole original data -> render pipeline is live,
      // but stop as soon as the cockpit control panel takes over.
      const sim = (globalThis as any).__A32NX_FLIGHT__;
      if (sim && !externallyControlled) {
        sim.pitch = 2.5 + Math.sin(phase * 0.5) * 1.5;
        sim.roll = Math.sin(phase * 0.3) * 4;
        sim.heading = (45 + Math.sin(phase * 0.2) * 3 + 360) % 360;
        sim.track = sim.heading;
      }
      publishPfdState();
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
});
