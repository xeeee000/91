import './harness/globals';
import './styles/clock.css';
import { publishClockState } from './data/clock-feed';

const phaseStart = performance.now();
publishClockState(0);

import('./instruments/clock-entry').then(() => {
  const host = document.querySelector('a32nx-clock') as any;
  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 256, window.innerHeight / 256);
    document.documentElement.style.setProperty('--clock-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 200) {
      lastPublish = now;
      publishClockState(phase);
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
