import './harness/globals';
import './styles/sd-full.css';
import { publishSdState } from './data/sd-feed';
import { flight } from './data/pfd-feed';
import { engineState } from './data/engine-state';
import { systemsState, hydPressures } from './data/systems-state';

// ?page=0..11 selects an ECAM SD page (0 = ENG, 3 = ELEC, 5 = FUEL, ...).
const requestedPage = Number(new URLSearchParams(window.location.search).get('page') ?? 0);
const page = Number.isFinite(requestedPage) && requestedPage >= 0 && requestedPage <= 12 ? requestedPage : 0;

publishSdState(page);

const channel = new BroadcastChannel('a32nx-sim');
channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.n1 === 'number') engineState.n1 = s.n1;
  if (typeof s.fuel === 'number') engineState.fuel = s.fuel;
  if (typeof s.gen1 === 'boolean') systemsState.gen1 = s.gen1;
  if (typeof s.gen2 === 'boolean') systemsState.gen2 = s.gen2;
  if (typeof s.hydGreen === 'boolean') systemsState.hydGreen = s.hydGreen;
  if (typeof s.hydBlue === 'boolean') systemsState.hydBlue = s.hydBlue;
  if (typeof s.hydYellow === 'boolean') systemsState.hydYellow = s.hydYellow;
  if (typeof s.hydGreenPressure === 'number') hydPressures.green = s.hydGreenPressure;
  if (typeof s.hydBluePressure === 'number') hydPressures.blue = s.hydBluePressure;
  if (typeof s.hydYellowPressure === 'number') hydPressures.yellow = s.hydYellowPressure;
  if (typeof s.fuelL === 'boolean') systemsState.fuelL = s.fuelL;
  if (typeof s.fuelR === 'boolean') systemsState.fuelR = s.fuelR;
  if (typeof s.fuelC === 'boolean') systemsState.fuelC = s.fuelC;
  if (typeof s.xfeed === 'boolean') systemsState.xfeed = s.xfeed;
  if (typeof s.apuMaster === 'boolean') systemsState.apuMaster = s.apuMaster;
  if (typeof s.apuAvailable === 'boolean') systemsState.apuAvailable = s.apuAvailable;
  if (typeof s.apuGen === 'boolean') systemsState.apuGen = s.apuGen;
  if (typeof s.apuBleed === 'boolean') systemsState.apuBleed = s.apuBleed;
  if (typeof s.wingAntiIce === 'boolean') systemsState.wingAntiIce = s.wingAntiIce;
  if (typeof s.pressAuto === 'boolean') systemsState.pressAuto = s.pressAuto;
  if (typeof s.pressFault === 'boolean') systemsState.pressFault = s.pressFault;
  if (typeof s.fuelLeakL === 'boolean') systemsState.fuelLeakL = s.fuelLeakL;
  if (typeof s.fuelLeakR === 'boolean') systemsState.fuelLeakR = s.fuelLeakR;
  if (typeof s.cabinDoor === 'boolean') systemsState.cabinDoor = s.cabinDoor;
  if (typeof s.cargoDoor === 'boolean') systemsState.cargoDoor = s.cargoDoor;
  if (typeof s.oxyFail === 'boolean') systemsState.oxyFail = s.oxyFail;
  if (typeof s.navLights === 'boolean') systemsState.navLights = s.navLights;
  if (typeof s.beaconLights === 'boolean') systemsState.beaconLights = s.beaconLights;
  if (typeof s.strobeLights === 'boolean') systemsState.strobeLights = s.strobeLights;
  if (typeof s.landingLights === 'boolean') systemsState.landingLights = s.landingLights;
  if (typeof s.taxiLights === 'boolean') systemsState.taxiLights = s.taxiLights;
  if (typeof s.altitude === 'number') flight.altitude = s.altitude;
  publishSdState(page);
};

import('./instruments/sd-full-entry').then(() => {
  const mount = document.getElementById('MSFS_REACT_MOUNT');
  const root = mount?.parentElement ?? document.body;

  let last = performance.now();
  let lastPublish = 0;

  function fit(): void {
    const scale = Math.min(window.innerWidth / 600, window.innerHeight / 600);
    document.documentElement.style.setProperty('--sd-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;

    if (now - lastPublish > 200) {
      lastPublish = now;
      publishSdState(page);
    }

    void dt;
    root.dispatchEvent(new Event('update'));
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
