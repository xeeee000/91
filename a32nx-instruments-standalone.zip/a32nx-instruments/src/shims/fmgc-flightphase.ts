export { FlightPhaseManager } from '../../vendor/fbw-a32nx/src/systems/fmgc/src/flightphase/FlightPhaseManager';

// Type-only event map in the upstream source. A runtime value is exported here
// so esbuild can satisfy legacy value imports from `@fmgc/flightphase`.
export const FlightPhaseManagerEvents = {} as Record<string, unknown>;