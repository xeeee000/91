export { FlightPhaseManager } from '../../../../vendor/fbw-a32nx/src/systems/fmgc/src/flightphase/FlightPhaseManager';

export const FlightPhaseManagerEvents = {} as Record<string, unknown>;