const tabs = Array.from(document.querySelectorAll<HTMLButtonElement>('.tab'));
const frame = document.getElementById('panel-frame') as HTMLIFrameElement | null;
const strip = document.getElementById('fcu-strip');
const rmpStrip = document.getElementById('rmp-strip');

const sources: Record<string, string> = {
  fcu: 'fcu.html',
  rmp: 'rmp.html',
  bat: 'bat.html',
  atc: 'atc.html',
  mcdu: 'mcdu.html',
  overhead: 'overhead.html',
};

const channel = new BroadcastChannel('a32nx-sim');

const fcuInputs = {
  speed: document.getElementById('fcu-spd') as HTMLInputElement | null,
  heading: document.getElementById('fcu-hdg') as HTMLInputElement | null,
  altitude: document.getElementById('fcu-alt') as HTMLInputElement | null,
  vs: document.getElementById('fcu-vs') as HTMLInputElement | null,
};

const managed = {
  speedManaged: false,
  headingManaged: false,
  altitudeManaged: false,
};

const rmpInputs = {
  active: document.getElementById('rmp-active') as HTMLInputElement | null,
  standby: document.getElementById('rmp-standby') as HTMLInputElement | null,
};

function publishRmp(): void {
  channel.postMessage({
    rmpActiveMHz: Number(rmpInputs.active?.value ?? 118.7),
    rmpStandbyMHz: Number(rmpInputs.standby?.value ?? 121.5),
  });
}

function publishFcu(): void {
  channel.postMessage({
    fcuSpeed: Number(fcuInputs.speed?.value ?? 250),
    fcuHeading: Number(fcuInputs.heading?.value ?? 45),
    fcuAltitude: Number(fcuInputs.altitude?.value ?? 20000),
    fcuVs: Number(fcuInputs.vs?.value ?? 0),
    fcuSpeedManaged: managed.speedManaged,
    fcuHeadingManaged: managed.headingManaged,
    fcuAltitudeManaged: managed.altitudeManaged,
  });
}

function select(panel: string): void {
  if (!frame || !sources[panel]) return;
  frame.src = sources[panel];
  tabs.forEach((t) => t.classList.toggle('active', t.dataset.panel === panel));
  if (strip) strip.style.display = panel === 'fcu' ? 'flex' : 'none';
  if (rmpStrip) rmpStrip.style.display = panel === 'rmp' ? 'flex' : 'none';  if (panel === 'fcu') publishFcu();
  if (panel === 'rmp') publishRmp();
}

tabs.forEach((tab) => tab.addEventListener('click', () => select(tab.dataset.panel ?? 'fcu')));
Object.values(fcuInputs).forEach((input) => input?.addEventListener('input', publishFcu));
Object.values(rmpInputs).forEach((input) => input?.addEventListener('input', publishRmp));

document.querySelectorAll<HTMLButtonElement>('[data-step]').forEach((button) => {
  button.addEventListener('click', () => {
    const [field, deltaText] = (button.dataset.step ?? '').split(':');
    const input = fcuInputs[field as keyof typeof fcuInputs];
    if (!input) return;
    const delta = Number(deltaText);
    let value = Number(input.value) + delta;
    if (field === 'speed') value = Math.max(100, Math.min(399, value));
    if (field === 'heading') value = (value + 360) % 360;
    if (field === 'altitude') value = Math.max(0, Math.min(40000, value));
    if (field === 'vs') value = Math.max(-6000, Math.min(6000, value));
    input.value = String(value);
    publishFcu();
  });
});

document.querySelectorAll<HTMLButtonElement>('[data-managed]').forEach((button) => {
  button.addEventListener('click', () => {
    const key = button.dataset.managed as keyof typeof managed;
    managed[key] = !managed[key];
    button.classList.toggle('on', managed[key]);
    publishFcu();
  });
});

frame?.addEventListener('load', () => {
  publishFcu();
  publishRmp();
});
setInterval(() => {
  publishFcu();
  publishRmp();
}, 500);

frame?.addEventListener('dblclick', () => {
  void frame.requestFullscreen?.();
});
