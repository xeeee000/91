import './harness/globals';
import './styles/pfd.css';
import { flight } from './data/pfd-feed';
import { fmaState, LateralMode } from './data/fma-state';
import { ndState } from './data/nd-state';
import { publishNdState } from './data/nd-feed';
import { publishRoute, routeState } from './data/route-feed';
import { simVars } from './harness/simvar-store';

publishNdState();

const channel = new BroadcastChannel('a32nx-sim');
const fmsChannel = new BroadcastChannel('a32nx-fms');
let routeSignature = '';

fmsChannel.onmessage = (event: MessageEvent) => {
  const data = event.data ?? {};
  if (Array.isArray(data.route) && data.route.length > 0) {
    const signature = data.route.map((p: any) => `${p.ident}:${p.lat}:${p.long}`).join('|');
    if (signature !== routeSignature) {
      routeSignature = signature;
      routeState.custom = data.route;
      routeState.activeIndex = 0;
      publishRoute();
    }
  }
};

channel.onmessage = (event: MessageEvent) => {
  const s = event.data ?? {};
  if (typeof s.altitude === 'number') flight.altitude = s.altitude;
  if (typeof s.latitude === 'number') flight.latitude = s.latitude;
  if (typeof s.longitude === 'number') flight.longitude = s.longitude;
  if (typeof s.ias === 'number') {
    flight.ias = s.ias;
    flight.tas = typeof s.tas === 'number' ? s.tas : s.ias + 30;
    flight.groundSpeed = typeof s.groundSpeed === 'number' ? s.groundSpeed : Math.max(0, s.ias - 5);
    flight.mach = typeof s.mach === 'number' ? s.mach : Math.min(0.82, s.ias / 620);
  }
  if (typeof s.heading === 'number') {
    flight.heading = s.heading;
    flight.track = s.heading;
  }
  if (typeof s.verticalSpeed === 'number') flight.verticalSpeed = s.verticalSpeed;
  if (typeof s.pitch === 'number') flight.pitch = s.pitch;
  if (typeof s.roll === 'number') flight.roll = s.roll;
  if (typeof s.lateral === 'string') fmaState.lateral = s.lateral as LateralMode;
  if (typeof s.ndMode === 'number') ndState.mode = s.ndMode;
  if (typeof s.ndRange === 'number') ndState.range = s.ndRange;
  if (typeof s.routeIndex === 'number') {
    routeState.activeIndex = s.routeIndex;
    publishRoute();
  }
  if (Array.isArray(s.customRoute) && s.customRoute.length > 0) {
    const signature = s.customRoute.map((p: any) => `${p.ident}:${p.lat}:${p.long}`).join('|');
    if (signature !== routeSignature) {
      routeSignature = signature;
      routeState.custom = s.customRoute;
      publishRoute();
    }
  }
  publishNdState();
};

import('./instruments/nd-entry').then(() => {
  const host = document.querySelector('a32nx-nd') as any;
  let last = performance.now();
  let lastPublish = 0;
  let phase = 0;

  // Route is sent to the original ND through the generic data listener bus.
  setInterval(publishRoute, 1500);
  setTimeout(publishRoute, 600);

  function fit(): void {
    const scale = Math.min(window.innerWidth / 768, window.innerHeight / 768);
    document.documentElement.style.setProperty('--pfd-scale', String(scale));
  }
  window.addEventListener('resize', fit);
  fit();

  function frame(now: number): void {
    const dt = Math.min(100, now - last);
    last = now;
    phase += dt / 1000;

    if (now - lastPublish > 80) {
      lastPublish = now;
      simVars.set('E:SIMULATION TIME', phase, 'seconds');
      simVars.set('E:ABSOLUTE TIME', 63_900_000_000 + phase, 'seconds');
      publishNdState();
    }

    if (host) {
      host.deltaTime = dt;
      host.Update?.();
    }
    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
});
