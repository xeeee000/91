import { RoutePoint, WAYPOINT_DB, AIRPORT_SCENE } from './data/waypoints';
import { FlightModel } from './sim/flight-model';
import { RustFlightModel } from './sim/rust-flight-model';

const units = Array.from(document.querySelectorAll<HTMLElement>('.unit'));

function toggleFullscreen(unit: HTMLElement): void {
  if (document.fullscreenElement === unit) {
    void document.exitFullscreen();
  } else {
    void unit.requestFullscreen?.();
  }
}

units.forEach((unit, index) => {
  unit.addEventListener('dblclick', () => toggleFullscreen(unit));
  unit.tabIndex = index + 1;
});

window.addEventListener('keydown', (e) => {
  if (e.target instanceof HTMLSelectElement || e.target instanceof HTMLInputElement) return;
  const n = Number(e.key);
  if (n >= 1 && n <= units.length && !e.ctrlKey && !e.metaKey && !e.altKey) {
    toggleFullscreen(units[n - 1]);
  }
  if (e.key === 'Escape' && document.fullscreenElement) {
    void document.exitFullscreen();
  }
});

const sdPage = document.getElementById('sd-page') as HTMLSelectElement | null;
const sdFrame = document.querySelector<HTMLIFrameElement>('iframe[title="SD"]');
function showSdPage(page: string): void {
  if (!sdPage || !sdFrame) return;
  if (sdPage.value === page && sdFrame.src.includes(`page=${page}`)) return;
  sdPage.value = page;
  sdFrame.src = `sd-full.html?page=${page}`;
}
sdPage?.addEventListener('change', () => {
  if (sdFrame) sdFrame.src = `sd-full.html?page=${sdPage.value}`;
});

// ---------------------------------------------------------------------------
// Shared flight/system state: one BroadcastChannel feeds every display iframe.
// ---------------------------------------------------------------------------
interface FlightControlState {
  altitude: number;
  ias: number;
  heading: number;
  verticalSpeed: number;
  pitch: number;
  roll: number;
  n1: number;
  fuel: number;
  gen1: boolean;
  gen2: boolean;
  hydGreen: boolean;
  hydBlue: boolean;
  hydYellow: boolean;
  hydGreenPressure: number;
  hydBluePressure: number;
  hydYellowPressure: number;
  pack1: boolean;
  pack2: boolean;
  engBleed1: boolean;
  engBleed2: boolean;
  apuBleed: boolean;
  fuelL: boolean;
  fuelR: boolean;
  fuelC: boolean;
  xfeed: boolean;
  apuMaster: boolean;
  apuAvailable: boolean;
  apuGen: boolean;
  eng1Running: boolean;
  eng2Running: boolean;
  eng1Master: boolean;
  eng2Master: boolean;
  wingAntiIce: boolean;
  pressAuto: boolean;
  eng1Fire: boolean;
  eng2Fire: boolean;
  apuFire: boolean;
  eng1Fail: boolean;
  eng2Fail: boolean;
  apuFail: boolean;
  cargoSmoke: boolean;
  pressFault: boolean;
  gearFail: boolean;
  elac1Fail: boolean;
  sec1Fail: boolean;
  fac1Fail: boolean;
  fuelLeakL: boolean;
  fuelLeakR: boolean;
  cabinDoor: boolean;
  cargoDoor: boolean;
  oxyFail: boolean;
  hotAirFault: boolean;
  navLights: boolean;
  beaconLights: boolean;
  strobeLights: boolean;
  landingLights: boolean;
  taxiLights: boolean;
  adirs1: boolean;
  adirs2: boolean;
  adirs3: boolean;
  adirsAligned: boolean;
  lateral: string;
  vertical: string;
  ap: boolean;
  locDeviation: number;
  gsDeviation: number;
  ilsCourse: number;
  ndMode: number;
  ndRange: number;
  routeIndex: number;
  customRoute: RoutePoint[];
  fcuSpeed: number;
  fcuAltitude: number;
  latitude: number;
  longitude: number;
  radioAltitude: number;
  mach: number;
  tas: number;
  groundSpeed: number;
  phase: string;
  throttle: number;
  flaps: number;
  gearDown: boolean;
  brakes: boolean;
  onGround: boolean;
}

const channel = new BroadcastChannel('a32nx-sim');
let model: any = new FlightModel();
(window as any).__A32NX_FLIGHT_MODEL__ = model;

// The overhead page publishes its derived AC/DC buses here. Until it has ever
// reported, keep the displays alive so the cockpit is usable on first load.
const overheadChannel = new BroadcastChannel('a32nx-overhead');
let overheadLive = false;
let overheadState: any = null;
let overheadDerived: any = null;

const fmsSceneChannel = new BroadcastChannel('a32nx-fms');
let sceneOrigin = '';
let fmsRoute: RoutePoint[] = [];
let fmsDestination: RoutePoint | null = null;
fmsSceneChannel.onmessage = (event: MessageEvent) => {
  const data = event.data ?? {};
  if (Array.isArray(data.route)) fmsRoute = data.route;
  if (typeof data.destination === 'string') {
    const point = WAYPOINT_DB[data.destination];
    fmsDestination = point ? { ident: data.destination, lat: point.lat, long: point.long } : null;
  }
  const origin = String(data.origin ?? '').toUpperCase();
  if (!origin || origin === sceneOrigin) return;
  const point = WAYPOINT_DB[origin];
  const scene = AIRPORT_SCENE[origin];
  if (!point || !scene) return;
  sceneOrigin = origin;
  if (typeof model.resetAt === 'function') {
    model.resetAt(point.lat, point.long, scene.elevationFt, scene.heading);
    model.controls.targetAlt = scene.elevationFt + 10_000;
    syncHud();
  }
};

overheadChannel.onmessage = (event: MessageEvent) => {
  const data = event.data ?? {};
  const d = data.derived;
  if (!d) return;
  overheadLive = true;
  overheadState = data.state;
  overheadDerived = d;
  document.querySelectorAll<HTMLElement>('.unit[data-power="ac"] .screen').forEach((screen) => {
    screen.classList.toggle('unpowered', !d.ac);
  });
  document.querySelectorAll<HTMLElement>('.unit[data-power="dc"] .screen').forEach((screen) => {
    screen.classList.toggle('unpowered', !d.dc);
  });
};

const inputs = {
  altitude: document.getElementById('ctl-alt') as HTMLInputElement | null,
  ias: document.getElementById('ctl-ias') as HTMLInputElement | null,
  heading: document.getElementById('ctl-hdg') as HTMLInputElement | null,
  verticalSpeed: document.getElementById('ctl-vs') as HTMLInputElement | null,
  pitch: document.getElementById('ctl-pitch') as HTMLInputElement | null,
  roll: document.getElementById('ctl-roll') as HTMLInputElement | null,
  n1: document.getElementById('ctl-n1') as HTMLInputElement | null,
  fuel: document.getElementById('ctl-fuel') as HTMLInputElement | null,
  selSpd: document.getElementById('ctl-sel-spd') as HTMLInputElement | null,
  selAlt: document.getElementById('ctl-sel-alt') as HTMLInputElement | null,
  gen1: document.getElementById('ctl-gen1') as HTMLInputElement | null,
  gen2: document.getElementById('ctl-gen2') as HTMLInputElement | null,
  hydGreen: document.getElementById('ctl-hyd-green') as HTMLInputElement | null,
  hydBlue: document.getElementById('ctl-hyd-blue') as HTMLInputElement | null,
  hydYellow: document.getElementById('ctl-hyd-yellow') as HTMLInputElement | null,
  lateral: document.getElementById('ctl-lat') as HTMLSelectElement | null,
  vertical: document.getElementById('ctl-vert') as HTMLSelectElement | null,
  ap: document.getElementById('ctl-ap') as HTMLInputElement | null,
  ndMode: document.getElementById('ctl-nd-mode') as HTMLSelectElement | null,
  ndRange: document.getElementById('ctl-nd-range') as HTMLSelectElement | null,
};

const outputs = {
  altitude: document.getElementById('out-alt'),
  ias: document.getElementById('out-ias'),
  heading: document.getElementById('out-hdg'),
  verticalSpeed: document.getElementById('out-vs'),
  pitch: document.getElementById('out-pitch'),
  roll: document.getElementById('out-roll'),
  n1: document.getElementById('out-n1'),
  fuel: document.getElementById('out-fuel'),
  selSpd: document.getElementById('out-sel-spd'),
  selAlt: document.getElementById('out-sel-alt'),
};

// Dynamic state: N1 spools at 8 %/s, hydraulics move at 900 psi/s and fuel is
// burned according to the current N1. This makes the displays show transients.
const dynamics = {
  n1: 62,
  fuel: 15000,
  hydGreenPressure: 3000,
  hydBluePressure: 3000,
  hydYellowPressure: 3000,
  lateralOffsetNm: 0,
  locDeviation: 0.02,
  gsDeviation: -0.03,
};
let n1Target = 62;
const hydTargets = { green: 3000, blue: 3000, yellow: 3000 };
let routeIndex = 0;
let customRoute: RoutePoint[] = [];

// ---------------------------------------------------------------------------
// Flight controls: sidestick, throttle, gear/flaps/brake and a tiny keyboard
// layer. These drive the JS flight model, not the old demo sliders.
// ---------------------------------------------------------------------------
const hud = document.getElementById('flight-hud');
if (window.matchMedia('(max-width: 900px)').matches) hud?.classList.add('hidden');
const stickPad = document.getElementById('stick-pad');
const stickKnob = document.getElementById('stick-knob');
const hudThrottle = document.getElementById('hud-throttle') as HTMLInputElement | null;
const held = new Set<string>();
let stickX = 0;
let stickY = 0;
let timeScale = 1;

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function flightLaw(): 'NORMAL' | 'ALTERNATE' | 'DIRECT' {
  if (!overheadLive) return 'NORMAL';
  const elac = !!overheadState?.elac1Fail;
  const sec = !!overheadState?.sec1Fail;
  const fac = !!overheadState?.fac1Fail;
  if ((elac && sec) || (elac && fac) || (sec && fac)) return 'DIRECT';
  if (elac || sec || fac) return 'ALTERNATE';
  return 'NORMAL';
}

function applyStickControls(): void {
  let pitch = stickY;
  let roll = stickX;
  if (held.has('KeyW')) pitch -= 0.8;
  if (held.has('KeyS')) pitch += 0.8;
  if (held.has('KeyA')) roll -= 0.8;
  if (held.has('KeyD')) roll += 0.8;
  const law = flightLaw();
  const lawFactor = law === 'DIRECT' ? 0.5 : law === 'ALTERNATE' ? 0.72 : 1;
  const yawFactor = overheadLive && overheadState?.fac1Fail ? 0.4 : 1;
  model.controls.pitch = clamp(pitch, -1, 1) * lawFactor;
  model.controls.roll = clamp(roll, -1, 1) * lawFactor;
  model.controls.yaw = ((held.has('KeyE') ? 0.7 : 0) + (held.has('KeyQ') ? -0.7 : 0)) * yawFactor;
}

function setStick(x: number, y: number): void {
  stickX = clamp(x, -1, 1);
  stickY = clamp(y, -1, 1);
  if (stickKnob) stickKnob.style.transform = `translate(${stickX * 34}px, ${stickY * 34}px)`;
}

stickPad?.addEventListener('pointerdown', (event) => {
  stickPad.setPointerCapture(event.pointerId);
  const move = (e: PointerEvent): void => {
    const rect = stickPad.getBoundingClientRect();
    setStick((e.clientX - rect.left - rect.width / 2) / (rect.width / 2), (e.clientY - rect.top - rect.height / 2) / (rect.height / 2));
  };
  move(event);
  const up = (): void => {
    stickPad.removeEventListener('pointermove', move);
    stickPad.removeEventListener('pointerup', up);
    setStick(0, 0);
  };
  stickPad.addEventListener('pointermove', move);
  stickPad.addEventListener('pointerup', up);
});

hudThrottle?.addEventListener('input', () => {
  model.controls.throttle = Number(hudThrottle.value);
});

function cycleFlaps(): void {
  model.setFlaps((model.controls.flaps + 1) % 5);
}

function syncHud(): void {
  const s = model.state;
  const c = model.controls;
  const phase = document.getElementById('hud-phase');
  const thr = document.getElementById('hud-thr');
  const gs = document.getElementById('hud-gs');
  const vs = document.getElementById('hud-vs');
  const aoa = document.getElementById('hud-aoa');
  const n1 = document.getElementById('hud-n1');
  const warn = document.getElementById('hud-warn');
  const rate = document.getElementById('hud-rate');
  if (phase) phase.textContent = s.onGround ? s.phase : s.phase;
  const lawElement = document.getElementById('hud-law');
  const law = flightLaw();
  if (lawElement) {
    lawElement.textContent = law === 'NORMAL' ? 'NORMAL LAW' : law === 'ALTERNATE' ? 'ALT LAW' : 'DIRECT LAW';
    lawElement.classList.toggle('degraded', law !== 'NORMAL');
  }
  (window as any).__A32NX_LAW__ = law;
  if (thr) thr.textContent = `${Math.round(c.throttle)}%`;
  if (gs) gs.textContent = String(Math.round(s.gs));
  if (vs) vs.textContent = String(Math.round(s.vsFpm));
  if (aoa) aoa.textContent = s.aoa.toFixed(1);
  if (n1) n1.textContent = s.n1.toFixed(0);
  if (warn) warn.textContent = s.warning ? `⚠ ${s.warning}` : s.touchdownVs < -600 ? `TOUCHDOWN ${Math.round(s.touchdownVs)} FPM` : '';
  if (rate) rate.textContent = `RATE ${timeScale}×`;
  if (hudThrottle && document.activeElement !== hudThrottle) hudThrottle.value = String(Math.round(c.throttle));
  document.getElementById('hud-gear')?.classList.toggle('active', c.gearDown);
  document.getElementById('hud-brake')?.classList.toggle('active', c.brake);
  document.getElementById('hud-ap')?.classList.toggle('active', c.ap);
  document.getElementById('hud-pause')?.classList.toggle('active', c.paused);
  const flap = document.getElementById('hud-flap');
  if (flap) flap.textContent = c.flaps === 0 ? 'FLAPS 0' : `FLAPS ${c.flaps}`;
}

document.getElementById('hud-toggle')?.addEventListener('click', () => hud?.classList.toggle('hidden'));
document.getElementById('hud-hide')?.addEventListener('click', () => hud?.classList.add('hidden'));
document.getElementById('hud-rwy')?.addEventListener('click', () => {
  model.resetRunway();
  if (inputs.selAlt) inputs.selAlt.value = '10000';
  if (inputs.selSpd) inputs.selSpd.value = '250';
  if (inputs.heading) inputs.heading.value = '45';
  if (inputs.ap) inputs.ap.checked = false;
  syncHud();
});
document.getElementById('hud-app')?.addEventListener('click', () => {
  const destination = fmsDestination;
  const scene = destination ? AIRPORT_SCENE[destination.ident] : undefined;
  if (destination && scene && typeof model.resetApproachAt === 'function') {
    const heading = scene.heading;
    const lat = destination.lat - (Math.cos((heading * Math.PI) / 180) * 8) / 60;
    const lon = destination.long - (Math.sin((heading * Math.PI) / 180) * 8) / (60 * Math.cos((destination.lat * Math.PI) / 180));
    model.resetApproachAt(lat, lon, scene.elevationFt, heading);
    if (inputs.selAlt) inputs.selAlt.value = String(scene.elevationFt);
    if (inputs.selSpd) inputs.selSpd.value = '135';
  } else {
    model.resetApproach();
    model.controls.ap = true;
    model.controls.targetAlt = 1000;
    model.controls.targetSpeed = 135;
    if (inputs.selAlt) inputs.selAlt.value = '1000';
    if (inputs.selSpd) inputs.selSpd.value = '135';
  }
  model.controls.ap = true;
  if (inputs.ap) inputs.ap.checked = true;
  syncHud();
});
document.getElementById('hud-ga')?.addEventListener('click', () => {
  if (typeof model.goAround === 'function') model.goAround();
  model.controls.ap = true;
  model.controls.throttle = 100;
  if (inputs.selAlt) inputs.selAlt.value = String(Math.round(model.controls.targetAlt));
  if (inputs.selSpd) inputs.selSpd.value = '180';
  if (inputs.ap) inputs.ap.checked = true;
  if (hudThrottle) hudThrottle.value = '100';
  syncHud();
  publish();
});

document.getElementById('hud-gear')?.addEventListener('click', () => {
  if (overheadLive && overheadState?.gearFail && !model.state.gearDown) {
    const warn = document.getElementById('hud-warn');
    if (warn) warn.textContent = 'L/G FAULT · GEAR WILL NOT EXTEND';
    return;
  }
  model.toggleGear();
  syncHud();
});
document.getElementById('hud-flap')?.addEventListener('click', () => {
  cycleFlaps();
  syncHud();
});
document.getElementById('hud-brake')?.addEventListener('click', () => {
  model.toggleBrake();
  syncHud();
});
document.getElementById('hud-ap')?.addEventListener('click', () => {
  model.toggleAp();
  if (inputs.ap) inputs.ap.checked = model.controls.ap;
  syncHud();
});
document.getElementById('hud-pause')?.addEventListener('click', () => {
  model.togglePause();
  syncHud();
});
document.getElementById('hud-reset')?.addEventListener('click', () => {
  model.resetRunway();
  timeScale = 1;
  syncHud();
});
document.getElementById('hud-rate')?.addEventListener('click', () => {
  timeScale = timeScale === 1 ? 2 : timeScale === 2 ? 4 : timeScale === 4 ? 8 : 1;
  syncHud();
});

window.addEventListener('keydown', (event) => {
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement) return;
  const code = event.code;
  if (['KeyW', 'KeyS', 'KeyA', 'KeyD', 'KeyQ', 'KeyE', 'ShiftLeft', 'ControlLeft'].includes(code)) {
    held.add(code);
    event.preventDefault();
    return;
  }
  if (event.repeat) return;
  if (code === 'KeyG') model.toggleGear();
  else if (code === 'KeyF') cycleFlaps();
  else if (code === 'KeyB') model.toggleBrake();
  else if (code === 'KeyP') model.togglePause();
  else if (code === 'KeyR') model.resetRunway();
  else if (code === 'KeyT') timeScale = timeScale === 1 ? 2 : timeScale === 2 ? 4 : timeScale === 4 ? 8 : 1;
  syncHud();
});

window.addEventListener('keyup', (event) => {
  held.delete(event.code);
});

function readState(): FlightControlState {
  const f = model.state;
  const hydGreen = overheadLive ? !!overheadDerived?.hydGreen : (inputs.hydGreen?.checked ?? true);
  const hydBlue = overheadLive ? !!overheadDerived?.hydBlue : (inputs.hydBlue?.checked ?? true);
  const hydYellow = overheadLive ? !!overheadDerived?.hydYellow : (inputs.hydYellow?.checked ?? true);
  return {
    altitude: f.altFt,
    ias: f.ias,
    heading: f.heading,
    verticalSpeed: f.vsFpm,
    pitch: f.pitch,
    roll: f.roll,
    n1: f.n1,
    fuel: f.fuelKg,
    gen1: overheadLive ? !!overheadState?.gen1 : (inputs.gen1?.checked ?? true),
    gen2: overheadLive ? !!overheadState?.gen2 : (inputs.gen2?.checked ?? true),
    hydGreen,
    hydBlue,
    hydYellow,
    hydGreenPressure: hydGreen ? dynamics.hydGreenPressure : 0,
    hydBluePressure: hydBlue ? dynamics.hydBluePressure : 0,
    hydYellowPressure: hydYellow ? dynamics.hydYellowPressure : 0,
    pack1: overheadLive ? !!overheadState?.pack1 : true,
    pack2: overheadLive ? !!overheadState?.pack2 : true,
    engBleed1: overheadLive ? !!overheadState?.engBleed1 : true,
    engBleed2: overheadLive ? !!overheadState?.engBleed2 : true,
    apuBleed: overheadLive ? !!overheadState?.apuBleed : false,
    fuelL: overheadLive ? !!overheadState?.fuelL : true,
    fuelR: overheadLive ? !!overheadState?.fuelR : true,
    fuelC: overheadLive ? !!overheadState?.fuelC : true,
    xfeed: overheadLive ? !!overheadState?.xfeed : false,
    apuMaster: overheadLive ? !!overheadState?.apuMaster : false,
    apuAvailable: overheadLive ? !!overheadState?.apuAvailable : false,
    apuGen: overheadLive ? !!overheadState?.apuGen : false,
    eng1Running: overheadLive ? !!overheadState?.eng1Running : false,
    eng2Running: overheadLive ? !!overheadState?.eng2Running : false,
    eng1Master: overheadLive ? !!overheadState?.eng1Master : false,
    eng2Master: overheadLive ? !!overheadState?.eng2Master : false,
    wingAntiIce: overheadLive ? !!overheadState?.wingAntiIce : false,
    pressAuto: overheadLive ? !!overheadState?.pressAuto : true,
    eng1Fire: overheadLive ? !!overheadState?.eng1Fire : false,
    eng2Fire: overheadLive ? !!overheadState?.eng2Fire : false,
    apuFire: overheadLive ? !!overheadState?.apuFire : false,
    eng1Fail: overheadLive ? !!overheadState?.eng1Fail : false,
    eng2Fail: overheadLive ? !!overheadState?.eng2Fail : false,
    apuFail: overheadLive ? !!overheadState?.apuFail : false,
    cargoSmoke: overheadLive ? !!overheadState?.cargoSmoke : false,
    pressFault: overheadLive ? !!overheadState?.pressFault : false,
    gearFail: overheadLive ? !!overheadState?.gearFail : false,
    elac1Fail: overheadLive ? !!overheadState?.elac1Fail : false,
    sec1Fail: overheadLive ? !!overheadState?.sec1Fail : false,
    fac1Fail: overheadLive ? !!overheadState?.fac1Fail : false,
    fuelLeakL: overheadLive ? !!overheadState?.fuelLeakL : false,
    fuelLeakR: overheadLive ? !!overheadState?.fuelLeakR : false,
    cabinDoor: overheadLive ? !!overheadState?.cabinDoor : false,
    cargoDoor: overheadLive ? !!overheadState?.cargoDoor : false,
    oxyFail: overheadLive ? !!overheadState?.oxyFail : false,
    hotAirFault: overheadLive ? !!overheadState?.hotAirFault : false,
    navLights: overheadLive ? !!overheadState?.navLights : false,
    beaconLights: overheadLive ? !!overheadState?.beaconLights : false,
    strobeLights: overheadLive ? !!overheadState?.strobeLights : false,
    landingLights: overheadLive ? !!overheadState?.landingLights : false,
    taxiLights: overheadLive ? !!overheadState?.taxiLights : false,
    adirs1: overheadLive ? !!overheadState?.adirs1 : false,
    adirs2: overheadLive ? !!overheadState?.adirs2 : false,
    adirs3: overheadLive ? !!overheadState?.adirs3 : false,
    adirsAligned: overheadLive ? !!overheadState?.adirsAligned : false,
    lateral: inputs.lateral?.value ?? 'HDG',
    vertical: inputs.vertical?.value ?? 'ALT',
    ap: model.controls.ap,
    locDeviation: dynamics.locDeviation,
    gsDeviation: dynamics.gsDeviation,
    ilsCourse: 45,
    ndMode: Number(inputs.ndMode?.value ?? 2),
    ndRange: Number(inputs.ndRange?.value ?? 2),
    routeIndex,
    customRoute,
    fcuSpeed: Number(inputs.selSpd?.value ?? 250),
    fcuAltitude: Number(inputs.selAlt?.value ?? 20000),
    latitude: f.lat,
    longitude: f.lon,
    radioAltitude: Math.max(0, f.altFt - 1411),
    mach: Math.min(0.82, f.tas / 620),
    tas: f.tas,
    groundSpeed: f.gs,
    phase: f.phase,
    throttle: f.throttle,
    flaps: f.flaps,
    gearDown: f.gearDown,
    brakes: f.brakes,
    onGround: f.onGround,
  };
}

function publish(): void {
  const s = readState();
  (window as any).__A32NX_LAST_STATE__ = s;
  channel.postMessage(s);

  const alt = document.getElementById('stat-alt');
  const ias = document.getElementById('stat-ias');
  const hdg = document.getElementById('stat-hdg');
  if (alt) alt.textContent = String(Math.round(s.altitude)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  if (ias) ias.textContent = String(Math.round(s.ias));
  if (hdg) hdg.textContent = String(Math.round(s.heading)).padStart(3, '0');

  if (outputs.altitude) outputs.altitude.textContent = String(Math.round(s.altitude));
  if (outputs.ias) outputs.ias.textContent = String(Math.round(s.ias));
  if (outputs.heading) outputs.heading.textContent = String(Math.round(s.heading)).padStart(3, '0');
  if (outputs.verticalSpeed) outputs.verticalSpeed.textContent = String(Math.round(s.verticalSpeed));
  if (outputs.pitch) outputs.pitch.textContent = s.pitch.toFixed(1);
  if (outputs.roll) outputs.roll.textContent = String(Math.round(s.roll));
  if (outputs.n1) outputs.n1.textContent = s.n1.toFixed(0);
  if (outputs.fuel) outputs.fuel.textContent = String(Math.round(s.fuel));
  if (outputs.selSpd) outputs.selSpd.textContent = String(Math.round(s.fcuSpeed));
  if (outputs.selAlt) outputs.selAlt.textContent = String(Math.round(s.fcuAltitude));
}

function handleInput(event: Event): void {
  const target = event.target as HTMLInputElement;
  if (target === inputs.n1) model.controls.throttle = Number(target.value);
  if (target === inputs.fuel) model.state.fuelKg = Number(target.value);
  if (target === inputs.ap) model.controls.ap = target.checked;
  if (target === inputs.hydGreen) hydTargets.green = target.checked ? 3000 : 0;
  if (target === inputs.hydBlue) hydTargets.blue = target.checked ? 3000 : 0;
  if (target === inputs.hydYellow) hydTargets.yellow = target.checked ? 3000 : 0;

  // ECAM-like automatic page selection when a system is degraded.
  if ((target === inputs.gen1 || target === inputs.gen2) && !target.checked) showSdPage('3');
  if (
    (target === inputs.hydGreen || target === inputs.hydBlue || target === inputs.hydYellow) &&
    !target.checked
  ) {
    showSdPage('4');
  }
  if (target === inputs.fuel && Number(target.value) < 3000) showSdPage('5');
  if (target === inputs.lateral && target.value === 'APP') {
    // Demo approach preset: put the aircraft on a 3° path at 8 NM.
    if (inputs.altitude) inputs.altitude.value = '2500';
    if (inputs.heading) inputs.heading.value = '45';
    dynamics.lateralOffsetNm = 0;
  }
  publish();
}

Object.values(inputs).forEach((input) => input?.addEventListener('input', handleInput));
inputs.lateral?.addEventListener('change', handleInput);
inputs.vertical?.addEventListener('change', handleInput);
inputs.ndMode?.addEventListener('change', handleInput);
inputs.ndRange?.addEventListener('change', handleInput);

const drawer = document.getElementById('control-drawer');
document.getElementById('controls-toggle')?.addEventListener('click', () => drawer?.classList.toggle('open'));
document.getElementById('controls-close')?.addEventListener('click', () => drawer?.classList.remove('open'));
document.getElementById('ctl-next-wpt')?.addEventListener('click', () => {
  routeIndex = (routeIndex + 1) % (customRoute.length || 4);
  publish();
});
document.getElementById('ctl-reset-route')?.addEventListener('click', () => {
  routeIndex = 0;
  customRoute = [];
  publish();
});
document.getElementById('ctl-insert-wpt')?.addEventListener('click', () => {
  const input = document.getElementById('ctl-wpt') as HTMLInputElement | null;
  const ident = (input?.value ?? '').trim().toUpperCase();
  const waypoint = WAYPOINT_DB[ident];
  if (!waypoint || customRoute.length >= 12) return;
  customRoute = [...customRoute, { ident, lat: waypoint.lat, long: waypoint.long }];
  routeIndex = 0;
  if (input) input.value = '';
  publish();
});

function moveTowards(current: number, target: number, maxDelta: number): number {
  if (Math.abs(target - current) <= maxDelta) return target;
  return current + Math.sign(target - current) * maxDelta;
}

function step(dt: number): void {
  model.controls.targetAlt = Number(inputs.selAlt?.value ?? 20000);
  model.controls.targetSpeed = Number(inputs.selSpd?.value ?? 250);
  let targetHeading = Number(inputs.heading?.value ?? model.state.heading);

  // Simple LNAV: when the lateral mode is NAV, steer to the next FMS waypoint.
  const lateralMode = inputs.lateral?.value ?? 'HDG';
  const navRoute: RoutePoint[] = customRoute.length > 0
    ? customRoute
    : fmsDestination && !fmsRoute.some((p) => p.ident === fmsDestination?.ident)
      ? [...fmsRoute, fmsDestination]
      : fmsRoute;
  if (lateralMode === 'NAV' && navRoute.length > 0) {
    const index = Math.min(routeIndex, navRoute.length - 1);
    const wp = navRoute[index];
    const dLat = wp.lat - model.state.lat;
    const dLon = (wp.long - model.state.lon) * Math.cos((model.state.lat * Math.PI) / 180);
    const bearing = (Math.atan2(dLon, dLat) * 180) / Math.PI;
    targetHeading = (bearing + 360) % 360;
    const distanceNm = Math.hypot(dLat * 60, dLon * 60);
    if (distanceNm < 1.5 && index < navRoute.length - 1) {
      routeIndex = index + 1;
    }
  }
  model.controls.targetHeading = targetHeading;

  applyStickControls();
  if (held.has('ShiftLeft')) model.controls.throttle = clamp(model.controls.throttle + 45 * dt, 0, 100);
  if (held.has('ControlLeft')) model.controls.throttle = clamp(model.controls.throttle - 45 * dt, 0, 100);
  if (overheadLive) {
    const running = !!overheadState?.eng1Running || !!overheadState?.eng2Running;
    if (!running) model.controls.throttle = 0;
    else if (model.controls.throttle < 20) model.controls.throttle = 24;
    if (overheadState?.elac1Fail || flightLaw() === 'DIRECT') model.controls.ap = false;
  }

  model.update(dt);
  for (let i = 1; i < timeScale; i++) model.update(dt);
  dynamics.fuel = model.state.fuelKg;

  dynamics.hydGreenPressure = moveTowards(dynamics.hydGreenPressure, hydTargets.green, 900 * dt);
  dynamics.hydBluePressure = moveTowards(dynamics.hydBluePressure, hydTargets.blue, 900 * dt);
  dynamics.hydYellowPressure = moveTowards(dynamics.hydYellowPressure, hydTargets.yellow, 900 * dt);

  // Simple ILS geometry: cross-track drift from heading error, 3° glide path.
  const altitude = model.state.altFt;
  const heading = model.state.heading;
  const ias = model.state.ias;
  const course = 45;
  const headingError = ((heading - course) * Math.PI) / 180;
  dynamics.lateralOffsetNm = Math.max(
    -1,
    Math.min(1, dynamics.lateralOffsetNm + Math.sin(headingError) * (ias / 3600) * dt),
  );

  const distanceFt = 8 * 6076;
  dynamics.locDeviation = Math.max(
    -2.5,
    Math.min(2.5, (Math.atan2(dynamics.lateralOffsetNm, 8) * 180) / Math.PI),
  );
  const idealAltitude = 1411 + distanceFt * Math.tan((3 * Math.PI) / 180);
  dynamics.gsDeviation = Math.max(
    -2.5,
    Math.min(2.5, (Math.atan2(altitude - idealAltitude, distanceFt) * 180) / Math.PI),
  );

  publish();
  syncHud();
}

publish();
syncHud();
setInterval(() => step(0.05), 50);

// Prefer the Rust/wasm dynamics core; the TS model remains a fallback for
// environments where the wasm asset cannot be fetched.
RustFlightModel.load()
  .then((rust) => {
    model = rust;
    (window as any).__A32NX_FLIGHT_MODEL__ = rust;
    if (sceneOrigin) {
      const point = WAYPOINT_DB[sceneOrigin];
      const scene = AIRPORT_SCENE[sceneOrigin];
      if (point && scene) {
        rust.resetAt(point.lat, point.long, scene.elevationFt, scene.heading);
        rust.controls.targetAlt = scene.elevationFt + 10_000;
      }
    }
    syncHud();
    console.info('[sim] Rust wasm flight core active');
  })
  .catch((error) => console.warn('[sim] Rust wasm core unavailable, using TS fallback', error));

const utc = document.getElementById('stat-utc');
function tick(): void {
  if (!utc) return;
  const now = new Date();
  utc.textContent = now.toISOString().slice(11, 19);
}
tick();
setInterval(tick, 1000);
