# Optional OpenAIP data

The standalone build uses `LocalNavDataProvider` by default.

To use an OpenAIP export:

1. Put an OpenAIP JSON export at `public/navdata/openaip.json`.
2. The MCDU boot code calls `loadOpenAip()` and switches the provider at runtime.
3. Accepted shapes:
   - `{ "items": [ ...airports ] }` (OpenAIP API response)
   - a bare array of airports
4. Airport geometry uses GeoJSON `[longitude, latitude]`; runway thresholds use
   `threshold.coordinates` or `thresholdLocation`.

The adapter is deliberately optional so the standalone build has no external
data dependency. A Navigraph adapter can implement the same
`NavDataProvider` interface.
