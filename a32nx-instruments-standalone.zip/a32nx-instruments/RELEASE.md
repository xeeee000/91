# Release / self-sign guide

This repository is built to produce two unsigned artifacts from GitHub Actions:

- iOS: `A32NXSim-unsigned.ipa`
- Windows: Tauri NSIS installer and MSI

No Mac is required on your side. The iOS job runs on `macos-14` in GitHub
Actions; you only download and self-sign the IPA.

## 1. Put the project on GitHub

The workflows assume the repository root is the `a32nx-instruments` folder
(the folder that contains `package.json`, `.github/`, `src/`, `src-tauri/` and
`ios/`).

```text
a32nx-instruments/
  .github/workflows/ci.yml
  .github/workflows/ios-unsigned.yml
  .github/workflows/windows-shell.yml
  package.json
  src/
  src-tauri/
  ios/
```

Create an empty GitHub repository, extract this zip, and push the
`a32nx-instruments` folder as the repository root.

```bash
cd a32nx-instruments
git init
git add .
git commit -m "A32NX standalone"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

The repo is GPL-3.0; self-signed distribution avoids the App Store GPL
conflict.

## 2. iOS unsigned IPA

Workflow: `.github/workflows/ios-unsigned.yml`

It performs:

1. `npm ci`
2. `npm run build` (Vite web build + wasm)
3. `brew install xcodegen`
4. `xcodegen generate` in `ios/`
5. unsigned `xcodebuild` for `generic/platform=iOS`
6. packages `Payload/A32NXSim.app` into `A32NXSim-unsigned.ipa`
7. uploads the IPA artifact

Run it from **Actions → iOS unsigned IPA → Run workflow**, or push a tag.

Download the artifact, unzip it, and self-sign with one of:

- AltStore / SideStore
- Sideloadly
- TrollStore (device/version dependent)

Notes:

- Free Apple ID signing expires after 7 days; re-sign to renew.
- The bundle id is `com.a32nx.sim`; change it in `ios/project.yml` if it
  conflicts with an existing app.
- The IPA is unsigned on purpose. Do not expect it to install directly.
- The app is landscape-only and loads `index.html` from `Resources/web`
  through the custom `a32nx://` scheme.

## 3. Windows installer

Workflow: `.github/workflows/windows-shell.yml`

It runs on `windows-latest`:

1. Rust stable + wasm target
2. `npm ci`
3. `npm run build`
4. `cargo tauri build` from the repository root
5. uploads the NSIS `.exe` and `.msi`

Download the artifact and run the installer. WebView2 is required; Windows 11
already ships it.

## 4. Local checks before pushing

```bash
npm ci
npm run build
cd crates/sim-core && cargo test --release
```

The web build also compiles the Rust wasm core via `scripts/build-wasm.mjs`.

## 5. If a workflow fails

- **iOS: `xcodegen: command not found`** — the brew step did not run; check the
  macOS runner image.
- **iOS: signing error** — the workflow sets `CODE_SIGNING_ALLOWED=NO`; do not
  add a development team to `project.yml`.
- **iOS: blank WebView** — check that `Resources/web` is a folder reference
  and that `a32nx://local/index.html` exists inside the app bundle.
- **Windows: `link.exe not found`** — the runner needs the MSVC build tools;
  `windows-latest` includes them. Local Windows machines without Visual Studio
  cannot build the native Tauri binary.
- **WASM fetch fails** — the server must serve `.wasm` as
  `application/wasm`; the iOS scheme handler and Vite both do.

## 6. What is still missing

See `docs/STATUS.md`. The biggest remaining gaps are:

- real OpenAIP data import
- complete ATA failure coverage
- on-device iPhone/iPad validation of the IPA

## PWA fallback (no IPA)

If you want to use the cockpit on the iPhone/iPad before the IPA is built:

1. Serve `dist/` over HTTPS (or LAN).
2. Safari → Share → Add to Home Screen.
3. It launches standalone with the manifest theme and icon.

This does not replace the self-signed IPA; it is only a fallback for testing the
layout and touch controls on-device.