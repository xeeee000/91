# 验证记录

本文件记录当前交付物的可复现验证结果，而不是功能描述。功能与限制见 `README.md`。

## 1. 原版代码完整性

- 上游仓库：`flybywiresim/aircraft`
- 固定 commit：`acbfe58dff586cf37e7931381948ff78dc1f30ea`
- 对比方式：把 `a32nx-instruments/vendor/` 下每个文件与上游原始检出逐文件 SHA-256 对比。
- 结果：**1415 个文件，0 个不一致，0 个缺失**。
- 结论：`vendor/` 中的 A32NX 仪表/共享代码未被修改；所有适配都在 `src/`、`*.html`、`vite.config.ts`。

## 2. 路由回归

在 `vite preview`（HTTP，非 `file://`）下逐页打开，记录 `pageerror`：

| 路由 | 结果 |
|---|---|
| `/` | 200，7 个 iframe，0 pageerror |
| `/pfd.html` | 200，0 pageerror |
| `/nd.html` | 200，0 pageerror |
| `/ewd.html` | 200，0 pageerror |
| `/sd.html` | 200，0 pageerror |
| `/sd-full.html` | 200，0 pageerror |
| `/sd-full.html?page=3`（ELEC） | 200，0 pageerror |
| `/sd-full.html?page=5`（FUEL） | 200，0 pageerror |
| `/clock.html` | 200，0 pageerror |
| `/isis.html` | 200，0 pageerror |
| `/fcu.html` | 200，0 pageerror |
| `/rmp.html` | 200，0 pageerror |
| `/bat.html` | 200，0 pageerror |
| `/atc.html` | 200，0 pageerror |
| `/mcdu.html` | 200，0 pageerror |
| `/panels.html` | 200，0 pageerror |

合计 16 条路由，0 失败。

## 3. 布局回归

| 分辨率 | 结果 |
|---|---|
| 1920×1080 | 7 个 iframe，全部可见 |
| 1440×900 | 7 个 iframe；截图 `docs/responsive-1440.png` |
| 1366×768 | 7 个 iframe，无溢出 |

## 4. 干净环境构建

把工程复制到空目录（排除 `node_modules`、`.vite`、`dist`），执行：

```bash
npm ci
npm run build
```

- `npm ci` 安装 42 个包。
- `vite build` 成功，约 13 s。
- `dist/`：107 个文件，3.34 MB。
- 产物包含 14 个 HTML 页面：`index`、`pfd`、`nd`、`ewd`、`sd`、`sd-full`、`clock`、`isis`、`fcu`、`rmp`、`bat`、`atc`、`mcdu`、`panels`。

## 5. 交互回归

- **FCU**：输入目标值、`±` 步进、managed 按钮均能更新七段显示（280 / 120 / 30000 / −1200）。
- **RMP**：输入 active/standby 频率后显示 119.100 / 121.800。
- **ATC**：键盘 `CLR → CLR → 1 → 2 → 3 → 4` 后显示 1234，无 pageerror。
- **MCDU 全页面**：MENU / INIT / FPLN / PERF / PROG / DATA / RAD / DIR / SEC / ATC / FUEL / AIRPORT 共 12 个入口，静态构建 0 pageerror；DIR TO 页可打开。
- **FLT NBR**：INIT 页 `FLT` 输入 + SET 后显示 AB123；键盘输入 XY987 + L3 后显示 XY987；`flightNumber` 均为对应值。
- **MCDU/FMS**：INIT 显示 FROM/TO LSGG/LFMN；F-PLN 显示航路，CST `250/5000` 显示为 `250/+5000`，IDX+UP/DN 可重排航路点；PERF 显示 V1/VR/V2，CALC 后为 136/141/146；PERF 页键盘输入 150 后 L1 可将 V1 改为 150；INIT 页键盘输入 `LSGS/LFLL` 后 R1 进入城市对页，无 `FORMAT ERROR`，也没有 flight plan #0 pageerror；ND 通过 `a32nx-fms` 频道收到航路。
- **SD 自动切页**：关 GEN 2 自动切 ELEC；燃油低于 3000 kg 自动切 FUEL。
- **ECAM 警告**：GEN/HYD/FUEL 故障码通过原版 `formatEwdMessages()` 显示。
- **驾驶舱控制**：液压/电源/燃油开关通过 `BroadcastChannel` 驱动 PFD/ND/E/WD/SD/ISIS；飞行姿态、速度、高度、位置由 JS 飞行模型驱动。
- **PFD 目标值**：SEL ALT 30000 / SEL SPD 280 时，PFD 高度读出与速度带目标三角同步到 30000 / 280。
- **起飞**：静态构建，RWY 重置、松刹车、THR 100%，24 s 后 IAS 147 kt；按住 S 抬起机头后，3.5 s 离地，IAS 172 kt、ALT 1483 ft、VS +368 fpm，phase `CLIMB`，0 pageerror。
- **APP 自动进近/着陆**：静态构建，APP 按钮设置 3000 ft / 8 NM、FLAPS 3、GEAR DOWN、AP 目标 1000 ft；接地速度 138 kt，接地率约 -180 fpm（拉平逻辑），12.4 s 后完全停住，phase `LANDED`。
- **失速/超速提示**：低推力拉杆至 IAS 105 kt / AOA 14.1° 时 HUD 出现 `STALL`；襟翼超速时出现 `OVERSPEED`。
- **时间加速**：`T` / HUD `RATE` 在 1×/2×/4×/8× 间切换，静态构建可用。
- **HUD**：RWY / APP / GEAR / FLAPS / BRAKE / AP / PAUSE / RESET 按钮与 `S/W/A/D/Q/E`、Shift/Ctrl、G/F/B/P/R 键盘输入可用；HUD 显示 GS/VS/AOA/N1 与 phase。

## 6. 已知无害警告

Chromium 对 PFD/SD 原版 SVG 的 `rotateX(0deg)` 会打印：

```
Error: <g> attribute transform: Expected '(', "rotateX(0deg)".
```

这是原版 3D 鼓形/姿态动画使用的 SVG transform，Chromium 不支持该写法；不影响页面渲染，也不是适配层引入的错误。

MCDU/FMS 还会打印以下控制台信息：

- `ERR_CONNECTION_REFUSED`：原版 `McduServerClient` 尝试连接 SimBridge WebSocket；独立环境没有该服务。
- `[FMS] Error during LNAV update ... isXF`：程序化注入的简化航段缺少完整 navdata 定义，LNAV 几何更新会报错；MCDU 页面和 ND 航路仍正常。\n- city pair 删除/重建 active plan 的空窗期已由适配层 guard，不再抛 pageerror。

## 7. 未完成项

- **MCDU/FMS**：原版页面、键盘、F-PLN 航路编辑/重排/约束、PERF 字段录入和简化性能计算已可用；还缺真实 navdata、完整起飞性能计算和任意航路点的直接定位编辑。
- **飞行模型**：简化点质量气动模型，没有完整 FBW Normal Law、发动机失效、结冰、地效、起落架损坏和失速改出逻辑；爬升/下降性能为演示级。
- **真实 FMS/navdata**：航路来自迷你本地库与程序化注入，不是 navdata 计算的航路。
- **完整 FWC 码表**：仅覆盖 GEN、HYD、FUEL 的少量警告码。
- **TCAS 交通源**：`registerTrafficListener()` 在独立环境中是空实现，ATC 只显示代码，不显示交通。
- **3D 面板/旋钮**：FCU/RMP 只有显示与输入，没有 3D 外形。

## 8. 复现命令

```bash
cd a32nx-instruments
npm install
npm run dev       # http://localhost:5177
npm run build
npm run preview   # http://localhost:5178
```

## 9. Rust 核心（阶段 0/1）

- cargo build --release --target wasm32-unknown-unknown 生成 sim_core.wasm（22,239 bytes）。
- 浏览器 cockpit 的 __A32NX_FLIGHT_MODEL__.source 为 ust-wasm，TS 模型仅作 fetch 失败回退。
- 静态构建：Rust 核心起飞 0→152 kt（25 s），抬轮后 184 kt / 1713 ft / +2501 fpm，0 pageerror。
- dist 104 文件 / 3.32 MB。

## 10. Phase 0 shell/CI status

- GitHub workflows: `ci.yml`, `windows-shell.yml`, `ios-unsigned.yml`.
- `actionlint 1.7.12` on all three workflows: **0 errors**.
- Rust wasm: `sim_core.wasm` 22,239 bytes; browser `source: "rust-wasm"`.
- Windows Tauri `cargo check` reached dependency compilation but this host has no MSVC `link.exe`; CI `windows-latest` has the MSVC toolchain.
- iOS Swift/Xcode build not executable on this Windows host; `ios-unsigned.yml` is the build path.
- No IPA or Windows installer artifact has been produced locally yet.


## 11. 顶板与冷舱（第一切片）

- 新增 /overhead.html：ELEC / APU / HYD / FUEL / AIR / PRESS / ANTI ICE / ADIRS。
- 状态通过 32nx-overhead 广播；cockpit 根据 AC/DC 总线给 6 个屏幕加 .unpowered。
- 冷舱：6 个屏幕全黑；BAT 1：2 个 DC 屏幕恢复；EXT PWR：6 个全部恢复。
- 静态构建 0 pageerror；dist 107 文件 / 3.33 MB，15 个 HTML。

## 12. 液压/电气耦合

- 顶板 BAT 1 + EXT PWR 后，GEN 1/2 仍 OFF，E/WD 显示 ELEC GEN 1/2 OFF。
- 仅 ELEC 1 泵 ON：SD HYD 显示 GREEN 3000 PSI、BLUE 0、YELLOW 0。
- E/WD 显示 BLUE ELEC PUMP OFF、YELLOW ENG 2 PUMP OFF。
- hydGreen/hydGreenPressure 在 cockpit 总线中随顶板变化：false/0 → true/3000。
- 静态构建 0 pageerror；dist 107 文件 / 3.33 MB。

## 13. PACKS 空调耦合

- 顶板 PACK 1/2 开关进入 32nx-sim 总线的 pack1/pack2。
- E/WD 设置原版 pack flow valve SimVar，并注入 FWC 216120701/216120801。
- PACK 1/2 OFF：E/WD 显示 AIR PACK 1 OFF 与 PACK 2 OFF；PACK 1 ON 后 PACK 1 行消失。
- 静态构建 0 pageerror，dist 107 文件 / 3.33 MB。

## 14. APU/燃油泵耦合

- 顶板 APU MASTER/START → 5 s 后 AVAIL；APU GEN 关闭 3XS 并给 AC 总线供电。
- SD APU 页：AVAIL、APU GEN 20% / 115 V / 400 Hz、BLEED 46 PSI。
- FUEL L/R/C + XFEED 写入 FUELSYSTEM PUMP ACTIVE/SWITCH 与阀门。
- 发动机 N1 > 5% 且 L/R 泵关闭时，E/WD 注入 280013006/280014006。
- 静态构建 0 pageerror；dist 107 文件 / 3.34 MB。

## 15. 发动机启动

- 顶板 ENG MASTER/START；需要 APU BLEED+AVAIL 或 XBLEED+另一台发动机。
- 单台 18 s 到慢车，cockpit 将 idle 设为 24% N1。
- E/WD：运行发动机 N1 24%、EGT 451°C、N2 56.8%、FF 280；未启动发动机显示 XX。
- 静态构建 0 pageerror；dist 107 文件 / 3.34 MB。

## 16. BLEED / PRESS 页

- BLEED：XBLEED、ENG PR、APU BLEED、PACK、WING ANTI ICE 由顶板驱动；SD 显示 46 PSI 与阀位。
- PRESS：CPC1/2 ARINC 字由飞行高度驱动；地面 ΔP 0.0 PSI、V/S 0、CAB ALT 0、LDG ELEV 1400 FT。
- 静态构建 0 pageerror；dist 107 文件 / 3.34 MB。

## 17. 发动机火警

- 顶板 FIRE ENG 1/2 按钮锁存火警，强制对应 MASTER OFF 并停车。
- E/WD 注入 FWC 260001001/260002001，顶部显示 ENG 1 FIRE / ENG 2 FIRE。
- 火警后两台发动机 E/WD 显示 XX，cockpit 油门被压到 0。
- 静态构建 0 pageerror；dist 107 文件 / 3.34 MB。

## 18. ZBAD → ZBAA 首航

- 新增 ZBAD/ZBAA/ZB01/ZB02/ZB03 本地航路点与 AIRPORT_SCENE。
- Rust sim_reset_at 支持机场坐标/标高/跑道航向。
- cockpit 监听 FMS origin，自动把飞机放到 ZBAD：39.5098/116.4105，ALT 118 ft，HDG 010。
- MCDU INIT ZBAD/ZBAA；F-PLN ZB01→ZB02→ZB03；0 pageerror。
- dist 107 文件 / 3.34 MB。

## 19. 手机/平板全仪表布局

- <=900px：3×2 网格，6 个仪表全部可见；iPhone 852×393 无横向滚动。
- iPad 1194×834：同样 6 个仪表全部可见。
- 小屏默认隐藏 HUD，顶栏 FLIGHT 可切换；HUD 宽度 320px。
- safe-area + viewport-fit=cover。
- 静态构建 0 pageerror；dist 107 文件 / 3.34 MB。

## 20. Navdata provider / 跑道

- NavDataProvider 抽象 + Local 实现；后续 OpenAIP/Navigraph 直接替换。
- 本地跑道：ZBAD 01L/19R、01R/19L；ZBAA 18L/36R、18R/36L、01/19；LSGG 04/22。
- FMS setOriginAirport('ZBAD') 与 setOriginRunway('01L') 均返回 ok。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 21. LNAV 与地面感应

- NAV 模式 + AP：根据 FMS 下一个航路点计算 bearing，命令 HDG；1.5 NM 内切换下一点。
- ZBAD → ZB01 目标航向 008°，与实际大圆方位一致。
- PFD/SD 起落架压缩改用 radio altitude，ZBAD 118 ft 正确判定在地面。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 22. APU 火警

- 顶板 APU FIRE 锁存火警，关闭 APU MASTER/AVAIL/GEN/BLEED。
- E/WD 注入 FWC 260003001，显示 APU FIRE。
- 发动机火警与 APU 火警相互独立。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 23. 复飞

- HUD GA 按钮 → Rust sim_go_around()：离地、+1200 fpm、TOGA、襟翼 2、收起落架、AP 接通。
- ZBAD：ALT 196 ft、V/S +1143 fpm、THR 100%、目标 3100 ft。
- APP 仍为独立进近重置。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 24. 灭火瓶 / QRH

- FIRE 面板 AGENT 1/2/APU AGENT；有对应火警才能释放。
- 5 s 后火警熄灭，E/WD APU FIRE 消失；发动机火警后发动机保持停车。
- QRH 覆盖层：ENG FIRE / APU FIRE / GO AROUND。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 25. SID / STAR / RNAV 进近

- 本地提供 ZBAD ZB1D、ZBAA ZB2A、ZBAA RNAV18L。
- FMS setDeparture('ZBAD/ZB1D')、setArrival('ZBAA/ZB2A')、setApproach('ZBAA/RNAV18L') 均成功。
- 程序腿使用 ARINC TF 结构；为简化训练程序，不是真实航图文本。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 26. 目的地进近重置

- HUD APP 读取 FMS 目的地 ZBAA，放到跑道前 8 NM。
- Rust sim_reset_approach_at() 支持任意机场。
- ZBAA：40.212/116.585，ALT 2104 ft，HDG 177，V/S -674 fpm，FLAPS 4，GEAR DOWN，AP ON。
- 无 FMS 目的地时回退 LSGG 进近。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 27. 目的地进近与程序腿

- publishFmsRoute() 优先读取 active flight plan 的 llLegs（含 SID/STAR/approach），静态 ZB 点作为回退。
- LNAV 最终点只在航线不含目的地时追加。
- APP 读取 FMS 目的地，ZBAA 8 NM 进近：40.212/116.585，ALT 2104 ft，HDG 177，V/S -674 fpm，FLAPS 4，GEAR DOWN。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 28. ZBAD → ZBAA 连续剖面

- 冷舱 → BAT/EXT → APU → FUEL L PUMPS → ENG 1 启动 → ZBAD 01L 起飞 → AP NAV → 20 000 ft。
- LNAV 顺序 ZB01→ZB02→ZB03，距 ZBAA 9.7 NM 时 APP。
- 进近从 2 100 ft 降到 116 ft，FLAPS 4 / GEAR DOWN。
- 落地：ZBAA 116 ft，103 kt，**-400 fpm**，phase LANDED。
- 全程 0 pageerror。
- 进近油门改为 N1 20%，避免 170 kt 飘飞/爬升；现在稳定在 135 kt 左右并落地。
- 静态构建 0 pageerror；dist 110 个文件 / 3.36 MB。

## 29. OpenAIP adapter

- OpenAipProvider 支持 API {items} 或机场数组、GeoJSON 坐标、跑道阈值。
- 合成数据：ZBAD 39.5098/116.4105，标高 118 ft，01L 3800 m。
- setNavDataProvider() 运行时切换；MCDU 仍加载 ZBAD/ZBAA，0 pageerror。
- public/navdata/README.md 说明离线导入；本地 provider 仍是默认。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 30. 发动机/APU 失效

- ENG FAIL 1/2 强制 MASTER OFF 并停车；双发失效 E/WD 显示 ALL ENG FAIL PROC.APPLY（770002712），参数 XX。
- APU FAIL 关闭 AVAIL/GEN/BLEED，点亮 FAULT。
- 火警与失效独立。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 31. 货舱烟雾 / 快速释压

- CARGO SMOKE → E/WD SMOKE FWD CARGO SMOKE（260015001）。
- DEPRESS → E/WD CAB PR EXCESS CAB ALT（213122101），SD CAB ALT 14000 ft / ΔP 0。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 32. 起落架 / ELAC 故障

- GEAR FAIL：起落架收起时 E/WD L/G GEAR NOT DOWN（320015001），HUD GEAR 不能放下。
- ELAC 1：E/WD F/CTL ELAC 1 FAULT（270011001），AP 断开并保持断开。
- 两个故障可叠加；静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 33. SEC/FAC 故障

- SEC 1 → F/CTL SEC 1 FAULT（270021001）；FAC 1 → AUTO FLT FAC 1 FAULT（220020001）。
- ELAC/SEC 故障时 pitch/roll 权限降到 60%；FAC 故障时 yaw 权限降到 40%。
- 故障可叠加；静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 34. 独立仪表供电

- MCDU/BAT 接 DC，FCU/RMP/ATC 接 AC。
- power-request 握手让新开页面立即拿到当前总线状态。
- 静态验证：冷舱 MCDU unpowered；BAT 1 后 MCDU 恢复；EXT PWR 恢复 AC 页面。
- 0 pageerror；dist 110 文件 / 3.36 MB。

## 35. 飞行法则

- HUD 显示 NORMAL LAW / ALT LAW / DIRECT LAW。
- 单个 ELAC/SEC/FAC 故障 → ALTERNATE；任意两个 → DIRECT。
- 操纵权限：100% / 72% / 50%；FAC 故障 yaw 40%。
- ELAC 或 DIRECT 强制 AP OFF。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 35. Normal / Alternate / Direct 法则

- HUD 显示 NORMAL LAW / ALT LAW / DIRECT LAW。
- 单个 ELAC/SEC/FAC 故障 → ALTERNATE；任意两个 → DIRECT。
- 权限 100% / 72% / 50%；FAC 故障 yaw 40%。
- ELAC 或 DIRECT 强制 AP OFF。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 36. 燃油泄漏

- FUEL LEAK L/R → E/WD L/R WING TK LO LVL（280013001/280014001）。
- SD FUEL 受影响油箱降到 3%。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 37. 舱门

- CABIN DOOR / CARGO DOOR → SD DOOR/OXY 警告形状；FWD_DOOR_CARGO_LOCKED 为 false。
- 舱门可同时打开；静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 38. 机组氧气

- OXY → E/WD -CREW OXY MASKS.....USE（213122102）。
- SD DOOR/OXY 的 PUSH_OVHD_OXYGEN_CREW 跟随故障。
- 静态构建 0 pageerror；dist 110 文件 / 3.36 MB。

## 39. 热空气故障

- HOT AIR → E/WD COND HOT AIR FAULT（216329001）。
- 静态构建 0 pageerror；dist 110 文件 / 3.37 MB。

## 40. 启动联锁

- APU START 需要 DC；ENG START 需要 DC + 对应燃油泵 + 引气。
- 拦截消息保持 3 秒：NO DC POWER...、ENG 1 · FUEL PUMPS OFF。
- 静态构建 0 pageerror；dist 110 文件 / 3.37 MB。

## 41. 外部灯光

- LIGHTS：NAV/BEACON/STROBE/LANDING/TAXI；EXT LT 状态灯。
- 映射 LIGHT NAV/BEACON/STROBE/LANDING/TAXI SimVar。
- 静态构建 0 pageerror；dist 110 文件 / 3.37 MB。

## 42. 全页面/供电回归

- 15 个页面全部 HTTP 200、0 pageerror。
- 冷舱：FCU/RMP/ATC + BAT/MCDU 全部 unpowered。
- BAT 1：BAT/MCDU 恢复；EXT PWR：FCU/RMP/ATC 恢复。
- dist 110 文件 / 3.37 MB。

## 43. ADIRS 校准

- ADIRS 1+2+3 ON → E/WD IR 1+2+3 IN ALIGN（340004812），10 秒后消失。
- ADIRS NAV 灯变绿；任一开关关闭则重新校准。
- 静态构建 0 pageerror；dist 110 文件 / 3.37 MB。

## 44. PWA 备用安装

- manifest + 192/512 + apple-touch-icon；Safari 可添加到主屏幕全屏运行。
- 这是 IPA 之外的备用路径，不是替代品。
- manifest 200、icon 200、0 pageerror；dist 114 文件 / 3.53 MB。

## 45. 最终回归

- PWA/ADIRS/LIGHTS 之后再次跑 15 页面：全部 200、0 pageerror。
- dist 114 文件 / 3.53 MB。
