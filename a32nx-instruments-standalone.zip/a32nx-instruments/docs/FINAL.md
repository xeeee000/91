# Final state — round 40

## Delivered

### Standalone cockpit

- 15 pages: cockpit, PFD, ND, E/WD, SD, clock, ISIS, FCU, RMP, BAT, ATC, MCDU, panels, overhead, SD-full.
- Final regression: all 15 → HTTP 200, 0 pageerror.
- `dist`: 114 files / 3.53 MB.

### Rust / WASM flight core

- `crates/sim-core` compiled to `wasm32-unknown-unknown`.
- Browser source is `rust-wasm`.
- Takeoff, climb, LNAV, destination approach, autoland, flare, stall and go-around tested.
- `sim_reset_at`, `sim_reset_approach_at`, `sim_go_around`.

### ZBAD → ZBAA

- Cold & dark → APU → fuel pumps → ENG 1 → takeoff 01L.
- LNAV ZB01 → ZB02 → ZB03.
- APP to ZBAA final 8 NM.
- Touchdown: ZBAA 116 ft, 103 kt, **-400 fpm**, phase `LANDED`.
- No pageerror during the run.

### Systems / overhead

- ELEC, APU, ENG, FIRE, FAULTS, HYD, FUEL, AIR, PRESS, ANTI ICE, ADIRS, LIGHTS.
- Cold & dark, battery/EXT/APU/engine start interlocks.
- HYD, PACK, BLEED, PRESS, fuel pumps/leaks, doors, crew oxygen, hot air.
- ADIRS 10 s alignment.
- Fire agents, QRH, go-around.

### V2 failure slice

- ENG 1/2 FIRE and FAIL
- APU FIRE and FAIL
- CARGO SMOKE
- RAPID DEPRESS
- GEAR FAIL
- ELAC 1 / SEC 1 / FAC 1
- NORMAL / ALTERNATE / DIRECT law
- FUEL LEAK L/R
- CABIN / CARGO DOOR
- CREW OXY
- HOT AIR
- GEN / HYD / PACK / BLEED switch faults

### Mobile

- iPhone landscape 852×393: 6 instruments visible.
- iPhone portrait 393×852: 6 instruments visible (2×3).
- iPad landscape 1194×834: 6 instruments visible.
- iPad portrait 834×1194: 6 instruments visible (2×3).
- PWA "Add to Home Screen" fallback.

## Not delivered

### iOS unsigned IPA

The SwiftUI/WKWebView shell, XcodeGen project and
`.github/workflows/ios-unsigned.yml` are present, but no Mac is available in
this workspace and the repository has not been pushed to GitHub Actions.
Therefore no actual `.ipa` exists yet.

### Windows installer

The Tauri 2 project and `.github/workflows/windows-shell.yml` are present, but
the local Windows machine has no MSVC `link.exe`; the workflow has not run.

### Real OpenAIP data

`OpenAipProvider` and the optional `/navdata/openaip.json` bootstrap exist and
were tested with synthetic data. The real OpenAIP export/API was not reachable
from this environment.

### Full A32NX parity

The flight model is a simplified 6DOF-ish model, not a full rigid-body/FBW
Normal Law implementation. ATA coverage is broad but not complete (SEC/FAC law
tables, all ATA chapters, full QRH branches).

## Exact next actions

1. Push `a32nx-instruments` to GitHub.
2. Run `ios-unsigned.yml`; download `A32NXSim-unsigned.ipa`.
3. Self-sign with AltStore/Sideloadly (see `RELEASE.md`).
4. Run `windows-shell.yml`; download NSIS/MSI.
5. Drop a real OpenAIP export at `public/navdata/openaip.json` if desired.
6. On-device test the IPA and report layout/touch issues.

## Evidence files

- `VERIFICATION.md` — 45 sections of verification.
- `docs/STATUS.md` — capability matrix.
- `RELEASE.md` — build/self-sign steps.
- `docs/route-landed.png` — ZBAA touchdown.
- `docs/direct-law.png` — DIRECT LAW.
- `docs/door-page.png`, `docs/fuel-leak.png`, `docs/smoke-press.png` — V2.
