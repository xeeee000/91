# A32NX standalone status

Last updated: round 40. `dist` 114 files / 3.53 MB.

## Phase 0 — shells and CI

| Item | Status |
| --- | --- |
| Windows Tauri 2 shell | config + icon + capabilities present; **not built locally** (no MSVC) |
| iOS SwiftUI/WKWebView shell | code + XcodeGen project present; **not built locally** (no Mac) |
| `a32nx://` scheme handler | done (MIME, traversal guard) |
| GitHub Actions CI | Ubuntu/Windows Rust + wasm + web jobs |
| iOS unsigned IPA workflow | present; **artifact not yet generated** |
| Windows installer workflow | present; **artifact not yet generated** |
| actionlint | 0 errors |

The workflows are ready but require the repository to be pushed to GitHub.
See `RELEASE.md`.

## Phase 1 — Rust flight core

| Item | Status |
| --- | --- |
| wasm32 target | built and loaded (`source: rust-wasm`) |
| 6DOF-ish state / rates | done |
| takeoff / climb / autoland / flare / stall / GA | tested |
| `sim_reset_at` airport scene | done |
| `sim_reset_approach_at` | done |
| full rigid-body aero / FBW Normal Law | simplified, not MSFS-grade |
| native MSVC tests | blocked locally; CI covers |

## Systems / overhead

| Area | Status |
| --- | --- |
| Cold & dark, BAT/EXT/GEN/APU | done |
| AC/DC displays + standalone MCDU/FCU/RMP/ATC/BAT | done |
| HYD G/B/Y | done |
| FUEL pumps/XFEED/leaks | done |
| PACK / BLEED / PRESS / ANTI ICE / ADIRS | partial; ADIRS 10 s alignment done |
| Engine start, fire, failure, agent | done; start interlocks (DC/fuel/bleed) |
| APU start/fire/fail/bleed | done; APU start requires DC |
| QRH overlay | done |
| Doors / crew oxygen / hot air | done |
| Exterior lights | done |
| Full ATA 21–49 matrix | **partial** |

## Route / navdata

| Item | Status |
| --- | --- |
| ZBAD → ZBAA route | done |
| LNAV | simple waypoint steering |
| SID ZB1D / STAR ZB2A / RNAV18L | simplified training procedures |
| ZBAD 01L / ZBAA 18L runways | done |
| continuous cold&dark→landing | verified (-400 fpm at ZBAA) |
| OpenAIP adapter | done; **real data file not imported** |
| Navigraph adapter | interface only |
| real SID/STAR charts | **not done** |

## V2 failures

Done:

- ENG 1/2 FIRE / FAIL
- APU FIRE / FAIL
- CARGO SMOKE
- RAPID DEPRESS
- GEAR FAIL
- ELAC 1 / SEC 1 / FAC 1
- NORMAL / ALTERNATE / DIRECT law
- FUEL LEAK L/R
- CABIN / CARGO DOOR
- CREW OXY
- HOT AIR
- ADIRS alignment
- exterior lights
- GEN/HYD/PACK/BLEED switch faults

Missing:

- complete ATA coverage
- smoke/oxygen QRH branches
- SEC/FAC full law tables
- failure propagation to every display/system

## Mobile

| Item | Status |
| --- | --- |
| iPhone landscape 852×393 | 6 instruments visible |
| iPhone portrait 393×852 | 6 instruments visible (2×3) |
| iPad landscape 1194×834 | 6 instruments visible |
| iPad portrait 834×1194 | 6 instruments visible (2×3) |
| HUD toggle | done |
| safe-area / viewport-fit | done |
| PWA Add to Home Screen fallback | done |
| real WKWebView validation | **blocked on IPA** |

## Honest bottom line

This is a working standalone cockpit with a Rust wasm flight core, a large
overhead/ECAM slice, a verified ZBAD → ZBAA flight, and broad V2 fault
coverage. It is not yet a complete A32NX systems clone, and the iOS/Windows
installers have not been produced on this machine.
