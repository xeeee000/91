# A32NX Instrument Suite — Standalone (Browser)

把 FlyByWire A32NX 的仪表渲染层从 MSFS / WASM 环境中剥离出来，在普通浏览器中独立运行。
**原始仪表源码未做任何修改**，MSFS 依赖通过适配层（globals + SimVar store + 模块别名）注入。

> 上游：https://github.com/flybywiresim/aircraft
> 固定提交：`acbfe58dff586cf37e7931381948ff78dc1f30ea`
> 许可证：GPL-3.0（见 `LICENSE`）

- 当前能力/缺口矩阵：[docs/STATUS.md](docs/STATUS.md)
- 自行签名 IPA / Windows 安装包步骤：[RELEASE.md](RELEASE.md)

![cockpit](docs/cockpit.png)

![PFD FMA](docs/pfd-fma.png)

![PFD approach](docs/fma-app.png)

![ND ROSE ILS](docs/nd-ils.png)

![ND route](docs/nd-route.png)

![ND DIR TO](docs/nd-dirto.png)

![ND waypoint insert](docs/nd-wpt-insert.png)

![ND ARC](docs/nd-arc.png)

![ND PLAN](docs/nd-plan.png)

![ILS dynamic deviation](docs/ils-dynamic.png)

![FLARE](docs/fma-flare.png)

![SRS](docs/fma-srs.png)

![PFD selected targets](docs/pfd-targets.png)

![FCU targets](docs/fcu-interactive.png)

![FCU managed](docs/fcu-step.png)

![RMP frequencies](docs/rmp-interactive.png)

![BAT](docs/bat.png)

![ATC](docs/atc.png)

![ATC keypad](docs/atc-keypad.png)

![MCDU F-PLN](docs/mcdu-fpln.png)

![MCDU INIT](docs/mcdu-init.png)

![MCDU FLT NBR](docs/mcdu-flt.png)

![MCDU PERF](docs/mcdu-perf.png)

![MCDU constraints](docs/mcdu-cst.png)

![MCDU city pair](docs/mcdu-city.png)

![ND FMS route](docs/nd-fms.png)

![flight controls](docs/controls.png)

系统页示例（ELEC，健康状态 / GEN 2 断开）：

![SD ELEC](docs/sd-elec.png)

![SD ELEC fault](docs/fault-elec.png)

液压泵关闭过程中的瞬态（GREEN 从 3000 → 0 PSI）：

![HYD transient](docs/hyd-ramp.png)

![ECAM auto page](docs/ecam-auto.png)

![E/WD warnings](docs/ewd-warning.png)

![E/WD fuel low](docs/ewd-fuel-low.png)

---

## 1. 当前已跑通的仪表

| 仪表 | 上游源码 | 状态 | 说明 |
|---|---|---|---|
| PFD | `fbw-a32nx/src/systems/instruments/src/PFD` | ✅ 独立运行 | 姿态、速度带、高度带、升降速度、航向带、FMA、ILS 菱形、无线电高度、SEL SPD/ALT 目标值 |
| ND | `fbw-a32nx/src/systems/instruments/src/ND` + `fbw-common/.../ND` | ✅ 独立运行 | ROSE NAV / ARC / PLAN、10–320 NM 距离、罗盘、距离环、飞机符号、GS/TAS、TERR、演示航路与航路点 |
| E/WD | `fbw-a32nx/src/systems/instruments/src/EWD` | ✅ 独立运行 | N1/N2/EGT/FF、FOB、PACKS、缝翼襟翼、ECAM 警告（GEN/HYD/FUEL） |
| SD | `fbw-a32nx/src/systems/instruments/src/SD`（legacy React 全量版） | ✅ 完整页面 | 11 页；ENG / ELEC / HYD / FUEL 已有健康系统数据；默认 ENG，`?page=N` 切换；`/sd.html` 保留 SDv2 |
| Clock | `fbw-a32nx/src/systems/instruments/src/Clock` + `fbw-common/.../Clock` | ✅ 独立运行 | UTC、日期、计时 |
| ISIS | `fbw-a32nx/src/systems/instruments/src/ISIS` | ✅ 独立运行 | 备用姿态、速度带、高度带、气压基准、ILS |
| FCU | `fbw-a32nx/src/systems/instruments/src/FCU` | ◐ 显示 + 目标输入 | SPD/HDG/ALT/V/S 七段显示、± 步进、M（managed）按钮、EFIS baro；面板底图/3D 旋钮属于模型，未接 |
| RMP | `fbw-a32nx/src/systems/instruments/src/RMP` | ◐ 显示 + 频率输入 | 双侧 VHF1 active/standby 七段显示，`panels.html` 可输入频率；按键/3D 外形未接 |
| BAT | `fbw-a32nx/src/systems/instruments/src/BAT` | ✅ 独立运行 | 双电池电压 28.0 V，原始七段字体 |
| ATC | `fbw-a32nx/src/systems/instruments/src/ATC` | ◐ 显示 + 键盘 | 应答机代码 2000，0–7/CLR 键盘；CLR 先删一位、再按清空；TCAS 计算机已启动 |
| MCDU | `fbw-a32nx/src/systems/instruments/src/MCDU` | ◐ 可用 | 原版 INIT/F-PLN/PERF；FLT NBR（L3 或 FLT SET）、FROM/TO 城市对、PERF 键盘录入、ALT/SPD 约束、IDX 重排、V 速度 CALC、ND 同步 |

> SD 现在默认使用上游 **legacy 全量 React 版**（`/sd-full.html`，12 个 ECAM 页），SDv2 保留在 `/sd.html`（目前只有 F/CTL、STATUS 两页）。
> ISIS 与 legacy SD 使用 React 17；项目为此增加了 `@flybywiresim/fbw-sdk-react` 门面和一个按文件切换 JSX runtime 的 Vite 插件。

---

## 2. 运行

要求 Node.js ≥ 20。

```bash
cd a32nx-instruments
npm install
npm run dev
# 打开 http://localhost:5177
```

生产构建 / 静态预览：

```bash
npm run build
npm run preview
# http://localhost:5178
```

> 必须通过 HTTP 访问，不能直接双击 `dist/index.html`（ES module 与 `/Fonts/...` 绝对路径限制）。

### 页面

| 页面 | 内容 |
|---|---|
| `/` | 2×2 + 右侧 Clock/ISIS 栏驾驶舱布局（PFD / ND / E/WD / SD / Clock / ISIS），SD 标题栏可切换 11 个 ECAM 页；GEN/HYD/FUEL 故障会自动切到对应系统页；`CONTROLS` 打开飞行数据控制抽屉，双击或按 `1`–`6` 全屏 |
| `/pfd.html` | 单台 PFD |
| `/nd.html` | 单台 ND |
| `/ewd.html` | 单台 E/WD |
| `/sd.html` | SDv2（F/CTL 页） |
| `/sd-full.html` | legacy 全量 SD，`?page=0..11` 选择 ECAM 页 |
| `/clock.html` | 单台时钟 |
| `/isis.html` | 单台 ISIS |
| `/fcu.html` | FCU 显示层（实验性，无面板按键） |
| `/rmp.html` | RMP 显示层（双侧 VHF/NAV 频率） |
| `/bat.html` | BAT 双电池电压显示 |
| `/atc.html` | ATC 应答机代码显示 + 0–7/CLR 键盘 |
| `/mcdu.html` | 原版 MCDU：显示 + 键盘 + FMS 演示航路 + FMS LITE 航路编辑条 |
| `/panels.html` | Pedestal 面板页，FCU / RMP / BAT / ATC / MCDU 切换；FCU 可输入目标/步进/managed，RMP 可输入 active/standby 频率 |

---

## 3. 架构：为什么原始代码可以不改

MSFS 仪表只依赖少量运行时全局对象和 `@microsoft/msfs-sdk`。我们没有改仪表，而是在它们下面换了一层“地面设备”：

```
┌──────────────────────────────────────────────────────────────┐
│  原始 A32NX 仪表代码（vendor/，逐字节来自上游，未修改）        │
│  PFD.tsx / ND.tsx / EWD.tsx / SD.tsx + SimVarPublisher ...    │
└───────────────────────────┬──────────────────────────────────┘
                            │  SimVar.GetSimVarValue()
                            │  Coherent.call()
                            │  BaseInstrument / registerInstrument
┌───────────────────────────▼──────────────────────────────────┐
│  src/harness/  ——  MSFS 运行时垫片                             │
│  globals.ts        BaseInstrument / registerInstrument /      │
│                    Coherent / simvar / LatLongAlt / ...       │
│  simvar-store.ts   带单位换算的 SimVar 存储                    │
└───────────────────────────┬──────────────────────────────────┘
                            │  L:A32NX_* / E:* / A:*
┌───────────────────────────▼──────────────────────────────────┐
│  src/data/  ——  JS 数据层（替代 MSFS + WASM systems）          │
│  pfd-feed.ts   ADIRS / FCU / FAC / FCDC / FMGC 的 ARINC 字与离散字  │
│  pfd-targets.ts SEL SPD / SEL ALT（PFD 目标值）                      │
│  nd-feed.ts    EFIS 控制、ND 模式/距离                              │
│  nd-state.ts   ND 模式与距离（驾驶舱可切换）                        │
│  route-feed.ts 通过 EB_EVENTS 注入航路，支持 DIR TO / 航路点插入           │
│  mini-navdata.ts 替换 MSFS facility backend，解析本地机场/航路点            │
│  waypoints.ts  迷你航路点库（LSGG/LSGS/LSGL/LFLL/LFMN/LIMC…）             │
│  ewd-feed.ts   发动机、燃油、引气、FWC 警告码                        │
│  sd-feed.ts    FCDC 舵面、液压、电气、GW                          │
│  clock-feed.ts 时钟电源、UTC、日期                                │
│  engine-state.ts N1 → N2/EGT/FF 的简化发动机模型                   │
│  systems-feed.ts 电气/液压/燃油稳态值 + 发电机/液压泵开关         │
│  systems-state.ts GEN/HYD 开关状态                                  │
│  isis-feed.ts  备用仪表：气压、空速、姿态、亮度                    │
│  fcu-feed.ts   FCU 七段显示与 EFIS baro                            │
│  fcu-state.ts  FCU 目标值（SPD/HDG/ALT/VS）                         │
│  rmp-feed.ts   RMP VHF 频率，rmp-state.ts 保存 active/standby          │
└──────────────────────────────────────────────────────────────┘
```

关键点：

1. **不改源码**：`vendor/` 内所有文件与上游提交一致。所有适配都在 `src/`。
2. **模块别名**：`vite.config.ts` 把上游 tsconfig 里的路径别名原样映射（`@shared`、`@failures`、`@flybywiresim/pfd` 等），因此相对导入/别名导入都能按 MSFS 构建时的规则解析。
3. **`@flybywiresim/fbw-sdk` 门面**：上游包索引会把 FMS、导航数据库、EFB、Sentry 全部拉进来；`src/sdk/fbw-sdk.ts` 只重导出仪表真正用到的运行时子集（ARINC 429、EventBus、publisher、FailuresConsumer 等）。这是唯一一个“替代模块”，不涉及渲染逻辑。
4. **ARINC 字**：FBW 的 `Arinc429Word` 并不是真实 429 位域，而是 `float32 value + 2 bit SSM`。因此 JS 侧可以直接 `Arinc429Word.getRawWord(value, NormalOperation)` 生成仪表可消费的字，无需复刻 WASM 的位打包。
5. **时间**：`E:SIMULATION TIME` / `E:ABSOLUTE TIME` 必须持续推进，否则 PFD 的高度 LagFilter、时钟、刷新逻辑不会工作。
6. **共享飞行状态**：驾驶舱页的 `CONTROLS` 抽屉通过 `BroadcastChannel('a32nx-sim')` 广播 ALT / IAS / HDG / V/S / PITCH / ROLL / N1 / FUEL / SEL SPD / SEL ALT、GEN/HYD 开关、LAT（HDG/NAV/APP）、VERT（ALT/VS/CLB/SRS）、AP、ND 模式/距离、`DIR TO` 索引和自定义航路；PFD、ND、E/WD、SD、ISIS 的 iframe 订阅后更新各自的 `flight` / `engineState` / `systemsState` / `fmaState` / `ndState` / `routeState` / `pfdTargets` 并重新发布 SimVar。

---

## 4. 目录

```
a32nx-instruments/
├─ index.html            驾驶舱 2×2 + 时钟栏布局
├─ pfd.html / nd.html / ewd.html / sd.html
├─ src/
│  ├─ cockpit.ts         全屏、UTC
│  ├─ pfd-main.ts        启动顺序：globals → 数据 → 动态 import 仪表 → 帧循环
│  ├─ nd-main.ts / ewd-main.ts / sd-main.ts
│  ├─ harness/
│  │  ├─ globals.ts      MSFS 全局对象垫片
│  │  └─ simvar-store.ts SimVar 存储 + 单位换算
│  ├─ sdk/fbw-sdk.ts     fbw-sdk 门面（FSComponent 仪表）
│  ├─ sdk/fbw-sdk-react.ts  fbw-sdk-react 门面（ISIS / 旧 SD）
│  ├─ data/              各仪表的数据适配
│  └─ instruments/       对 vendor 仪表入口的薄 import
├─ vendor/
│  ├─ fbw-a32nx/src/systems/...
│  └─ fbw-common/src/systems/...
├─ public/Fonts/fbw-a32nx/     ECAM / NDChrono / AirbusChronometer / AirbusFCU / AirbusRMP / ISIS 字体
├─ public/Images/fbw-a32nx/FCU/fcu-background.png
└─ docs/
```

---

## 5. 数据层现状（重要）

当前是**演示飞行状态**，不是完整的 A320 系统仿真：

- 姿态：pitch 2.5°、roll 0°，默认带轻微正弦运动；一旦从驾驶舱 `CONTROLS` 广播数据，演示运动自动停止；
- 高度 12 000 ft、IAS 250 kt、Mach 0.48、HDG 045，可从控制抽屉实时修改；
- ADIRS 同时向 IR/ADR 1、2、3 发布数据（A320 的 ATT/HDG 与 AIR DATA 旋钮在 NORM 位时使用 3 号源，这是上游 `getSupplier()` 的行为）；
- 发动机：N1 以 8 %/s 跟随目标，N2 / EGT / FF 由 `engine-state.ts` 推导；燃油按 N1 实时消耗；
- 液压：GREEN / BLUE / YELLOW 以 900 PSI/s 跟随泵开关目标，SD 可看到压力爬升/下降；
- 电气：GEN 1/2 开关会改变发电机电压/频率/负载与接触器状态；
- SD 的 F/CTL 舵面为中立位，FCDC 离散字置为 normal；
- ISIS 使用 `AIRSPEED INDICATED` / `INDICATED ALTITUDE:3` / `PLANE PITCH/BANK` 等基础 SimVar；
- FCU 七段显示与 EFIS baro 来自 `fcu-state.ts`，`panels.html` 顶部支持目标输入、± 步进和 managed 切换；`coui://` 贴图在构建时重写为本地 `/Images/...`；
- ND 航路通过 `RegisterGenericDataListener` 的 `EB_EVENTS` 通道注入：默认 4 个演示航路点，也可在 `CONTROLS` 里输入 ICAO（LSGG/LSGS/LSGL/LFLL/LFMN/LIMC…）插入自定义航路；`DIR TO NEXT` 推进活动航路点。航路点来自迷你本地库，不是真实 navdata。

这意味着：**渲染层是完整的原版逻辑；数据层是“能让它正确动起来的最小系统模型”。**
下一步接真实飞行模型时，只需要替换 `src/data/*` 的写入，不必碰 `vendor/`。

---

## 6. 已知限制

1. **没有完整 WASM systems**：A320 的飞行控制、FMS、液压/电气/燃油等逻辑仍在 Rust WASM 中；本阶段用 JS 最小模型替代。`systems-feed.ts` 有 N1 惯性、液压压力斜坡、燃油消耗和 GEN/HYD 开关，但还没有故障传播、过热、跳开关等完整逻辑。
2. **进近模式是简化几何**：APP 模式会把高度/航向预置到 8 NM、3° 路径（2500 ft / 45°），并根据航向偏差积分横向偏移、根据高度差计算 G/S 偏差；无线电高度 ≤100 ft 自动转 FLARE、≤5 ft 转 ROLL OUT。不是真实 ILS 接收机/进近路径，也没有真实 LAND 模式逻辑。
3. **SDv2 只有 F/CTL、STATUS 两页**：上游 SDv2 本身如此；主驾驶舱已改用 legacy 全量 SD。
4. **Chromium 的 SVG 3D 限制**：高度/航向的“滚筒”数字使用 `rotate3d`，Chromium 不支持 SVG 属性级 3D 变换，可能同时看到相邻数字（例如高度窗显示 `120|20`）。原版 Coherent GT 渲染器没有这个问题；后续可在适配层做 DOM 级兼容。
5. **MCDU/FMS 目前是演示级**：INIT/F-PLN/PERF、FLT NBR、PERF 字段键盘录入、FROM/TO 城市对输入、航路点追加/删除/清空、CST 高度/速度约束、IDX+UP/DN 航路点重排、V 速度 CALC 可用；启动时注入 LSGG→LFMN 航路与性能数据。`mini-navdata.ts` 覆盖 WAYPOINT_DB 内机场/航路点。仍缺真实 navdata 和完整起飞性能计算；城市对删除/重建 active plan 的空窗期已由适配层 guard，不再抛 pageerror。
6. **音效/交互**：`onInteractionEvent` 已转发，但还没有键盘/鼠标映射到 FCU/RMP；SD 页切换通过驾驶舱下拉框完成。
7. **共享状态覆盖范围**：目前 `BroadcastChannel` 驱动 PFD / ND / E/WD / SD / ISIS；FCU、RMP 仍使用固定演示数据，后续统一到同一条数据总线。
7. **ISIS 亮度层**：MSFS 的 glass-cockpit 调光覆盖层在 standalone 中被 CSS 隐藏，否则整屏过暗。

---

## 7. 验证记录

完整、可复现的记录见 **[VERIFICATION.md](VERIFICATION.md)**（含上游代码逐文件哈希对比）。摘要：

- **路由回归**：`/`、PFD、ND、E/WD、SDv2、full SD、Clock、ISIS、FCU、RMP、BAT、ATC、MCDU、Panels、`sd-full?page=3`、`sd-full?page=5` 共 16 条，全部 HTTP 200，0 pageerror。
- **布局回归**：1920×1080、1440×900、1366×768 三档均渲染 7 个 iframe；1440 截图保存在 `docs/responsive-1440.png`。
- **干净环境构建**：把工程复制到空目录，执行 `npm ci`（42 个包）后 `vite build` 成功（约 13 s），不依赖本机缓存。
- Chromium 会对部分 SVG `rotateX(...)` 打印 transform 警告，这是 PFD/SD 原版 3D 鼓形动画的已知兼容性提示，不影响渲染。

![1440 layout](docs/responsive-1440.png)

## 8. 下一阶段建议

1. **系统层**：把 `fbw-a32nx/src/wasm/systems` 中仪表实际消费的 ARINC 字/离散字逐步移植为 TypeScript（或把 Rust 编译为 WASM 并在浏览器中跑，但需要替换 MSFS 接口）。
2. **FMS/导航**：接入 `fbw-a32nx/src/systems/fmgc` 的飞行计划与 `fbw-common` 的 navdata，让 ND 显示航路、VOR/NDB、机场。
3. **面板**：FCU / RMP 的按键与 3D 外形、MCDU 用同样的宿主模式接入；它们大多也是 HTML/SVG，只是数据接口不同。
4. **驾驶舱布局**：当前 2×2 + 右侧 Clock/ISIS 是开发布局；后续可按 A320 真实面板做 glareshield + pedestal，多显示器/多窗口用 BroadcastChannel 同步。
5. **数据总线**：把 `src/data` 换成 WebSocket/SharedWorker 数据源，仪表 iframe 只订阅，便于接外部飞行模型。

---

## 9. 许可

- 上游 A32NX 代码：GPL-3.0，版权归 FlyByWire Simulations 及其贡献者。
- 本项目新增的适配层（`src/`、`vite.config.ts`、HTML/CSS）：GPL-3.0。
- `@microsoft/msfs-sdk`：MIT。

如果分发本项目的二进制/构建产物，请保留 `LICENSE` 与上游版权声明。

---

## Flight model (JS, no MSFS)

The cockpit now has a lightweight A320-class flight model instead of the old manual sliders.

![Flight cockpit](docs/flight-cockpit.png)

![Takeoff PFD](docs/flight-pfd.png)

![Landing](docs/flight-landing.png)

### Controls

| Input | Action |
|---|---|
| `S` / `W` or drag the sidestick down/up | pitch up / down |
| `A` / `D` or drag the sidestick left/right | roll |
| `Q` / `E` | rudder |
| `Shift` / `Ctrl` | throttle up / down |
| `G` | gear |
| `F` | flaps cycle 0-4 |
| `B` | brake |
| `P` | pause |
| `R` | reset to runway |
| HUD `RWY` | LSGG runway, flaps 2, brake set |
| HUD `APP` | 8 NM / 3000 ft approach, AP to 1000 ft |
| HUD `AP` | altitude / speed / heading autopilot |
| HUD `PAUSE` | freeze the model |

### Flight profile

- Takeoff: LSGG field elevation 1411 ft, flaps 2, release brake, throttle 100%, rotate at ~145 kt.
- Climb: the model uses lift/drag/thrust/weight, so climb rate depends on speed and configuration.
- Cruise: AP holds target altitude, speed and heading from the drawer (`TGT HDG`, `SEL SPD`, `SEL ALT`).
- Landing: `APP` sets a 3000 ft / 8 NM approach, gear down and flaps 3; AP descends to 1000 ft, touchdown at about 140 kt, auto-brake stops the aircraft.

Verified in the static build:

- takeoff at 147 kt after 24 s, liftoff at 172 kt, 1483 ft / +368 fpm shortly after;
- APP landing: touchdown at 140 kt, full stop 12.6 s later, phase `LANDED`;
- PFD/ND/ISIS/E/WD all update from the same model; 0 pageerror.

Limitations: simplified point-mass aero, no engine-out/icing/ground effect, no full FBW normal law, no landing gear damage.

### Time acceleration and protections

- `T` or HUD `RATE` cycles 1x / 2x / 4x / 8x simulation rate.
- Landing flare: below 80 ft the model reduces sink rate; touchdown is typically around 140 kt / -180 fpm.
- Stall warning: `alpha > 15°` or IAS below ~105 kt sets the HUD `STALL` warning and forces a nose-down tendency.
- Overspeed with flaps sets `OVERSPEED` in the HUD.

---

## Rust flight core (Phase 0/1)

The flight dynamics now have a Rust implementation in `crates/sim-core`.

- Rust `cdylib` + `rlib`, no external crates.
- Builds for Windows/iOS natively and for `wasm32-unknown-unknown`.
- The browser cockpit loads `public/wasm/sim_core.wasm`; if the fetch fails it falls back to the TypeScript model.
- Current browser state reports `source: "rust-wasm"`.
- `npm run wasm` rebuilds the wasm artifact; `npm run dev` / `npm run build` run it automatically.
- `cargo test` contains native takeoff and autopilot-landing profile tests.

Prerequisites: Rust stable + `wasm32-unknown-unknown` target.

```bash
rustup target add wasm32-unknown-unknown
cargo test --manifest-path crates/sim-core/Cargo.toml
npm run wasm
```

Verified in the static build: Rust core active, takeoff 0→152 kt in 25 s, rotation to 184 kt / 1713 ft / +2501 fpm, 0 pageerror.

CI: `.github/workflows/ci.yml` runs Rust tests and the wasm/web build on Ubuntu and Windows. The iOS unsigned-IPA workflow is the next Phase 0 deliverable.

---

## Phase 0 shells and CI

### Windows (Tauri 2)

- `src-tauri/` contains the Tauri 2 shell, icon, capability and window config.
- `.github/workflows/windows-shell.yml` builds NSIS + MSI installers on `windows-latest`.
- Local prerequisite: Rust stable + WebView2 runtime (Windows 11 has it).
- The shell loads the same `dist/` web app, including the Rust wasm core.

### iOS unsigned IPA

- `ios/` is a small SwiftUI + WKWebView host with an `a32nx://` custom scheme handler.
- `ios/project.yml` is an XcodeGen project; the web build is copied into `ios/Resources/web`.
- `.github/workflows/ios-unsigned.yml` runs on `macos-14`, installs XcodeGen, builds with `CODE_SIGNING_ALLOWED=NO`, and packages `A32NXSim-unsigned.ipa`.
- The IPA is unsigned; sign it with AltStore / Sideloadly / your own certificate.
- Repo root is expected to be `a32nx-instruments`.

### Verified in this environment

- Rust wasm build: 22,239 bytes.
- Browser cockpit reports `source: "rust-wasm"`.
- Static takeoff: 152 kt at 25 s; rotation to 184 kt / 1713 ft / +2501 fpm.
- WASM autoland: touchdown 137.7 kt / -180 fpm.
- Web static build: 104 files / 3.32 MB, 0 pageerror.
- Windows/iOS shell compilation is wired in CI but was not executable on this Windows host (no Xcode; Tauri toolchain downloads at CI time).

### Current Phase 0 status

- Rust/wasm core verified in the browser.
- `actionlint` passes all three workflows.
- Tauri Windows shell compiles only where MSVC Build Tools are present; GitHub `windows-latest` has them.
- iOS Xcode build requires the macOS GitHub runner; no local IPA yet.
- Repo root must be the `a32nx-instruments` directory for the workflow paths.

## Overhead panel and cold & dark (first slice)

`overhead.html` is the first A320 overhead panel slice:

- ELEC: BAT 1/2, EXT PWR, GEN 1/2, APU GEN, BUS TIE.
- APU: MASTER SW, START, AVAIL, GEN.
- HYD: ENG/ELEC pumps, PTU.
- FUEL: L/R/C pumps, XFEED.
- AIR: PACK 1/2, ENG BLEED 1/2, APU BLEED, XBLEED.
- PRESS, ANTI ICE, ADIRS.

The panel publishes derived AC/DC buses on `a32nx-overhead`. The cockpit listens and blanks the AC displays (PFD/ND/E/WD/SD) and DC displays (clock/ISIS) when their bus is off.

Verified:

- Opening the overhead page with all switches off leaves 6 cockpit screens unpowered.
- BAT 1 restores the 2 DC screens.
- EXT PWR restores all 6 screens.
- 0 pageerror.

This is only the power slice; hydraulic/fuel/bleed/APU effects on the instruments and ECAM are still to come.

### Hydraulic / electrical coupling

The overhead state now flows into the cockpit bus:

- `a32nx-overhead` → cockpit `readState()`.
- HYD GREEN pressure follows `hydEng1 || hydElec1`; BLUE follows `hydElec2`; YELLOW follows `hydEng2 || hydElec2`.
- GEN 1/2 states drive the E/WD ELEC warnings.
- SD HYD page shows GREEN 3000 PSI, BLUE 0, YELLOW 0 after BAT + EXT PWR with only ELEC 1 pump on.
- E/WD shows `ELEC GEN 1 OFF`, `GEN 2 OFF`, `BLUE ELEC PUMP OFF`, `YELLOW ENG 2 PUMP OFF`.

Verified static: 0 pageerror.

### Air conditioning / PACKS

- Overhead `PACK 1/2` now drives `systemsState.pack1/2` on the E/WD bus.
- E/WD sets the original pack-flow valve SimVars and injects the FWC codes `216120701` / `216120801`.
- With PACK 1/2 off, E/WD shows `AIR PACK 1 OFF` and `PACK 2 OFF`; turning PACK 1 on clears its line.
- The E/WD PACKS indicator follows the pack state.

Verified static: PACK 1/2 OFF → warnings present; PACK 1 ON → PACK 1 line gone; 0 pageerror.

### APU and fuel pumps

- Overhead APU MASTER/START/AVAIL/GEN/BLEED now drive the original SD APU page:
  - `AVAIL`
  - `APU GEN 20% / 115 V / 400 Hz`
  - `BLEED 46 PSI`
- APU generator state also closes `3XS` and feeds the AC bus.
- Fuel L/R/C pumps and XFEED drive `FUELSYSTEM PUMP ACTIVE/SWITCH` and the fuel valves; with engines above idle, E/WD emits `L TK PUMP 1 OFF` / `R TK PUMP 1 OFF` if the respective side pumps are off.

Verified static: APU AVAIL + GEN + BLEED page renders 20/115/400 and 46 PSI; 0 pageerror.

### Engine start

- Overhead `ENG` panel: MASTER 1/2, START 1/2, ENG 1/2 run lights.
- Start requires ENG MASTER + bleed (APU BLEED with APU AVAIL, or XBLEED with the other engine running).
- Each engine takes 18 s to reach idle; the cockpit then commands 24% N1 idle.
- E/WD shows the running engine N1/EGT/N2/FF and `XX` for the shut-down engine.
- Turning the master switch off shuts the engine down.

Verified static: APU AVAIL + APU BLEED + FUEL L PUMPS + ENG 1 MASTER/START → ENG 1 running, N1 24%, EGT ~451 C, N2 ~57%, E/WD engine 2 off.

### Bleed and pressurization pages

- `BLEED`: XBLEED, ENG 1/2 PR valves, APU bleed, PACK flow and wing anti-ice now come from the overhead. The SD page shows 46 PSI APU bleed, valve positions and anti-ice.
- `PRESS`: a simple cabin schedule from the flight-model altitude drives CPC1/2 ARINC words.
  - Ground: ΔP 0.0 PSI, V/S 0, CAB ALT 0, LDG ELEV 1400 FT.
  - Climb: CAB ALT follows `(altitude - 1411) * 0.24`, ΔP is capped at 8.6 PSI.

Verified static: BLEED page 46 PSI and valve graphics; PRESS page 0.0 PSI / 0 CAB ALT at LSGG; 0 pageerror.

### Engine fire (V2 start)

- Overhead `FIRE` panel with ENG 1/2 FIRE guarded buttons and fire lights.
- Pressing FIRE:
  - latches the fire warning
  - forces the associated ENG MASTER off
  - shuts down the engine and the engine run light
- E/WD receives FWC `260001001` / `260002001` and shows `ENG 1 FIRE` / `ENG 2 FIRE` at the top of the warning column.
- The flight model then sees no running engine and commands idle thrust to zero.

Verified: ENG 1 FIRE on the overhead → E/WD `ENG 1 FIRE`, both engines `XX`, 0 pageerror.

### First route: ZBAD → ZBAA

- `ZBAD` (Beijing Daxing) and `ZBAA` (Beijing Capital) plus `ZB01/02/03` are in the mini nav database.
- The FMS demo route is now ZBAD → ZBAA with ZB01/02/03.
- The Rust core has `sim_reset_at(lat, lon, elevation, heading)`, and the cockpit listens to the FMS route origin to reposition the aircraft.
- ZBAD scene: 39.5098 N / 116.4105 E, field elevation 118 ft, runway heading 010.
- MCDU INIT shows `ZBAD/ZBAA`; F-PLN shows ZB01 → ZB02 → ZB03 → ZBAA.

Verified static:

- Cockpit position `39.5098 / 116.4105`, ALT 118 ft, HDG 010.
- F-PLN ZB01/ZB02/ZB03, DEST ZBAA.
- 0 pageerror.

### Phone / tablet all-instruments layout

- `@media (max-width: 900px)` switches the cockpit to a 3×2 grid: PFD / ND / E-WD on top, SD / Clock / ISIS below.
- iPhone 14 Pro landscape (852×393 CSS): all 6 units visible, no horizontal scroll.
- iPad Pro 11" (1194×834 CSS): all 6 units visible with a larger 3-column grid.
- The flight HUD is hidden on small screens by default; `FLIGHT` in the top bar toggles it.
- Safe-area padding and `viewport-fit=cover` are enabled for iPhone/iPad.
- The HUD is now a compact 320 px overlay on phones.

Verified with browser viewports; actual WKWebView on-device layout still needs the IPA.

### Navdata provider and runway data

- New `src/data/navdata/provider.ts`:
  - `NavDataProvider` interface
  - `LocalNavDataProvider` (current)
  - future OpenAIP / Navigraph implementations plug into the same interface.
- Local provider includes:
  - ZBAD 01L/19R, 01R/19L
  - ZBAA 18L/36R, 18R/36L, 01/19
  - LSGG 04/22
- `mini-navdata.ts` now serves `getRunways()` from the provider, so the FMS can load a real runway:
  - `setOriginAirport('ZBAD')` → ok
  - `setOriginRunway('01L')` → ok
- The MCDU/FMS is unaware of the data source; swapping to OpenAIP/Navigraph only changes the provider.

Verified static: origin ZBAD / runway 01L; 0 pageerror.

### LNAV and ground-sense fix

- When the lateral selector is `NAV` and AP is on, the cockpit computes the bearing to the next FMS waypoint and commands HDG.
- Waypoint sequencing advances within 1.5 NM; the route used is custom route, otherwise FMS route + destination.
- Verified at ZBAD: target heading to ZB01 is 008°, matching the great-circle bearing from 39.5098/116.4105.
- PFD/SD gear-compressed logic now uses radio altitude, not MSL altitude, so ZBAD (118 ft) is correctly sensed as on-ground.

### APU fire

- FIRE panel now includes APU FIRE.
- Pressing APU FIRE:
  - latches the fire warning
  - forces APU MASTER off
  - drops AVAIL / GEN / BLEED
  - E/WD shows `APU FIRE` (FWC `260003001`)
- APU fire does not shut down the engines; engine 1/2 fire handles remain independent.

Verified static: APU FIRE → E/WD `APU FIRE`, 0 pageerror.

### Go-around

- HUD `GA` button (next to APP).
- Rust core `sim_go_around()`:
  - leaves the ground
  - sets +1200 fpm
  - throttle 100%
  - flaps 2, gear up, brakes off
  - AP on, target altitude = field elevation + 3000 ft, target speed 180 kt
- Cockpit syncs the FCU selected altitude and throttle slider.
- APP remains a separate approach reset.

Verified static at ZBAD: ALT 196 ft, V/S +1143 fpm, THR 100%, gear up, AP on, target 3100 ft; 0 pageerror.

### Fire agents and QRH

- FIRE panel now has AGENT 1 / AGENT 2 / APU AGENT.
- Agent discharge requires the matching fire warning; after 5 s the fire is extinguished and the E/WD warning clears.
- Engines stay shut down after an engine fire; the agent only clears the fire.
- `QRH` button opens an emergency checklist overlay:
  - ENG 1/2 FIRE
  - APU FIRE
  - GO AROUND
- QRH is available from the overhead page and closes back to the panel.

Verified static: APU FIRE + APU AGENT → fire true before, false after 5 s, E/WD `APU FIRE` gone; 0 pageerror.

### SID / STAR / RNAV approach

- Local navdata now provides:
  - ZBAD SID `ZB1D` (runway 01L, via ZB01/ZB02)
  - ZBAA STAR `ZB2A` (runway 18L, via ZB02/ZB03)
  - ZBAA RNAV approach `RNAV18L` (runway 18L)
- The FMS can now set all three:
  - `setDeparture('ZBAD/ZB1D')` → true
  - `setArrival('ZBAA/ZB2A')` → true
  - `setApproach('ZBAA/RNAV18L')` → true
- The procedure objects use ARINC-style `TF` legs so the FMS builds them like real database procedures.
- These are simplified training procedures, not the real published ZBAD/ZBAA SID/STAR text.

### Destination approach reset

- HUD `APP` is now destination-aware:
  - reads the FMS destination (ZBAA)
  - places the aircraft 8 NM before the destination runway along the scene heading
  - sets field elevation, 2000 ft AGL, 140 kt, flaps 4, gear down, AP on
- Rust `sim_reset_approach_at()` supports any airport, not just LSGG.
- At ZBAA: 40.212 N / 116.585 E, ALT ~2100 ft, HDG 177, V/S -674 fpm, flaps 4, gear down, AP on.
- If no FMS destination is present, APP falls back to the original LSGG approach.

Verified static: ZBAA approach state and 0 pageerror.

### Destination-aware approach and procedure legs

- `publishFmsRoute()` now prefers the active flight plan's `allLegs` (SID/STAR/approach included) over the demo point list; the static list remains the fallback.
- Cockpit LNAV keeps the FMS destination as the final leg only when it is not already in the route.
- HUD `APP` now targets the FMS destination:
  - ZBAA final 8 NM
  - field elevation 116 ft
  - 140 kt, flaps 4, gear down, AP on
- The destination approach uses Rust `sim_reset_approach_at()`, so it works beyond LSGG.

Verified static: ZBAA 40.212/116.585, ALT 2104 ft, HDG 177, V/S -674 fpm, FLAPS 4, GEAR DOWN, AP ON.

### Continuous ZBAD → ZBAA profile

A full profile was flown end to end in one session:

1. Cold & dark → BAT 1 → EXT PWR → APU MASTER/START (5 s) → APU BLEED.
2. FUEL L PUMPS ON → ENG 1 MASTER/START (18 s) → idle.
3. Takeoff from ZBAD 01L, gear up, AP ON, NAV mode, CLB to 20 000 ft.
4. LNAV sequenced ZB01 → ZB02 → ZB03 toward ZBAA.
5. At 9.7 NM from ZBAA, APP reset to final 8 NM.
6. RNAV-style descent: 2 100 ft → 116 ft, flaps 4, gear down.
7. Touchdown at ZBAA: 116 ft, 103 kt, **-400 fpm**, phase `LANDED`.

No pageerror during the run.

The approach was also tuned to idle thrust (N1 20%) so the aircraft does not float/climb at 170 kt; it now stabilises around 135 kt and lands.

### OpenAIP adapter

- `src/data/navdata/openaip.ts` implements `NavDataProvider` for OpenAIP JSON:
  - accepts `{ items: [...] }` or a bare airport array
  - GeoJSON `[lon, lat]` airport coordinates
  - threshold coordinates or `thresholdLocation`
  - elevation/runway length/width
- `src/data/navdata/bootstrap.ts` optionally loads `/navdata/openaip.json` at MCDU boot.
- `setNavDataProvider()` / `getNavDataProvider()` let the provider swap at runtime; the MCDU/FMS backend calls the getter on every query.
- A sample drop-in instructions file is at `public/navdata/README.md`.
- Local provider remains the default, so no network data is required for the standalone build.

Verified:
- Synthetic OpenAIP airport → ZBAD 39.5098/116.4105, elevation 118 ft, runway 01L 3800 m.
- Runtime provider name switches to `openaip`; MCDU still loads ZBAD/ZBAA with 0 pageerror.

### Engine and APU failure

- ENG panel: FAIL 1 / FAIL 2.
- APU panel: FAIL.
- Engine failure forces the associated master switch off and shuts the engine down.
- Both engines failed:
  - E/WD shows `ALL ENG FAIL PROC.APPLY` (FWC `770002712`)
  - both engine parameter blocks show `XX`
- APU failure drops AVAIL / GEN / BLEED and latches the APU FAULT light.
- Fires and failures are independent: a failed engine can still have a fire warning.

Verified static: ENG 1 FAIL + ENG 2 FAIL → E/WD `ALL ENG FAIL PROC.APPLY`, both N1/EGT/N2/FF XX, 0 pageerror.

### Cargo smoke and rapid depressurization

- FIRE panel: `CARGO SMOKE`.
  - E/WD: `SMOKE` group + `FWD CARGO SMOKE` (FWC `260015001`).
- PRESS panel: `DEPRESS`.
  - E/WD: `CAB PR EXCESS CAB ALT` (FWC `213122101`).
  - SD press schedule is forced to CAB ALT 14000 ft / ΔP 0.
- Both are latched faults and independent from engine/APU fire.

Verified static: CARGO SMOKE + DEPRESS → E/WD `CAB PR EXCESS CAB ALT` and `SMOKE FWD CARGO SMOKE`; 0 pageerror.

### Landing gear and ELAC faults

- FAULTS panel: GEAR FAIL, ELAC 1.
- GEAR FAIL:
  - if the gear is up, E/WD shows `L/G GEAR NOT DOWN` (FWC `320015001`)
  - the HUD gear lever cannot extend the gear (fault is latched)
- ELAC 1 fault:
  - E/WD shows `F/CTL ELAC 1 FAULT` (FWC `270011001`)
  - AP disconnects and stays disconnected while the fault is latched
- Both faults are independent and can be combined with engine/APU failures.

Verified static: GEAR FAIL + ELAC 1 → `F/CTL ELAC 1 FAULT`, `L/G GEAR NOT DOWN`, AP off, gear stays up; 0 pageerror.

### SEC and FAC faults

- FAULTS panel: SEC 1 and FAC 1.
- E/WD:
  - `F/CTL SEC 1 FAULT` (FWC `270021001`)
  - `AUTO FLT FAC 1 FAULT` (FWC `220020001`)
- Flight-control law degradation:
  - ELAC 1 or SEC 1 fault: stick pitch/roll authority is reduced to 60%.
  - FAC 1 fault: rudder/yaw authority is reduced to 40%.
- Faults are independent and can be stacked with gear/ELAC/engine failures.

Verified static: SEC 1 + FAC 1 → both E/WD messages, 0 pageerror.

### Standalone instrument power

- New `installInstrumentPower()` helper.
- Cold & dark now blanks standalone pages too:
  - MCDU / BAT: DC bus
  - FCU / RMP / ATC: AC bus
- `power-request` handshake makes a newly opened page receive the current bus state immediately.
- BAT 1/2 powers the DC pages; EXT PWR / GEN / APU GEN powers the AC pages.
- Direct page opening without the overhead still works (no bus message = stays powered).

Verified static: overhead + MCDU → cold `unpowered`; BAT 1 → MCDU powered; 0 pageerror.

### Normal / Alternate / Direct law

- HUD now shows `NORMAL LAW`, `ALT LAW` or `DIRECT LAW`.
- Law is derived from the FBW computer faults:
  - one of ELAC 1 / SEC 1 / FAC 1 failed → **ALTERNATE**
  - any two of them failed → **DIRECT**
- Control authority:
  - NORMAL 100%
  - ALTERNATE 72%
  - DIRECT 50%
- FAC 1 still reduces yaw authority to 40%.
- ELAC 1 or DIRECT law forces AP off.

Verified static: NORMAL → ALT → DIRECT transitions in the HUD; AP off; 0 pageerror.

### Fuel leaks

- FUEL panel: `LEAK L` / `LEAK R` with a latched LEAK light.
- E/WD:
  - `FUEL` group + `L WING TK LO LVL` (FWC `280013001`)
  - `R WING TK LO LVL` (FWC `280014001`)
- SD FUEL page drops the affected main/aux tank quantity to 3% while the leak is active.
- Both sides can leak at once.

Verified static: LEAK L + LEAK R → both E/WD fuel low-level messages; 0 pageerror.

### Doors

- FUEL panel: CABIN DOOR / CARGO DOOR, both latched.
- SD DOOR/OXY page:
  - cabin door open → cabin door warning shape
  - cargo door open → cargo door warning shape / `FWD DOOR CARGO LOCKED` false
  - slides show as armed/closed graphics
- The doors are independent; both can be open at once.

Verified static: CABIN DOOR + CARGO DOOR → SD DOOR/OXY warning shapes; 0 pageerror.

### Crew oxygen

- FUEL panel: OXY fault button + OXY light.
- E/WD: `-CREW OXY MASKS.....USE` (FWC `213122102`).
- SD DOOR/OXY: `PUSH_OVHD_OXYGEN_CREW` is set, so the oxygen mask indication follows the fault.
- Independent from cabin/cargo door and pressurization faults.

Verified static: OXY → E/WD `-CREW OXY MASKS.....USE`; 0 pageerror.

### Hot air fault

- AIR panel: HOT AIR fault button + FAULT light.
- E/WD: `COND` group + `HOT AIR FAULT` (FWC `216329001`).
- Independent of PACK 1/2 off, bleed and pressurization faults.

Verified static: HOT AIR → E/WD `COND HOT AIR FAULT`; 0 pageerror.

### Start interlocks

- APU START requires DC power (`BAT 1` or `EXT PWR`).
- ENG START requires:
  - DC power
  - the matching fuel pump side on (`FUEL L` for ENG 1, `FUEL R` for ENG 2)
  - bleed available (APU BLEED + AVAIL, or XBLEED + other engine)
- Blocked starts show a 3-second held message instead of being immediately overwritten by the status line.

Verified: no DC → `NO DC POWER · BAT 1 OR EXT PWR REQUIRED`; BAT only, fuel off → `ENG 1 · FUEL PUMPS OFF`; BAT + fuel + APU bleed → engine starts.

### Exterior lights

- New LIGHTS panel:
  - NAV
  - BEACON
  - STROBE
  - LANDING
  - TAXI
  - EXT LT status light
- State is published on `a32nx-sim` and mapped to `LIGHT NAV/BEACON/STROBE/LANDING/TAXI` SimVars in the systems feed.
- All five can be on at once; the EXT LT light reflects any active exterior light.

Verified static: all five on, EXT LT green; 0 pageerror.

### Full page and power regression sweep

- All 15 pages return HTTP 200 with 0 pageerror:
  - index, PFD, ND, E/WD, SD, clock, ISIS, FCU, RMP, BAT, ATC, MCDU, panels, overhead, SD-full
- Standalone power groups:
  - cold: FCU/RMP/ATC (AC) and BAT/MCDU (DC) all `unpowered`
  - BAT 1: BAT + MCDU powered, AC pages still dark
  - EXT PWR: FCU/RMP/ATC also powered
- This confirms the cold&dark overlay is wired beyond the six cockpit displays.

### ADIRS alignment

- ADIRS 1/2/3 switches now drive a real alignment sequence.
- When all three are on:
  - E/WD shows `IR 1+2+3 IN ALIGN` (FWC `340004812`)
  - after 10 s the message clears
  - the ADIRS NAV light turns green
- Turning any ADIRS off resets alignment and the light.
- Cold & dark starts unaligned.

Verified static: align message present, gone after 10 s, NAV light green; 0 pageerror.

### PWA fallback for iPhone / iPad

- Added `manifest.webmanifest` with standalone display and 192/512 icons.
- `apple-touch-icon` and `apple-mobile-web-app-*` meta tags added.
- In Safari, "Add to Home Screen" now launches the cockpit full-screen without an IPA.
- This is a fallback only: the self-signed IPA is still the requested native path.
- Verified: manifest 200, icon 200, 0 pageerror.

PWA files:

- `public/manifest.webmanifest`
- `public/icons/icon-192.png`
- `public/icons/icon-512.png`
- `public/icons/apple-touch-icon.png`

### Final smoke after PWA/ADIRS

All 15 pages re-tested after the PWA manifest, ADIRS alignment and lights changes:

- 15 × HTTP 200
- 15 × 0 pageerror

This is the final regression gate for the current build.
